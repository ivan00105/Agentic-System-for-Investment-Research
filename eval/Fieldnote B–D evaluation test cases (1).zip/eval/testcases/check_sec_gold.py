#!/usr/bin/env python3
"""Corroborate the primary-document iXBRL labels against SEC Companyfacts."""

import argparse
import json
import os
import re
from collections import Counter
from decimal import Decimal
from pathlib import Path

import httpx
import yaml

from build_cases import Edgar, HERE


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--cache", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    agent = os.environ.get("SEC_USER_AGENT", "")
    if "@" not in agent:
        p.error("Set SEC_USER_AGENT to a descriptive application and a valid contact email.")
    edgar = Edgar(agent, args.cache)
    ticker_cache, seen, findings = {}, set(), []
    for file in sorted(HERE.glob("*.yaml")):
        c = yaml.safe_load(file.read_text(encoding="utf-8"))
        ciks = {x["ticker"]: x["cik"] for x in c["companies"]}
        for item in c["gold"]:
            source = item.get("source")
            if not source:
                continue
            t = item["ticker"]
            tag = re.search(r"us-gaap:(\w+)", source["location"])[1]
            key = (t, tag, item["period_end"].isoformat(), source["accession"])
            if key in seen:
                continue
            seen.add(key)
            if t not in ticker_cache:
                try:
                    response = edgar.get(f"https://data.sec.gov/api/xbrl/companyfacts/CIK{ciks[t]:010}.json")
                    ticker_cache[t] = json.loads(response)["facts"]["us-gaap"]
                except (httpx.HTTPError, KeyError, ValueError) as exc:
                    ticker_cache[t] = type(exc).__name__
            facts = ticker_cache[t]
            if isinstance(facts, str):
                status, match = "endpoint_unavailable", set()
            else:
                match = {f["val"] for f in facts.get(tag, {}).get("units", {}).get("USD", [])
                         if f.get("end") == key[2] and f.get("accn") == key[3]
                         and f.get("filed") == source["filed"].isoformat()
                         and (not f.get("start") if item["metric"] in {"total_assets", "total_liabilities", "stockholders_equity"}
                              else f.get("start") and 350 <= (
                                  item["period_end"].fromisoformat(f["end"]) -
                                  item["period_end"].fromisoformat(f["start"])).days + 1 <= 380)}
                status = ("confirmed" if Decimal(str(item["value"])) * 1_000_000 in match
                          else ("different_value" if match else "not_in_companyfacts"))
            findings.append({"ticker": t, "concept": tag, "period_end": key[2], "accession": key[3],
                             "status": status, "url": source["url"]} | (
                                {"filed_value_usd_millions": item["value"], "companyfacts_usd": sorted(match)}
                                if status == "different_value" else {}))
    edgar.client.close()
    counts = Counter(item["status"] for item in findings)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps({"unique_checks": len(findings), "counts": counts, "rows": findings},
                                   indent=2) + "\n", encoding="utf-8")
    print(dict(counts))
    return int(counts["different_value"] > 0)


if __name__ == "__main__":
    raise SystemExit(main())
