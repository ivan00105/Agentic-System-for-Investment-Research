#!/usr/bin/env python3
"""Build non-secret regression YAMLs from original SEC inline XBRL documents."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import time
from collections import Counter
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path

import httpx
import yaml
from lxml import html

HERE = Path(__file__).resolve().parent
YEAR = 2025
# Splits are by issuer, not question. Paired compares only join issuers in one split.
ISSUERS = (
    ("AAPL", 320193, "Apple Inc.", "dev"), ("MSFT", 789019, "Microsoft Corporation", "dev"),
    ("NVDA", 1045810, "NVIDIA Corporation", "dev"), ("AMD", 2488, "Advanced Micro Devices, Inc.", "dev"),
    ("AMZN", 1018724, "Amazon.com, Inc.", "dev"), ("WMT", 104169, "Walmart Inc.", "dev"),
    ("GOOGL", 1652044, "Alphabet Inc.", "dev"), ("META", 1326801, "Meta Platforms, Inc.", "dev"),
    ("JPM", 19617, "JPMorgan Chase & Co.", "dev"), ("BAC", 70858, "Bank of America Corporation", "dev"),
    ("XOM", 34088, "Exxon Mobil Corporation", "dev"), ("CVX", 93410, "Chevron Corporation", "dev"),
    ("PEP", 77476, "PepsiCo, Inc.", "dev"), ("KO", 21344, "The Coca-Cola Company", "dev"),
    ("IBM", 51143, "International Business Machines Corporation", "dev"),
    ("INTC", 50863, "Intel Corporation", "dev"),
    ("ORCL", 1341439, "Oracle Corporation", "held_out"), ("ADBE", 796343, "Adobe Inc.", "held_out"),
    ("CRM", 1108524, "Salesforce, Inc.", "held_out"), ("COST", 909832, "Costco Wholesale Corporation", "held_out"),
    ("TGT", 27419, "Target Corporation", "held_out"), ("HD", 354950, "The Home Depot, Inc.", "held_out"),
    ("NKE", 320187, "NIKE, Inc.", "held_out"), ("PG", 80424, "The Procter & Gamble Company", "held_out"),
    ("CAT", 18230, "Caterpillar Inc.", "held_out"), ("MCD", 63908, "McDonald's Corporation", "held_out"),
    ("DIS", 1744489, "The Walt Disney Company", "held_out"), ("GS", 886982, "The Goldman Sachs Group, Inc.", "held_out"),
)
BANKS = {"JPM", "BAC", "GS"}
PAIRS = (("AAPL", "MSFT"), ("NVDA", "AMD"), ("AMZN", "WMT"), ("GOOGL", "META"),
         ("JPM", "BAC"), ("XOM", "CVX"), ("PEP", "KO"), ("IBM", "INTC"), ("ORCL", "ADBE"),
         ("CRM", "ORCL"), ("COST", "TGT"), ("TGT", "HD"), ("NKE", "PG"), ("CAT", "MCD"))
LOOKAHEAD = {"AAPL", "NVDA", "WMT", "JPM", "PEP", "ADBE", "TGT", "GS", "DIS", "HD"}
STATEMENTS = {
    "net_income": ("income statement", "NetIncomeLoss"),
    "operating_income": ("income statement", "OperatingIncomeLoss"),
    "operating_cash_flow": ("cash flow statement", "NetCashProvidedByUsedInOperatingActivities"),
    "capex": ("cash flow statement", "PaymentsToAcquirePropertyPlantAndEquipment"),
    "total_assets": ("balance sheet", "Assets"),
    "total_liabilities": ("balance sheet", "Liabilities"),
    "stockholders_equity": ("balance sheet", "StockholdersEquity"),
}
REVENUE = ("RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues", "SalesRevenueNet",
           "RevenueFromContractWithCustomerIncludingAssessedTax")


@dataclass
class Filing:
    ticker: str
    cik: int
    name: str
    split: str
    accession: str
    filed: date
    end: date
    url: str
    contexts: dict
    facts: dict
    sha256: str

    @property
    def company(self):
        return {"ticker": self.ticker, "cik": self.cik, "name": self.name}


class Edgar:
    def __init__(self, user_agent, cache):
        self.client = httpx.Client(headers={"User-Agent": user_agent}, timeout=45, follow_redirects=False)
        self.cache = cache
        self.cache.mkdir(parents=True, exist_ok=True)
        self.previous = 0.0

    def get(self, url):
        path = self.cache / hashlib.sha256(url.encode()).hexdigest()
        if not path.exists():
            time.sleep(max(0, 0.36 - (time.monotonic() - self.previous)))
            self.previous = time.monotonic()
            response = self.client.get(url)
            response.raise_for_status()
            path.write_bytes(response.content)
        return path.read_bytes()


def text(node):
    return "".join(node.itertext()).strip()


def filing(edgar, issuer):
    ticker, cik, name, split = issuer
    rows = json.loads(edgar.get(f"https://data.sec.gov/submissions/CIK{cik:010}.json"))["filings"]["recent"]
    for form, filed, end, accession, doc in zip(
        *(rows[key] for key in ("form", "filingDate", "reportDate", "accessionNumber", "primaryDocument")),
        strict=True,
    ):
        if form != "10-K" or not f"{YEAR}-01-01" <= end <= f"{YEAR+1}-04-01":
            continue
        assert re.fullmatch(r"[\w.-]+", doc) and re.fullmatch(r"\d{10}-\d{2}-\d{6}", accession)
        url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{accession.replace('-', '')}/{doc}"
        body = edgar.get(url)
        root = html.fromstring(body, parser=html.HTMLParser(huge_tree=True))
        inline = [node for node in root.iter("ix:nonnumeric") if node.get("name", "").lower() == "dei:documentfiscalyearfocus"]
        if {text(node) for node in inline} != {str(YEAR)}:
            continue
        anchors = {text(node) for node in root.iter("ix:nonnumeric")
                   if node.get("name", "").lower() == "dei:documentperiodenddate"}
        if not anchors:
            raise ValueError(f"{ticker}: no tagged report date")
        contexts = {}
        for node in root.iter("xbrli:context"):
            if any(el.tag in {"xbrli:segment", "xbrli:scenario", "xbrldi:explicitmember", "xbrldi:typedmember"}
                   for el in node.iter()):
                continue
            entity = node.find(".//xbrli:identifier")
            period = node.find(".//xbrli:period")
            if entity is None or period is None or not text(entity).isdigit() or int(text(entity)) != cik:
                continue
            parsed = {child.tag.split(":")[-1]: date.fromisoformat(text(child)) for child in period
                      if child.tag.split(":")[-1] in {"instant", "startdate", "enddate"}}
            if set(parsed) in ({"instant"}, {"startdate", "enddate"}):
                contexts[node.get("id")] = parsed
        usd = {node.get("id") for node in root.iter("xbrli:unit")
               if [text(child).lower() for child in node] == ["iso4217:usd"]}
        facts = {}
        for node in root.iter("ix:nonfraction"):
            ref, key = node.get("contextref"), node.get("name", "").lower()
            # Use displayed filing rows only, not inline hidden facts.
            if ref not in contexts or node.get("unitref") not in usd:
                continue
            if not key.startswith("us-gaap:") or any(parent.tag in {"ix:hidden", "ix:header"} for parent in node.iterancestors()):
                continue
            raw = re.sub(r"[\s,]", "", text(node))
            if not re.fullmatch(r"\d+(?:\.\d+)?", raw):
                continue
            number = Decimal(raw).scaleb(int(node.get("scale", "0")))
            if node.get("sign") == "-":
                number = -number
            facts.setdefault((key, ref), set()).add(number)
        return Filing(ticker, cik, name, split, accession, date.fromisoformat(filed), date.fromisoformat(end),
                      url, contexts, facts, hashlib.sha256(body).hexdigest())
    raise ValueError(f"{ticker}: no FY{YEAR} original 10-K found in recent SEC submissions")


def source(f, metric, *, prior=False):
    if metric == "revenue":
        # Do not mistake a bank's or REIT's ASC 606 subset for total revenue.
        tags = ("RevenuesNetOfInterestExpense",) if f.ticker in BANKS else REVENUE
        statement = "income statement"
    else:
        statement, tag = STATEMENTS[metric]
        tags = (tag,)
    values = {}
    for (key, ref), numbers in f.facts.items():
        if key not in [f"us-gaap:{tag.lower()}" for tag in tags]:
            continue
        period = f.contexts[ref]
        if metric in {"total_assets", "total_liabilities", "stockholders_equity"}:
            end = period.get("instant")
        else:
            end = period.get("enddate")
            if end is not None and not 350 <= (end - period["startdate"]).days + 1 <= 380:
                continue
        if not end or (not prior and end != f.end) or (prior and not 350 <= (f.end-end).days <= 380):
            continue
        values.setdefault((key, end), set()).update(numbers)
    # Conflicting visible entity-wide values trigger omission rather than a guessed gold.
    distinct = {(end, value) for (_, end), numbers in values.items() for value in numbers}
    if len(distinct) != 1:
        return None
    end, value = distinct.pop()
    tag = next(tag for tag in tags if (f"us-gaap:{tag.lower()}", end) in values)
    fy = YEAR - prior
    value = value / Decimal(1_000_000)
    return {"name": f"{f.ticker.lower()}_{metric}_{fy}", "metric": metric, "ticker": f.ticker,
            "value": int(value) if value == value.to_integral_value() else float(value), "unit": "USD millions",
            "fiscal_period": f"FY{fy}", "period_end": end,
            "source": {"form": "10-K", "accession": f.accession, "filed": f.filed, "url": f.url,
                       "location": f"Consolidated {statement} / visible consolidated iXBRL fact us-gaap:{tag}, period ended {end}"}}


def calc(metric, f, a, b, formula, value, unit):
    val = round(value, 6)
    return {"name": f"{f.ticker.lower()}_{metric}_{YEAR}", "metric": metric, "ticker": f.ticker,
            "value": float(val), "unit": unit, "fiscal_period": f"FY{YEAR}", "period_end": f.end,
            "tolerance": 0.02 if unit == "percent" else 0.5,
            "derived": {"formula": formula, "inputs": [a["name"], b["name"]]}}


def case(label, filings, typ, question, gold, mention, avoid, notes, *, cutoff=None):
    first = filings[0]
    assert all(f.split == first.split for f in filings)
    return {"id": f"{'dev' if first.split == 'dev' else 'held'}-ext-{label}", "split": first.split,
            "case_type": typ, "mode": "check" if len(filings) == 1 else "compare",
            "source": "Fieldnote extension; SEC EDGAR original Form 10-K inline XBRL",
            "question": question, "cutoff": cutoff or (max(f.filed for f in filings) + timedelta(days=30)),
            "companies": [f.company for f in filings],
            "expected": {"behaviour": "answer" if gold else "not_available", "must_mention": mention, "must_not": avoid},
            "gold": gold, "review": {"labelled_by": "Deterministic SEC filing extractor", "labelled_on": date.today(),
                                     "checked_by": None, "check_note": None}, "notes": notes}


def per_issuer(f):
    t = f.ticker
    label = t.lower()
    fy = f"fiscal {YEAR}"
    facts = {m: source(f, m) for m in ("revenue", *STATEMENTS)}
    rev, net, op = (facts[m] for m in ("revenue", "net_income", "operating_income"))
    ocf, capex = (facts[m] for m in ("operating_cash_flow", "capex"))
    assets, liabilities, equity = (facts[m] for m in ("total_assets", "total_liabilities", "stockholders_equity"))
    if rev and net:
        fields = "total net revenue and net income attributable to shareholders" if t in BANKS else "revenue and net income attributable to the parent"
        yield case(f"{label}-{YEAR}-income", [f], "bank" if t in BANKS else "clean",
                   f"What were {t}'s {fy} {fields} in its original annual filing for the year ended {f.end}?"
                   + (" If operating margin is unsupported, say so rather than estimating it." if t in BANKS else ""),
                   [rev, net],
                   ["Use the consolidated income statement and the specified fiscal-year end."]
                   + (["Explain why a conventional operating margin is unsupported when there is no operating-income line."] if t in BANKS else []),
                   ["Do not substitute segment revenue, a later revision, or an interim figure."]
                   + (["Do not substitute net interest income for total net revenue or invent operating income."] if t in BANKS else []),
                   "Both figures come from original-filing consolidated tags. Wording for banks checks GAAP versus managed basis.")
    if ocf and capex and capex["value"] >= 0 and t not in BANKS:
        fcf = calc("fcf", f, ocf, capex, "operating_cash_flow - capex", ocf["value"] - capex["value"], "USD millions")
        yield case(f"{label}-{YEAR}-cash-flow", [f], "check",
                   f"For {t}'s {fy} ended {f.end}, what were operating cash flow, cash paid to acquire property, plant and equipment "
                   "as a positive outflow, and free cash flow defined as the first minus the second? Show all three values.",
                   [ocf, capex, fcf], ["Define free cash flow and show both fiscal-year operands."],
                   ["Do not subtract a signed negative capex again or use investing cash flow as capex."],
                   "Free cash flow is an explicit calculation, not an issuer-defined non-GAAP metric.")
    if assets and liabilities and equity:
        yield case(f"{label}-{YEAR}-balance-sheet", [f], "check",
                   f"At {t}'s {fy} year-end ({f.end}), what were consolidated total assets, total liabilities, "
                   "and stockholders' equity attributable to the parent? Use the original annual report.",
                   [assets, liabilities, equity], ["State the as-of date; these are balance sheet amounts, not full-year flows."],
                   ["Do not use current assets, current liabilities, or equity including noncontrolling interests for these items."],
                   "Point-in-time gold uses exact instant contexts, with the parent equity tag.")
    if rev and op and rev["value"] > 0 and t not in BANKS:
        margin = calc("operating_income_to_revenue", f, op, rev, "100 * operating_income / revenue",
                      100 * op["value"] / rev["value"], "percent")
        yield case(f"{label}-{YEAR}-operating-margin", [f], "check",
                   f"For {t}'s {fy} ended {f.end}, provide reported GAAP operating income or loss and revenue, "
                   "then calculate operating margin as operating income divided by revenue. Report both inputs and the margin.",
                   [op, rev, margin], ["Show both operands and preserve the sign of any operating loss."],
                   ["Do not substitute a gross, EBITDA, net, or adjusted margin."],
                   "Operating margin has a 0.02 percentage-point tolerance; numeric operands come from the original filing.")
    if label in {"aapl", "msft", "nvda", "wmt", "cost", "tgt", "hd", "nke", "dis", "adbe", "ko", "cat"}:
        prev = source(f, "revenue", prior=True)
        if rev and prev and prev["value"] > 0:
            growth = calc("revenue_growth", f, rev, prev, "100 * (revenue_fy2025 / revenue_fy2024 - 1)",
                          100 * (rev["value"] / prev["value"] - 1), "percent")
            yield case(f"{label}-{YEAR}-revenue-growth", [f], "fiscal_period_trap",
                       f"Use the comparative annual columns in {t}'s original {fy} 10-K. Report the revenue and period end for "
                       f"each of FY{YEAR} and FY{YEAR-1}, then calculate unannualised year-over-year growth.",
                       [rev, prev, growth], ["State both fiscal year-end dates and compute growth from the displayed operands."],
                       ["Do not substitute calendar-year periods or annualise the change."],
                       "The preceding full-year value is from the same filing as the later value. Adjacent fiscal periods may not match calendar years.")
    if t in LOOKAHEAD:
        cutoff = f.filed - timedelta(days=1)
        yield case(f"{label}-{YEAR}-original-10k-not-yet-filed", [f], "look_ahead",
                   f"As of {cutoff}, what annual revenue did {t} report in the original 10-K for {fy} ending {f.end}? "
                   "Only the original 10-K is allowed; do not use press releases, earnings exhibits, or later data.",
                   [], ["Say the requested original annual filing is unavailable as of the cutoff."],
                   ["Do not reveal or cite any post-cutoff filing or report the figure using another document."],
                   f"Negative control: SEC submissions place the original filing on {f.filed}. "
                   f"Audit-only reference (after cutoff, never a gold answer): {f.url}", cutoff=cutoff)


def comparisons(found):
    for left, right in PAIRS:
        if left not in found or right not in found:
            continue
        a, b = found[left], found[right]
        assets = [source(f, "total_assets") for f in (a, b)]
        if any(g is None for g in assets):
            continue
        liabilities = [source(f, "total_liabilities") for f in (a, b)]
        use_liabilities = all(liabilities)
        gold = [g for pair in zip(assets, liabilities, strict=True) for g in pair] if use_liabilities else assets
        fields = "total assets and total liabilities" if use_liabilities else "total assets"
        winner = "State that total assets were equal."
        if assets[0]["value"] != assets[1]["value"]:
            winner = f"Identify {left if assets[0]['value'] > assets[1]['value'] else right} as reporting higher total assets."
        yield case(f"{left.lower()}-{right.lower()}-{YEAR}-compare-balance-sheet", [a, b], "clean",
                   f"Compare {left} and {right} using their original FY{YEAR} annual filings. For each company, report {fields} "
                   "at its own fiscal year-end, state the date, and identify which reports higher total assets.",
                   gold, [f"Report each company's own fiscal year-end ({left}: {a.end}; {right}: {b.end}).",
                          winner],
                   ["Do not align issuers to an invented common period or confuse current balances with totals."],
                   "Each issuer retains its own audited balance sheet date. This comparison tests cross-issuer evidence binding, not valuation.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=HERE)
    args = parser.parse_args()
    agent = os.environ.get("SEC_USER_AGENT", "")
    if "@" not in agent:
        parser.error("Set SEC_USER_AGENT to a descriptive application and a valid contact email.")
    edgar, found, skipped = Edgar(agent, args.cache), {}, {}
    for issuer in ISSUERS:
        try:
            f = filing(edgar, issuer)
        except (ValueError, httpx.HTTPError) as exc:
            skipped[issuer[0]] = f"{type(exc).__name__}: {exc}"
            print(f"Skipped {issuer[0]}: {exc}", flush=True)
        else:
            found[f.ticker] = f
            print(f"Verified FY{YEAR} filing for {f.ticker} ended {f.end}; {len(f.facts)} fact groups", flush=True)
    edgar.client.close()
    cases = [c for f in found.values() for c in per_issuer(f)] + list(comparisons(found))
    if not cases:
        raise SystemExit("No cases built; check SEC access.")
    args.out.mkdir(parents=True, exist_ok=True)
    for c in cases:
        path = args.out / f"{c['id']}.yaml"
        path.write_text(yaml.safe_dump(c, sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")
    counts = Counter(c["case_type"] for c in cases)
    provenance = {"fiscal_year": YEAR, "filings": {t: {"url": f.url, "sha256": f.sha256, "split": f.split,
                    "filed": f.filed.isoformat(), "period_end": f.end.isoformat()} for t, f in found.items()},
                  "skipped_issuers": skipped,
                  "no_cases_for_issuer": sorted(set(found) - {company["ticker"] for c in cases for company in c["companies"]}),
                  "cases": len(cases), "gold_items": sum(len(c["gold"]) for c in cases),
                  "counts_by_type": dict(counts)}
    (args.out / "provenance.json").write_text(json.dumps(provenance, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Built {len(cases)} cases, {provenance['gold_items']} gold items: {dict(counts)}")


if __name__ == "__main__":
    main()
