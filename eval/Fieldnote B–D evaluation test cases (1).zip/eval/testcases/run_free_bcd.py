#!/usr/bin/env python3
"""Run the stock evaluator with one pinned, zero-price OpenRouter model."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

import httpx
import yaml

HERE = Path(__file__).resolve().parent
EVAL = HERE.parent
BASE = "https://openrouter.ai/api/v1"
PREFERRED = ("nvidia/nemotron-3.5-lightning:free", "inclusionai/ling-3.2-flash:free",
             "google/gemma-4-26b-a4b-it:free", "nvidia/nemotron-3.5-super-vl:free")
PATHS = {"/api/v1/key", "/api/v1/chat/completions"}
STOP = {400, 401, 402, 403, 404, 408, 429, 500, 502, 503, 504}


def free(entry):
    """Require an explicit free slug, tool support, and zero listed prices."""
    price = entry.get("pricing") or {}
    if not entry.get("id", "").endswith(":free") or not {"tools", "tool_choice"} <= set(entry.get("supported_parameters") or []):
        return False
    try:
        return {"prompt", "completion"} <= price.keys() and all(
            Decimal(str(rate)) == 0 for rate in price.values() if rate is not None
        ) and price["prompt"] is not None and price["completion"] is not None
    except (InvalidOperation, TypeError):
        return False


def select_model(rows, requested):
    eligible = {row["id"]: row for row in rows if free(row) and row.get("context_length", 0) >= 131_072}
    if requested:
        if requested not in eligible:
            raise ValueError("Requested model is not in the current zero-price tool-capable catalog.")
        return eligible[requested]
    for model in PREFERRED:
        if model in eligible:
            return eligible[model]
    raise ValueError("No preferred free tool-capable model is available; inspect the catalog and choose explicitly.")


def worker():
    """Only this process inherits the stored-credential proxy; SEC tools do not."""
    with httpx.Client(timeout=httpx.Timeout(90, connect=15), follow_redirects=False) as client:
        for line in sys.stdin:
            packet = json.loads(line)
            path = packet["path"]
            if path not in PATHS or packet["method"] != ("GET" if path.endswith("/key") else "POST"):
                raise ValueError("Unsupported credential worker request.")
            try:
                response = client.request(packet["method"], f"https://openrouter.ai{path}", json=packet.get("body"))
                out = {"status": response.status_code, "content": response.text, "headers": {
                    key: val for key, val in response.headers.items()
                    if key.lower() in {"content-type", "retry-after", "x-ratelimit-reset"}}}
            except httpx.HTTPError as exc:
                out = {"network_error": type(exc).__name__}
            print(json.dumps(out), flush=True)


class Gate:
    def __init__(self, handle=None):
        self.child = None
        self.attempts = 0
        self.cap = 0
        self.last = 0.0
        self.stop = None
        if handle:
            self.child = subprocess.Popen(
                ["pplx", "credentials", "run", handle, "--", sys.executable, str(Path(__file__).resolve()), "--worker"],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, encoding="utf-8",
            )
        else:
            key = os.environ.get("OPENROUTER_API_KEY")
            if not key:
                raise ValueError("Set OPENROUTER_API_KEY securely or use --credential-handle.")
            self.client = httpx.Client(headers={"Authorization": f"Bearer {key}"},
                                       timeout=httpx.Timeout(90, connect=15), follow_redirects=False)

    def request(self, method, path, body=None):
        if self.child:
            try:
                self.child.stdin.write(json.dumps({"method": method, "path": path, "body": body}) + "\n")
                self.child.stdin.flush()
                line = self.child.stdout.readline()
            except (OSError, BrokenPipeError) as exc:
                raise httpx.TransportError("Credential worker exited.") from exc
            if not line:
                raise httpx.TransportError("Credential worker returned no result.")
            response = json.loads(line)
            if response.get("network_error"):
                raise httpx.TransportError(response["network_error"])
            return httpx.Response(response["status"], text=response["content"], headers=response["headers"])
        return self.client.request(method, f"https://openrouter.ai{path}", json=body)

    def transport(self, request):
        if request.method != "POST" or request.url.host != "openrouter.ai" or request.url.path != "/api/v1/chat/completions":
            raise ValueError("Blocked non-OpenRouter completion request.")
        if self.stop or self.attempts >= self.cap:
            self.stop = self.stop or "local_request_budget_exhausted"
            return httpx.Response(429, json={"error": {"message": self.stop}})
        body = json.loads(request.content)
        if body.get("model") != self.model or "models" in body or "plugins" in body:
            raise ValueError("Blocked unpinned model or extra service.")
        provider = body.setdefault("provider", {})
        provider.update(require_parameters=True, allow_fallbacks=True, max_price={"prompt": 0, "completion": 0, "request": 0})
        time.sleep(max(0, 3.2 - (time.monotonic() - self.last)))
        self.last = time.monotonic()
        self.attempts += 1
        try:
            reply = self.request("POST", request.url.path, body)
        except httpx.TransportError:
            self.stop = "network_outcome_unknown"
            raise
        if reply.status_code in STOP or reply.status_code >= 400:
            self.stop = f"provider_http_{reply.status_code}"
        return reply

    def close(self):
        if self.child:
            self.child.stdin.close()
            try:
                self.child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.child.terminate()
                self.child.wait(timeout=5)
        else:
            self.client.close()


def dump(path, data):
    temp = path.with_suffix(f"{path.suffix}.tmp")
    temp.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def safe_quota(gate):
    status = gate.request("GET", "/api/v1/key")
    if status.status_code != 200:
        raise ValueError(f"OpenRouter key preflight returned HTTP {status.status_code}.")
    raw = status.json().get("data", {}).get("free_model_daily_requests") or {}
    return {k: v for k in ("used", "limit", "remaining") if type(v := raw.get(k)) is int and v >= 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--credential-handle", help="Optional approved Perplexity custom-credential handle.")
    parser.add_argument("--model", help="Explicit free model. All conditions and roles use the same model.")
    parser.add_argument("--case-dir", type=Path, default=HERE)
    parser.add_argument("--cases", help="Comma-separated IDs; defaults to a smoke test, or the selected split with --all.")
    parser.add_argument("--all", action="store_true", help="Plan all cases in --split, stopping at the same request cap.")
    parser.add_argument("--split", choices=("dev", "held_out", "all"), default="dev")
    parser.add_argument("--out", type=Path, required=True, help="New private batch output directory.")
    parser.add_argument("--max-requests", type=int, default=40, help="Hard ceiling on dispatched completion requests.")
    parser.add_argument("--quota-only", action="store_true", help="Verify credentials, model and quota without making a completion request.")
    args = parser.parse_args()
    if args.max_requests < 1:
        parser.error("--max-requests must be at least 1.")
    if args.cases and args.all:
        parser.error("Use --cases or --all, not both.")
    sys.path.insert(0, str(EVAL))
    import run_eval
    import score
    import live_discover
    from openai import OpenAI
    from research_assistant import cli, config
    from research_assistant.model_access import ModelSettings

    cases = score.load_cases(args.case_dir)
    default = "dev-ext-aapl-2025-income,dev-ext-jpm-2025-original-10k-not-yet-filed,dev-ext-aapl-msft-2025-compare-balance-sheet"
    chosen = list(cases.values()) if args.all and args.split == "all" else run_eval.pick(
        cases, args.cases or (None if args.all else default), args.split)
    if not chosen:
        parser.error("No selected cases.")
    if args.all:
        chosen.sort(key=lambda c: (c.get("live_priority", 999), c["id"]))
    if any(c["mode"] not in {"check", "compare", "discover"} or
           (c["mode"] == "discover" and not c.get("discovery")) for c in chosen):
        parser.error("Discover cases require an explicit discovery fixture with a declared universe.")
    catalog = httpx.get(f"{BASE}/models", timeout=20)
    catalog.raise_for_status()
    model = select_model(catalog.json()["data"], args.model)
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    gate = Gate(args.credential_handle)
    gate.model = model["id"]
    plan = [(case, cond) for case in chosen for cond in "BCD"]
    meta = {"observed_utc": datetime.now(timezone.utc).isoformat(), "provider": "openrouter",
            "model": model["id"], "model_pricing": model["pricing"], "context_length": model["context_length"],
            "conditions": list("BCD"), "selected_cases": [c["id"] for c in chosen],
            "planned_runs": len(plan), "requested_completion_cap": args.max_requests,
            "shim_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "dispatch_count": 0}
    attempted = set()
    try:
        quota = safe_quota(gate)
        meta["free_quota_before"] = quota
        gate.cap = min(args.max_requests, quota.get("remaining", 0))
        meta["completion_request_cap"] = gate.cap
        if "remaining" not in quota:
            gate.stop = "free_quota_not_reported"
        elif gate.cap == 0:
            gate.stop = "account_free_daily_quota_exhausted"
        elif args.quota_only:
            gate.stop = "quota_only"
        elif "@" not in os.environ.get("SEC_USER_AGENT", ""):
            gate.stop = "sec_user_agent_missing"
        if gate.stop:
            return 0 if gate.stop == "quota_only" else 2

        config.AGENT_BAD_REPLY_RETRIES = 0
        settings = ModelSettings("openrouter", "OpenRouter", model["id"], "unused-transport-placeholder", BASE)
        if problem := run_eval.check_manifest(out, run_eval.manifest(settings, chosen, args.case_dir)):
            raise ValueError(problem)
        with cli.sec_client() as sec, OpenAI(api_key="unused-transport-placeholder", base_url=BASE,
                max_retries=0, http_client=httpx.Client(transport=httpx.MockTransport(gate.transport))) as model_client:
            for c, condition in plan:
                if gate.stop or gate.attempts >= gate.cap:
                    gate.stop = gate.stop or "local_request_budget_exhausted"
                    break
                attempted.add((c["id"], condition))
                print(f"\n== {c['id']}: {condition}", file=sys.stderr, flush=True)
                if c["mode"] == "discover":
                    live_discover.run_case(c, condition, out, model_client, settings, sec)
                else:
                    run_eval.run_case(c, condition, 1, out, model_client, settings, sec)
        return 0 if not gate.stop else 2
    except (ValueError, httpx.HTTPError) as exc:
        gate.stop = gate.stop or f"preflight_or_runner_error_{type(exc).__name__}"
        print(str(exc), file=sys.stderr)
        return 2
    finally:
        meta.update(dispatch_count=gate.attempts, stop_reason=gate.stop, started_runs=len(attempted))
        rows = []
        discovery_rows = []
        for entry in score.read_index(out):
            case = cases[entry["case"]]
            if case["mode"] == "discover":
                discovery_rows.append(live_discover.score_run(case, entry, out))
            else:
                rows.append(score.score_run(case, entry, out))
        if rows:
            score.write(out, rows, cases)
        if discovery_rows:
            dump(out / "discovery_scores.json", discovery_rows)
        by_run = {(r["case"], r["condition"]): {
            "status": r["status"], "auto_pass": r["passed"] if r["ended"] else None,
            "gold_correct": sum(g["outcome"] == "correct" for g in r["gold"]) if r["ended"] else None,
            "gold_total": len(r["gold"]), "model_calls": (r.get("totals") or {}).get("model_calls"),
        } for r in rows}
        by_run.update({(r["case"], r["condition"]): {
            "status": r["status"], "auto_pass": None, "screen_auto_pass": r["screen_auto_pass"],
            "model_calls": (r.get("totals") or {}).get("model_calls"),
        } for r in discovery_rows})
        meta["status_by_case"] = {c["id"]: {cond: by_run.get((c["id"], cond), {
            "status": "not_run", "auto_pass": None,
            **({"screen_auto_pass": None} if c["mode"] == "discover" else {}),
        }) for cond in "BCD"} for c in chosen}
        dump(out / "free_run_status.json", meta)
        # Keep result mirrors outside the input fixture folder, so --case-dir never ingests a score as gold.
        mirrors = out / "case_results"
        mirrors.mkdir(exist_ok=True)
        for c in chosen:
            data = c | {"evaluation": {"model": model["id"], "conditions": meta["status_by_case"][c["id"]],
                                      "manual_review_complete": False}}
            (mirrors / f"{c['id']}.yaml").write_text(
                yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")
        gate.close()
        print(f"OpenRouter: {model['id']}; requests dispatched: {gate.attempts}; status: {gate.stop or 'completed'}")


if __name__ == "__main__":
    if sys.argv[1:] == ["--worker"]:
        worker()
    else:
        sys.exit(main())
