# Fieldnote B–D evaluation results

## Latest OpenRouter attempt: mixed-mode suite

The newly supplied, securely saved credential authenticated to OpenRouter. At 13:41 UTC on 25 November 2026, the provider reported **51 used, a 50-request daily limit, and 0 remaining** for free variants. That counter is separate from the key's spending limit; a successful key check or a positive spending limit does not authorize a free completion ([OpenRouter budget and rate-limit documentation](https://openrouter.ai/docs/api_reference/limits)).

| New challenge fixtures | Cases | Planned B–D assignments | Started |
|---|---:|---:|---:|
| Check | 13 | 39 | 0 |
| Compare | 1 | 3 | 0 |
| Discover | 8 | 24 | 0 |
| Total | 22 | 66 | 0 |

**Observed outcome: zero model requests and no live scores.** The batch wrote `results/openrouter-2026-11-25/free_run_status.json` and 22 case-shaped `case_results/*.yaml` files. Every B/C/D entry is `not_run` with null scores, not a failed case or an abstention. The 22 new fixtures in `live/` are additional to the 111-case extension below; the 14 named-stock prompts adapt existing filing-backed gold and are not independent labels. The eight Discovery prompts exercise exact filters, ranking direction, an undefined term, impossible thresholds, bank metric gaps and historical refusal. Discovery checks screen behavior separately from numeric answer accuracy.

### Model selection

- **First choice:** [`nvidia/nemotron-3.5-lightning:free`](https://openrouter.ai/nvidia/nemotron-3.5-lightning:free), listed at zero cost with function calling and a 1M-token context; a candidate for high-throughput multi-step runs, not a measured winner.
- **Alternatives for separate matched batches:** [`inclusionai/ling-3.2-flash:free`](https://openrouter.ai/inclusionai/ling-3.2-flash:free) and [`google/gemma-4-26b-a4b-it:free`](https://openrouter.ai/google/gemma-4-26b-a4b-it:free), both flagged in the [OpenRouter model catalog](https://openrouter.ai/api/v1/models?supported_parameters=tools) for tool calls and zero listed prices. No candidate was measured for latency, token use, or accuracy in this attempt.

Retry only after the authenticated free allowance is positive, with one pinned model for B, C and D. Prioritize a Check, a positive Discover case, a cutoff test, and a conflicting-filing case before broadening the run. For model comparisons, compare fixed models on the same completed triplets and track model calls, completion tokens, elapsed time, and evidence correctness. Leave infrastructure stops and incomplete triplets visible.

## Earlier 111-case extension

The earlier extension adds **111 schema-compatible cases** in `eval/testcases/`, with 275 labeled gold items across 27 issuers. It contains 98 Check cases and 13 Compare cases, and no Discover cases. All 171 distinct directly sourced facts matched the original accession, period, currency and value in [SEC EDGAR Companyfacts](https://www.sec.gov/search-filings/edgar-application-programming-interfaces); derived items were checked separately for their formulas.

| Verification | Observed |
|---|---:|
| Upstream repository tests passed | 795 |
| Extension tests passed | 115 |
| Distinct original-filing facts corroborated | 171 / 171 |
| Planned live B–D runs | 333 |
| Live completion requests dispatched | 0 |
| New live B–D scores | Not available |

### Earlier OpenRouter preflight

The authenticated status check returned zero free requests remaining out of a daily limit of 50 on 25 November 2026. The runner stopped before its first completion request. The catalog showed `nvidia/nemotron-3.5-lightning:free` as a zero-price tool-enabled candidate ([OpenRouter model card](https://openrouter.ai/nvidia/nemotron-3.5-lightning:free)). No paid endpoint, alternate credential, or simulated model score was used to fill the live results.

## Historical archive, separately rescored

These counts concern only the previously supplied project archive and original `eval/cases` fixtures, not the 111 new fixtures. The recheck used the current repository scorer on completed historical outputs with linked raw traces.

| Condition | Archived completions | Trace-backed completions rescored | Automated passes in rescored subset | Correct gold in rescored subset |
|---|---:|---:|---:|---:|
| B: Single agent | 12 | 9 | 4 / 9 | 19 / 32 |
| C: Analyst team | 4 | 1 | 1 / 1 | 3 / 3 |
| D: Analyst team with critic | 4 | 1 | 1 / 1 | 3 / 3 |

All 11 trace-backed automated verdicts match their saved verdicts. Nine further completions have saved scores but no linked raw trace for rescoring. The unequal, selectively available sample is not a comparison of condition accuracy. Automated passes and gold matches are not manual factual adjudication. See `results/archived-bcd-rescore.yml` for the case-by-condition record.
