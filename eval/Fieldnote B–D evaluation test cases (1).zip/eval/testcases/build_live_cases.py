"""Build a mixed-mode challenge set without using model outputs as gold."""

import argparse
from collections import Counter
from datetime import date
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
OUT = HERE / "live"
LABEL_DATE = date(2026, 11, 25)

# Prompt variants inherit only the cited filing evidence and applicable grading criteria.
NAMED = [
    (10, "apple-consolidated-v-segments", "dev-ext-aapl-2025-income",
     "For Apple FY2025, I have a spreadsheet that treats one business segment as company revenue. "
     "What consolidated revenue and parent net income belong in the company-wide row? Use the original annual filing."),
    (30, "nvidia-before-original", "dev-ext-nvda-2025-original-10k-not-yet-filed",
     "I know the full-year NVIDIA filing surfaced later. At the cutoff, could you cite fiscal 2025 revenue "
     "from the original 10-K? Restrict the answer to what was public by the cutoff."),
    (40, "microsoft-two-revenue-versions", "dev-restatement-msft-fy2016-revenue",
     "My notes give two different revenue totals for the same Microsoft fiscal year ended June 2016. "
     "Reconcile the original and restated figures, explain why they differ, and name each filing."),
    (60, "visa-unavailable-metric", "dev-missing-v-fy2023-gross-margin",
     "Fill a Visa FY2023 comparison row with the requested gross profit and gross margin if the filing supports them. "
     "If it does not, mark them unavailable; also give reported net revenues as the reference figure."),
    (80, "consolidated-retail-cash-flow", "dev-ext-wmt-2025-cash-flow",
     "What did Walmart report for consolidated operating cash flow and capital expenditures in its original fiscal 2025 "
     "10-K? Calculate free cash flow as the difference and show the inputs, not a company-defined substitute."),
    (100, "costco-genuine-growth", "held-trap-cost-fy2023-53-week-growth",
     "A colleague calls Costco FY2023 total revenue growth a like-for-like comparison. Check that claim against both "
     "fiscal periods and report the two total revenues and reported growth rate."),
    (110, "two-banks-comparable-balance-sheets", "dev-ext-jpm-bac-2025-compare-balance-sheet",
     "Compare JPMorgan Chase and Bank of America on total assets and total liabilities at their FY2025 year-ends. "
     "Use each original annual filing and keep the issuer and balance-sheet date attached to each value."),
    (120, "check-clear-disclosure", "held-vals-net-2024-channel-partners",
     "I was told Cloudflare did not disclose how much FY2024 revenue came from channel partners. "
     "Check the 10-K notes. Give the disclosed share and dollar amount if present, the consolidated revenue "
     "denominator, and the note number."),
    (130, "best-buy-unequal-periods", "held-trap-bby-fiscal-2019-revenue",
     "For a Best Buy trend chart, give FY2019 revenue, the FY2018 comparison revenue, and FY2019 percentage growth. "
     "Can I describe those fiscal periods as directly comparable in length? Use the annual filing."),
    (140, "retrospective-airbnb", "held-missing-abnb-2019-not-yet-filed",
     "Freeze the information set on 30 June 2020. Could a researcher source Airbnb FY2019 revenue "
     "from a public SEC filing at that time? Do not use events or filings learned later."),
    (150, "bank-operating-margin", "dev-bank-jpm-2023",
     "For JPMorgan Chase FY2023, report GAAP total net revenue and net income. "
     "Can its filing support the same operating-margin calculation used for an industrial firm?"),
    (160, "calendar-label-versus-fiscal", "dev-trap-nvda-fiscal-2024-revenue",
     "I am labelling NVIDIA annual financials by fiscal year. Provide FY2024 total revenue and the exact fiscal "
     "end date; explain why using a calendar 2024 total or FY2025 would mislabel it."),
    (170, "similarly-named-metrics", "held-clean-cat-2023",
     "In Caterpillar's FY2023 results, what were sales and revenues, operating profit, and profit attributable to common shareholders? "
     "Do not treat consolidated-and-affiliated profit, EPS, or an estimate derived from EPS as the requested profit."),
    (180, "unknown-isnt-zero", "dev-unknown-ticker-qzxv",
     "Can you source annual revenue for ticker QZXV? Check whether it identifies an SEC issuer before giving "
     "a number; leave it unavailable if the issuer cannot be verified."),
]

COMPANIES = {
    "AAPL": (320193, "Apple Inc."), "MSFT": (789019, "Microsoft Corporation"),
    "NVDA": (1045810, "NVIDIA Corporation"), "AMD": (2488, "Advanced Micro Devices, Inc."),
    "KO": (21344, "The Coca-Cola Company"), "PEP": (77476, "PepsiCo, Inc."),
    "JPM": (19617, "JPMorgan Chase & Co."), "BAC": (70858, "Bank of America Corporation"),
    "XOM": (34088, "Exxon Mobil Corporation"), "CVX": (93410, "Chevron Corporation"),
    "COST": (909832, "Costco Wholesale Corporation"), "WMT": (104169, "Walmart Inc."),
}

DISCOVER = [
    (20, "positive-operating-margin", "AAPL MSFT", "Find up to one company with annual operating margin above 5%. "
     "Rank by operating margin, highest first.", [("operating_margin", ">", 0.05)], "operating_margin", True, 1, (1, 1)),
    (50, "impossible-net-margin", "KO PEP", "Find up to one company with annual net margin above 500%. "
     "Rank by net margin, highest first.", [("net_margin", ">", 5.0)], "net_margin", True, 1, (0, 0)),
    (70, "historic-margin", "AAPL MSFT", "As of June 30, 2024, find up to one company with annual operating margin "
     "above 5%. Rank by operating margin, highest first.", [("operating_margin", ">", 0.05)],
     "operating_margin", True, 1, None),
    (90, "vague-profitability", "COST WMT", "Find up to one highly profitable company. If I have not defined highly "
     "profitable, explain the definition you would use.", None, None, None, 1, (0, 1)),
    (190, "combined-thresholds", "NVDA AMD", "Find up to one company with annual revenue growth above 3% and "
     "annual operating margin above 3%. Rank by revenue growth, highest first.",
     [("revenue_growth", ">", 0.03), ("operating_margin", ">", 0.03)], "revenue_growth", True, 1, (1, 1)),
    (200, "unsupported-bank-margin", "JPM BAC", "Find up to one company with annual operating margin above 100%, "
     "ranked by operating margin, highest first. Do not estimate a missing operating income.",
     [("operating_margin", ">", 1.0)], "operating_margin", True, 1, (0, 0)),
    (210, "ascending-revenue", "XOM CVX", "Find up to one company with positive annual revenue. Rank by annual "
     "revenue, smallest first.", [("revenue", ">", 0)], "revenue", False, 1, (1, 1)),
    (220, "historic-growth", "KO PEP", "As of June 30, 2024, find up to one company with positive annual revenue "
     "growth. Rank by revenue growth, highest first.", [("revenue_growth", ">", 0)],
     "revenue_growth", True, 1, None),
]


def generate(out):
    out.mkdir(parents=True, exist_ok=True)
    review = {"labelled_by": "Fieldnote evaluation fixture author", "labelled_on": LABEL_DATE,
              "checked_by": None, "check_note": None}
    generated = []
    for priority, slug, origin, question in NAMED:
        source = HERE / f"{origin}.yaml" if "-ext-" in origin else HERE.parent / "cases" / f"{origin}.yaml"
        case = yaml.safe_load(source.read_text(encoding="utf-8"))
        case.update(id=f"live-{slug}", split="dev", live_priority=priority, question=question,
                    source=f"Prompt variant of {origin}; existing SEC filing sources retained.",
                    review=review, notes=f"Related prompt variant, not independent evidence. {case['notes']}",
                    inherits_gold_from=origin)
        case.pop("related", None)
        generated.append(case)
    for priority, slug, names, question, filters, rank, descending, top_k, bounds in DISCOVER:
        companies = [{"ticker": t, "cik": COMPANIES[t][0], "name": COMPANIES[t][1]} for t in names.split()]
        checks = {"top_k": top_k}
        if filters is not None:
            checks.update(filters=[{"metric": m, "op": o, "value": v} for m, o, v in filters],
                          rank_by=rank, descending=descending)
        else:
            checks["disclose_assumption"] = True
        if bounds is None:
            checks["historical_refusal"] = True
        else:
            checks["picks_range"] = list(bounds)
        generated.append({
            "id": f"live-discover-{slug}", "split": "dev", "live_priority": priority,
            "case_type": "look_ahead" if bounds is None else "impossible_filter" if bounds == (0, 0) else "check",
            "mode": "discover", "source": "Hand-authored declared-list screen; public SEC evidence at runtime.",
            "question": f"From the declared list ({names}), {question[0].lower()}{question[1:]}",
            "cutoff": date(2024, 6, 30) if bounds is None else LABEL_DATE,
            "companies": companies, "expected": {
                "behaviour": "not_available" if bounds is None or bounds == (0, 0) else "answer_or_abstain",
                "must_mention": ["Disclose screening and recheck scope; missing observations are not zero."] +
                (["Refuse to use present-day SEC Frames as a point-in-time screen."] if bounds is None else []),
                "must_not": ["Do not invent a qualifying issuer or use a name outside the declared list."]},
            "gold": [], "review": review,
            "notes": "Open-world candidate quality and prose require review. Only the declared rule, recheck and "
                     "candidate-count expectation are automated. Live runs use their actual issue time.",
            "discovery": {"universe": f"Evaluation list: {names}", "time_mode": "historical" if bounds is None else "live",
                          "checks": checks},
        })
    for case in generated:
        (out / f"{case['id']}.yaml").write_text(
            yaml.safe_dump(case, sort_keys=False, allow_unicode=True, width=110), encoding="utf-8")
    print(dict(Counter(case["mode"] for case in generated)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=OUT)
    generate(parser.parse_args().out)
