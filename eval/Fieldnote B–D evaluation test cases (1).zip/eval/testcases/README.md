# Fieldnote B–D evaluation extension

This folder targets [Fieldnote at `52484a9`](https://github.com/ivan00105/Agentic-System-for-Investment-Research/tree/52484a9994d7361ed6745c2d58e5807cae220cef). It preserves the original 111 extension fixtures and adds 22 mixed-mode challenges in `live/`. Named-stock cases follow [`dev-bank-jpm-2023.yaml`](https://github.com/ivan00105/Agentic-System-for-Investment-Research/blob/52484a9994d7361ed6745c2d58e5807cae220cef/eval/cases/dev-bank-jpm-2023.yaml); Discover cases add a field for their declared universe and screen checks. The original repository fixtures and agents are unchanged. The `held_out` labels in the 111-case extension mean a separate issuer split within that extension, not a sealed or contamination-free benchmark.

## Mixed-mode challenge set

The new set has 13 Check, one Compare, and eight Discover cases; overlapping gold is marked with `inherits_gold_from`. Discover consumes only the question, declared universe and relevant cutoff, not the expected screen. Its separate `discovery_scores.json` checks the structured screen, recheck status, and candidate counts, not candidate prose or independent market recall. Historical screens must refuse to use current SEC Frames. For live Discover cases the fixture date is the authoring date; the runner uses and records the actual issue time.

The most recent authenticated preflight stopped before dispatch. See [the results](RESULTS.md) and the case-shaped `results/openrouter-2026-11-25/case_results/` for all 66 `not_run` assignments.

```bash
python eval/testcases/build_live_cases.py
python -m pytest -q eval/testcases/test_live_suite.py
python eval/testcases/run_free_bcd.py \
  --case-dir eval/testcases/live --all --split all \
  --model nvidia/nemotron-3.5-lightning:free \
  --max-requests 1000 --out data/eval/mixed-bcd
```

Install the test dependencies and configure the secret and SEC contact as described below before running these commands. `--max-requests` is only a hard ceiling; the runner clamps it to the available provider quota.

## Earlier 111-case extension

| Split | Check | Compare | Total | Planned B–D runs |
|---|---:|---:|---:|---:|
| Development | 50 | 7 | 57 | 171 |
| Held-out extension | 48 | 6 | 54 | 162 |
| Total | 98 | 13 | 111 | 333 |

There are 101 answerable cases and 10 no-filing-at-cutoff controls across 27 issuers. The answer keys have 225 sourced entries (171 distinct issuer/concept/end-date/accession facts) and 50 calculated entries. Gold comes from original SEC annual filings, not model outputs or Fieldnote tools. Direct extraction preserves consolidated scope, dates, sign, unit, accession and document link. All 171 distinct facts were corroborated against [SEC EDGAR Companyfacts](https://www.sec.gov/search-filings/edgar-application-programming-interfaces). This is a second extraction path for the same filings, not an independent human audit. Omitted or ambiguous tags are not filled with estimates; `provenance.json` records the issuer with no qualifying extracted case.

Each fixture includes `question`, `cutoff`, `companies`, `expected`, `gold`, `review` and `notes`. Refer to [the run summary](RESULTS.md) for observed versus planned results.

## Run from the repository root

Extract the ZIP into the repository root, so it creates `eval/testcases/`. Install the repository and test dependencies in a Python 3.12 environment. Set `SEC_USER_AGENT` to a project label and valid contact email. Configure a fresh `OPENROUTER_API_KEY` in a local secret manager or environment without saving it in source control, or provide an approved `--credential-handle` in a supported Computer session. The runner sends the public research question and retrieved evidence to OpenRouter, never the answer key. It uses the same fixed model across all roles and conditions.

```bash
python -m pip install -e '.[test]'

# Offline schema, arithmetic, routing and mock pipeline verification.
python -m pytest -q eval/testcases/test_extension.py

# One matched B/C/D triplet; choose a fresh --out directory for each launch.
python eval/testcases/run_free_bcd.py \
  --cases dev-ext-aapl-2025-income \
  --out data/eval/ext-smoke \
  --max-requests 40

# Broader run, in matched B/C/D order per case; still stops at quota or cap.
python eval/testcases/run_free_bcd.py \
  --all --split dev \
  --out data/eval/ext-dev \
  --max-requests 50
```

Use `--all --split all` to plan the full 333 condition–case assignments. Use `--quota-only` to check the current model and account quota without inference. The hard cap counts model requests, not cases: a condition may use multiple requests, with additional analyst or critic calls in C/D. A budget stop can leave a triplet incomplete; compare conditions only on a matched completed subset and report missing runs separately. Do not combine batches with different models or settings into a single ablation without stratifying them.

The runner checks live catalog pricing and supports only an explicit zero-price `:free` model with function calling. The preflight preferred [Nemotron 3.5 Lightning (free)](https://openrouter.ai/nvidia/nemotron-3.5-lightning:free) for its context window and throughput-oriented design. This is a selection heuristic, not a measured performance improvement. The runner rejects paid models and extra plugins, caps provider prices, paces requests, disables retries, and stops on provider limits rather than switching keys. See [OpenRouter's account limits](https://openrouter.ai/docs/api_reference/limits).

With live quota, a batch writes `free_run_status.json`, raw private traces, upstream `scores.json` and `scores.md`, reports, and `case_results/*.yaml` (case template plus a separate `evaluation` block). Review prose/citations against the filings; the scorer does not adjudicate the `must_mention` and `must_not` rules. Keep batch traces in ignored `data/eval/`, not in the test fixture folder.

## Rebuild or rescore offline

The original cases remain under `eval/cases/`; the new files require `--case-dir eval/testcases` if you rescore with the stock CLI.

```bash
python -m pip install lxml
python eval/testcases/build_cases.py --cache data/eval/sec-extension-cache
python eval/testcases/check_sec_gold.py \
  --cache data/eval/sec-extension-cache \
  --out eval/testcases/results/sec-gold-crosscheck.json

python eval/run_eval.py --case-dir eval/testcases --rescore data/eval/ext-smoke
python eval/testcases/rescore_archive.py /path/to/experiments/results/bcd \
  --out data/eval/archived-bcd-rescore.yml
```

The historical rescoring command uses the project’s original archive and original case files. It cannot generate new model answers. The ZIP includes the resulting score summary, not the raw archive or traces.
