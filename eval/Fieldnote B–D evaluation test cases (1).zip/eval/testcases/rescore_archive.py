#!/usr/bin/env python3
"""Rescore trace-backed historical runs only; never infer a result from a missing trace."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import score


def brief(row):
    gold = row["gold"]
    totals = row.get("totals") or {}
    return {"status": row["status"], "auto_pass": row["passed"] if row["ended"] else None,
            "gold_correct": sum(g["outcome"] == "correct" for g in gold) if row["ended"] else None,
            "gold_total": len(gold), "model_calls": totals.get("model_calls"), "minutes": row["minutes"]}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("archive_bcd", type=Path, help="Original archive directory experiments/results/bcd, containing NEM* batches.")
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    cases = score.load_cases()
    historical = {}
    for folder in sorted(args.archive_bcd.glob("NEM*")):
        if not (folder / "scores.json").is_file():
            continue
        for saved in json.loads((folder / "scores.json").read_text(encoding="utf-8")):
            key = saved["case"], saved["condition"]
            if not saved["ended"] or saved["condition"] not in "BCD" or saved["case"] not in cases:
                continue
            if key in historical and historical[key][1]["trace"] != saved["trace"]:
                raise ValueError(f"Multiple archived completed traces for {key}; selection requires review.")
            if key not in historical or (folder / saved["trace"]).is_file():
                historical[key] = folder, saved
    if not historical:
        raise SystemExit("No eligible historical completion was found.")

    summary = {"provenance": "Prior experiment archive, not a new OpenRouter run; original eval/cases only.",
               "missing_trace_policy": "Treat missing linked trace as unverified, not a fail or fresh score.",
               "conditions": {}, "cases": {}}
    for cond in "BCD":
        archived = rescored_ended = agree = correct = total = passes = 0
        for (case_id, k), (folder, row) in sorted(historical.items()):
            if k != cond:
                continue
            archived += 1
            item = {"archive_batch": folder.name, "archived_claim": brief(row)}
            if not (folder / row["trace"]).is_file():
                item["offline_rescore"] = None
                item["trace_status"] = "missing"
            else:
                fresh = score.score_run(cases[case_id], row, folder)
                item["offline_rescore"] = brief(fresh)
                item["trace_status"] = "available"
                item["verdict_matches_saved"] = row["passed"] == fresh["passed"]
                rescored_ended += int(fresh["ended"])
                agree += int(item["verdict_matches_saved"])
                passes += int(fresh["passed"])
                if fresh["ended"]:
                    correct += item["offline_rescore"]["gold_correct"]
                    total += item["offline_rescore"]["gold_total"]
            summary["cases"].setdefault(case_id, {})[cond] = item
        summary["conditions"][cond] = {
            "archived_completions": archived, "trace_rescored_completions": rescored_ended,
            "trace_rescored_auto_pass": passes, "trace_rescored_gold_correct": correct,
            "trace_rescored_gold_total": total, "trace_rescored_same_auto_verdict": agree}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(yaml.safe_dump(summary, sort_keys=False), encoding="utf-8")
    print(json.dumps(summary["conditions"], indent=2))


if __name__ == "__main__":
    main()
