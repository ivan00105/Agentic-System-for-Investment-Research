"""Offline case-schema, gold arithmetic and free-routing checks."""

from collections import defaultdict
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys

import httpx
import pytest
import yaml

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1] / "tests"))
import run_free_bcd
import test_eval_cases as original

CASES = tuple(sorted(HERE.glob("*.yaml")))


@pytest.mark.parametrize("path", CASES, ids=lambda path: path.stem)
def test_schema_and_gold(path):
    original.test_case_has_required_fields_and_types(path)
    c = original.load(path)
    assert c["id"] == path.stem
    assert path.name not in {p.name for p in original.CASES}
    items = {item["name"]: item for item in c["gold"]}
    for item in items.values():
        if not (d := item.get("derived")):
            continue
        a, b = (Decimal(str(items[n]["value"])) for n in d["inputs"])
        expected = {"fcf": lambda: a - b, "operating_income_to_revenue": lambda: 100 * a / b,
                    "revenue_growth": lambda: 100 * (a / b - 1)}[item["metric"]]()
        assert abs(expected - Decimal(str(item["value"]))) <= Decimal("0.0000006")
    if c["case_type"] == "look_ahead":
        provenance = json.loads((HERE / "provenance.json").read_text(encoding="utf-8"))
        filing = provenance["filings"][c["companies"][0]["ticker"]]
        assert c["cutoff"].isoformat() < filing["filed"]
        assert not c["gold"]


def test_split_and_original_document_provenance():
    provenance = json.loads((HERE / "provenance.json").read_text(encoding="utf-8"))
    assert len(CASES) == provenance["cases"]
    assert sum(len(original.load(p)["gold"]) for p in CASES) == provenance["gold_items"]
    splits = defaultdict(set)
    for path in CASES:
        case = original.load(path)
        for company in case["companies"]:
            splits[company["ticker"]].add(case["split"])
        for item in case["gold"]:
            if source := item.get("source"):
                filing = provenance["filings"][item["ticker"]]
                assert filing["url"] == source["url"]
                assert filing["filed"] == source["filed"].isoformat()
                assert len(bytes.fromhex(filing["sha256"])) == hashlib.sha256().digest_size
    assert all(len(split) == 1 for split in splits.values())


def candidate(model, **prices):
    return {"id": model, "pricing": {"prompt": "0", "completion": "0"} | prices,
            "context_length": 262144, "supported_parameters": ["tools", "tool_choice"]}


def test_model_selection_is_explicit_and_zero_price():
    model = run_free_bcd.PREFERRED[0]
    eligible = candidate(model)
    assert run_free_bcd.select_model([eligible], None) == eligible
    for ineligible in (candidate("paid/model"), candidate(model, request="0.01"), candidate(model, prompt=None),
                       eligible | {"supported_parameters": ["tools"]}):
        with pytest.raises(ValueError, match="zero-price tool-capable"):
            run_free_bcd.select_model([ineligible], ineligible["id"])


def test_gate_checks_hard_cap_and_never_swaps_models(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "test-placeholder")
    gate = run_free_bcd.Gate()
    gate.cap, gate.model = 1, run_free_bcd.PREFERRED[0]
    sent = []
    monkeypatch.setattr(gate, "request", lambda method, path, body: sent.append(body) or httpx.Response(200, json={}))
    url = f"{run_free_bcd.BASE}/chat/completions"
    try:
        with pytest.raises(ValueError, match="unpinned"):
            gate.transport(httpx.Request("POST", url, json={"model": "paid/model"}))
        req = httpx.Request("POST", url, json={"model": gate.model})
        assert gate.transport(req).status_code == 200
        assert sent[0]["provider"]["max_price"] == {"prompt": 0, "completion": 0, "request": 0}
        assert gate.transport(req).status_code == 429
        assert len(sent) == gate.attempts == 1
    finally:
        gate.close()


def test_bcd_runner_end_to_end_with_mocked_provider(monkeypatch, tmp_path):
    """Exercise the unchanged B/C/D implementation, scoring and status persistence offline."""
    model = run_free_bcd.PREFERRED[0]
    monkeypatch.setenv("OPENROUTER_API_KEY", "test-placeholder")
    monkeypatch.setenv("SEC_USER_AGENT", "Local test test@example.invalid")
    monkeypatch.setattr(run_free_bcd.time, "sleep", lambda _: None)
    monkeypatch.setattr(run_free_bcd.httpx, "get", lambda *a, **k: httpx.Response(
        200, request=httpx.Request("GET", "https://openrouter.ai/api/v1/models"), json={"data": [candidate(model)]}))
    called = []

    def fake_request(self, method, path, body=None):
        if method == "GET":
            return httpx.Response(200, json={"data": {"free_model_daily_requests": {"used": 0, "remaining": 50, "limit": 50}}})
        called.append(body)
        tools = {t["function"]["name"] for t in body.get("tools", [])}
        message = {"role": "assistant", "content": "Check the original filing date."}
        if tools:
            name = "submit_objections" if "submit_objections" in tools else "submit_report"
            args = {"objections": []} if name == "submit_objections" else {"limitations": ["No eligible filing at the cutoff."]}
            message = {"role": "assistant", "content": None, "tool_calls": [{"id": f"call_{len(called)}",
                "type": "function", "function": {"name": name, "arguments": json.dumps(args)}}]}
        return httpx.Response(200, json={"id": f"mock_{len(called)}", "created": 1, "model": model,
            "object": "chat.completion", "choices": [{"index": 0, "message": message,
                "finish_reason": "tool_calls" if tools else "stop"}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}})

    monkeypatch.setattr(run_free_bcd.Gate, "request", fake_request)
    case_id = "dev-ext-jpm-2025-original-10k-not-yet-filed"
    out = tmp_path / "offline-mock"
    monkeypatch.setattr(sys, "argv", ["run_free_bcd.py", "--cases", case_id, "--out", str(out)])
    assert run_free_bcd.main() == 0
    status = json.loads((out / "free_run_status.json").read_text(encoding="utf-8"))
    assert status["started_runs"] == 3 and status["dispatch_count"] == len(called)
    assert all(r["status"] == "finished" and r["auto_pass"] for r in status["status_by_case"][case_id].values())
    mirror = original.load(out / "case_results" / f"{case_id}.yaml")
    assert mirror["expected"]["behaviour"] == "not_available" and mirror["gold"] == []
    assert mirror["evaluation"]["conditions"] == status["status_by_case"][case_id]
    assert any("submit_objections" in {t["function"]["name"] for t in req.get("tools", [])} for req in called)
    assert all(req["model"] == model and "models" not in req for req in called)
