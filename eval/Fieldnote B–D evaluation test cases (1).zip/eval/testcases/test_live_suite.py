"""Offline verification for the mixed-mode fixtures and separate Discover scoring."""

import json
import sys
from pathlib import Path

import httpx
import pytest
import yaml

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE.parents[1] / "tests"))

import build_live_cases as builder
import live_discover
import run_free_bcd as runner
import test_eval_cases as original

CASES = sorted((HERE / "live").glob("*.yaml"))


@pytest.mark.parametrize("path", CASES, ids=lambda path: path.stem)
def test_fixture(path):
    case = original.load(path)
    assert case["id"] == path.stem and case["split"] == "dev"
    if case["mode"] != "discover":
        original.test_case_has_required_fields_and_types(path)
        origin = case["inherits_gold_from"]
        root = HERE if "-ext-" in origin else HERE.parent / "cases"
        assert case["gold"] == original.load(root / f"{origin}.yaml")["gold"]
        return
    assert not case["gold"] and len(case["companies"]) == 2
    assert case["expected"]["must_mention"] and case["expected"]["must_not"]
    fixture = case["discovery"]
    checks = fixture["checks"]
    assert checks["top_k"] == 1
    if fixture["time_mode"] == "historical":
        assert checks["historical_refusal"] and case["cutoff"] < builder.LABEL_DATE
    else:
        low, high = checks["picks_range"]
        assert 0 <= low <= high <= checks["top_k"]


def test_reproducible_generation(tmp_path):
    builder.generate(tmp_path)
    assert len(CASES) == len(builder.NAMED) + len(builder.DISCOVER)
    assert {p.name for p in CASES} == {p.name for p in tmp_path.glob("*.yaml")}
    assert all(p.read_bytes() == (tmp_path / p.name).read_bytes() for p in CASES)


def test_discover_does_not_pass_with_wrong_scope(tmp_path):
    case = original.load(HERE / "live/live-discover-positive-operating-margin.yaml")
    entry = {"case": case["id"], "condition": "D", "repeat": 1, "trace": "trace.jsonl"}
    rule = case["discovery"]["checks"]
    spec = {key: rule[key] for key in ("rank_by", "descending", "filters")}
    end = {"kind": "run_end", "status": "finished", "counts": {"screened": 2, "returned": 1},
           "candidates": [{"outcome": "picked", "cik": "0000320193", "verdict": "pass"}], "markdown": "test"}

    def write_and_score():
        (tmp_path / "trace.jsonl").write_text(json.dumps({"kind": "screen_spec", "spec": spec, "top_k": 1})
                                             + "\n" + json.dumps(end), encoding="utf-8")
        return live_discover.score_run(case, entry, tmp_path)

    assert write_and_score()["screen_auto_pass"] is True
    spec["price_checks"] = [{"metric": "pe", "op": "<", "value": 10}]
    assert write_and_score()["checks"]["no_unsolicited_filters"] is False
    spec.pop("price_checks")
    end["candidates"][0]["cik"] = "0000000001"
    assert write_and_score()["checks"]["universe_and_recheck"] is False


def test_historical_discover_runs_expected_refusal(monkeypatch, tmp_path):
    from research_assistant.data import sec

    model = runner.PREFERRED[0]
    monkeypatch.setenv("OPENROUTER_API_KEY", "test-placeholder")
    monkeypatch.setenv("SEC_USER_AGENT", "Offline contact test@example.invalid")
    monkeypatch.setattr(runner.time, "sleep", lambda _: None)
    monkeypatch.setattr(sec.SecClient, "get", lambda *args: pytest.fail("Historical screen must not call SEC"))
    monkeypatch.setattr(runner.httpx, "get", lambda *a, **k: httpx.Response(
        200, request=httpx.Request("GET", runner.BASE + "/models"), json={"data": [
            {"id": model, "pricing": {"prompt": "0", "completion": "0"}, "context_length": 1000000,
             "supported_parameters": ["tools", "tool_choice"]}]}))

    def fake_request(self, method, path, body=None):
        if method == "GET":
            return httpx.Response(200, json={"data": {"free_model_daily_requests": {"used": 0, "limit": 50, "remaining": 50}}})
        assert body["model"] == model
        assert body["provider"]["max_price"] == {"prompt": 0, "completion": 0, "request": 0}
        args = {"filters": [{"metric": "operating_margin", "op": ">", "value": 0.05}],
                "rank_by": "operating_margin", "descending": True, "top_k": 1}
        return httpx.Response(200, json={"id": "mock", "created": 1, "model": model, "object": "chat.completion",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": None,
                "tool_calls": [{"id": "call", "type": "function",
                    "function": {"name": "submit_screen_spec", "arguments": json.dumps(args)}}]},
                "finish_reason": "tool_calls"}]})

    monkeypatch.setattr(runner.Gate, "request", fake_request)
    out = tmp_path / "batch"
    monkeypatch.setattr(sys, "argv", ["run_free_bcd.py", "--case-dir", str(HERE / "live"), "--cases",
                                    "live-discover-historic-margin", "--out", str(out)])
    assert runner.main() == 0
    meta = json.loads((out / "free_run_status.json").read_text())
    assert meta["dispatch_count"] == 3
    rows = json.loads((out / "discovery_scores.json").read_text())
    assert all(r["status"] == "expected_refusal" and r["screen_auto_pass"] for r in rows)
    assert all(r["run_status"] == "failed" for r in rows)
    assert not (out / "scores.json").exists()
    result = yaml.safe_load((out / "case_results/live-discover-historic-margin.yaml").read_text())
    assert result["evaluation"]["conditions"]["B"]["auto_pass"] is None
