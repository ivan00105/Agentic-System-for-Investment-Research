"""Run Discover with the native pipeline and score its screen separately from numeric briefs."""

import json
import math
from datetime import datetime, time, timezone


def run_case(case, condition, out, client, settings, sec):
    import run_eval
    from research_assistant import cli
    from research_assistant.agents import discover
    from research_assistant.agents.trace import Trace
    from research_assistant.data.universe import Member, Universe
    from research_assistant.tools.result import ToolContext

    fixture = case["discovery"]
    historical = fixture["time_mode"] == "historical"
    cutoff = (datetime.combine(case["cutoff"], time.max, timezone.utc)
              if historical else datetime.now(timezone.utc))
    universe = Universe(fixture["universe"], case["source"], str(case["cutoff"]),
                        "Declared evaluation list, not an index or a historical membership snapshot.",
                        tuple(Member(c["ticker"], str(c["cik"]).zfill(10), c["name"]) for c in case["companies"]))
    trace = Trace.new(out / "traces", echo=cli.progress)
    run_eval.append(out, {"case": case["id"], "condition": condition, "repeat": 1,
                         "trace": f"traces/{trace.path.name}", "run_id": trace.run_id})
    discover.run(case["question"], client, settings, ToolContext(cutoff=cutoff, sec=sec, historical=historical),
                 universe, research=cli.CONDITIONS[condition], condition=cli.LABELS[condition], trace=trace)


def _same_filters(actual, expected):
    key = lambda f: (f["metric"], f["op"], float(f["value"]))
    a, b = sorted(map(key, actual)), sorted(map(key, expected))
    return len(a) == len(b) and all(x[:2] == y[:2] and math.isclose(x[2], y[2], rel_tol=1e-8, abs_tol=1e-10)
                                   for x, y in zip(a, b, strict=True))


def score_run(case, entry, out):
    path = out / entry["trace"]
    row = {k: entry[k] for k in ("case", "condition", "repeat", "trace")}
    row.update(status="crashed", screen_auto_pass=None, checks={}, totals=None)
    try:
        events = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    except (OSError, ValueError):
        return row
    end = next((e for e in reversed(events) if e["kind"] == "run_end"), None)
    if end is None:
        return row
    criterion = case["discovery"]["checks"]
    screen = next((e for e in events if e["kind"] == "screen_spec"), {})
    spec = screen.get("spec") or {}
    counts = end.get("counts") or {}
    ciks = {str(c["cik"]).zfill(10) for c in case["companies"]}
    picked = [c for c in end.get("candidates", []) if c["outcome"] == "picked"]
    checks = {
        "spec_present": bool(spec),
        "top_k": screen.get("top_k") == criterion["top_k"],
        "universe_and_recheck": all(c["cik"] in ciks and c["verdict"] == "pass" for c in picked),
    }
    if "filters" in criterion:
        checks["filters"] = _same_filters(spec.get("filters", []), criterion["filters"])
        checks["no_unsolicited_filters"] = not (spec.get("sic_prefixes") or spec.get("price_checks"))
    for key in ("rank_by", "descending"):
        if key in criterion:
            checks[key] = spec.get(key) == criterion[key]
    if criterion.get("disclose_assumption"):
        checks["disclosed_assumption"] = ("assumed" in (end.get("terms") or {}).values()
                                           and "assumed" in (end.get("markdown") or "").lower())
    historical = criterion.get("historical_refusal", False)
    no_fake_success = "screen can't run as of a past cutoff" in (end.get("error") or "").lower()
    if historical:
        checks["historical_refusal"] = end["status"] == "failed" and no_fake_success and not picked
    else:
        minimum, maximum = criterion["picks_range"]
        checks["screen_completed"] = end["status"] == "finished" and counts.get("screened") == len(ciks)
        checks["candidate_count"] = (counts.get("returned") == len(picked) and minimum <= len(picked) <= maximum)
    row.update(status="expected_refusal" if historical and checks["historical_refusal"] else end["status"],
               run_status=end["status"], screen_auto_pass=all(checks.values()), checks=checks,
               counts=counts, totals=end.get("totals"), error=end.get("error"))
    folder = out / "reports"
    folder.mkdir(exist_ok=True)
    (folder / f"{entry['case']}--{entry['condition']}{entry['repeat']}.md").write_text(
        end.get("markdown") or "", encoding="utf-8")
    return row
