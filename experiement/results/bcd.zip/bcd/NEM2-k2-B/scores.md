# Evaluation scores

3 runs of 3 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| B | 3 | 1/3 (33%) | 7/14 (50%) | 3/3 (100%) | 11 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-fb-nflx-fy2015-ebitda-margin | B | 1 | finished | 2/4 | answered | no | 4 |
| held-fb-wmt-fy2019-operating-margin-change | B | 1 | finished | 2/7 | answered | no | 4 |
| held-trap-bby-fiscal-2019-revenue | B | 1 | finished | 3/3 | answered | yes | 3 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| B | 3 | 33% (0% to 100%) | - | - | 3/3 | 2/3 | $0.0000 |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

(none)

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| B | 3 | 28 | 27/28 (96%) | 1 | 0/18 | 14 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

No D runs in this batch.

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| B | 3 | 7 | 4 | 79,599 | 46% | 3,533 | $0.0000 | $0.0000 | 1.2 | 1.5 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

| Case | Condition | Repeat | What went wrong |
|---|---|---|---|
| held-fb-nflx-fy2015-ebitda-margin | B | 1 | depreciation_amortization_2015: needs review; ebitda_margin_2015: needs review |
| held-fb-wmt-fy2019-operating-margin-change | B | 1 | total_revenues_fy2019: missing; total_revenues_fy2018: missing; operating_income_fy2019: missing; operating_income_fy2018: missing; operating_margin_change_fy2019: needs review |

Runs that ended without a report (failed, stopped or crashed): B: 0/3 (0%).

## Needs review

### held-fb-nflx-fy2015-ebitda-margin

What was Netflix's 2015 EBITDA margin, with EBITDA as operating income plus the depreciation and amortization of property, equipment and intangibles from the cash flow statement?

- Must mention: EBITDA here is a non-GAAP measure built to the question's definition.
- Must not: Adds "Amortization of streaming content assets" (3,405,382 thousand), which gives about 55.7%.
- B1, Gold depreciation_amortization_2015: No tool record measures 'depreciation_and_amortization'.
- B1, Gold ebitda_margin_2015: No tool record measures 'ebitda_to_revenue'.

Reports: reports/held-fb-nflx-fy2015-ebitda-margin--B1.md

### held-fb-wmt-fy2019-operating-margin-change

By how much did Walmart's operating margin (operating income over total revenues) change from fiscal 2018 to fiscal 2019?

- Must mention: The change is about +0.2 percentage points (from about 4.1% to about 4.3%), not a percent change.
- Must mention: The periods are the fiscal years ended 31 January 2019 and 31 January 2018.
- Must not: Uses Walmart's own "Operating income as a percentage of net sales" (4.3 and 4.1), which divides by net sales, not total revenues, without saying so.
- B1, Gold operating_margin_change_fy2019: No automatic rule for the unit 'percentage points'.

Reports: reports/held-fb-wmt-fy2019-operating-margin-change--B1.md

### held-trap-bby-fiscal-2019-revenue

What were Best Buy's revenue and revenue growth in fiscal 2019?

- Must mention: The period is the fiscal year ended 2 February 2019.
- Must mention: Fiscal 2018 had 53 weeks and fiscal 2019 had 52, which lowers the reported growth.
- Must not: Reports 43,638, which is fiscal 2020 (ended 1 February 2020, mostly calendar 2019).

Reports: reports/held-trap-bby-fiscal-2019-revenue--B1.md
