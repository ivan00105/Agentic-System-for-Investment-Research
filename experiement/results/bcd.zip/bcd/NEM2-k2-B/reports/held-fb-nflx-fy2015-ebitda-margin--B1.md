# What was Netflix's 2015 EBITDA margin, with EBITDA as operating income plus the depreciation and amortization of property, equipment and intangibles from the cash flow statement?

- Run status: finished
- Cutoff: 2016-02-29T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261125-045136-3716f8

## Plan

1. **Find Netflix** – Use `find_company` with ticker "NFLX" to get its CIK and confirm it's a US GAAP filer.  
2. **Retrieve 2015 annual financials** – Call `get_financials` for the fiscal year ending 2015-12-31 (newest first) to obtain:  
   - Operating income (fact ID)  
   - Depreciation & amortization from the cash flow statement (fact ID)  
   - Revenue (fact ID)  
3. **Calculate EBITDA and EBITDA margin** – Use `calculate` with formula `ratio` (or a custom expression) to compute:  
   - EBITDA = operating income + D&A (cash flow)  
   - EBITDA margin = EBITDA / revenue  
   Cite the fact IDs from step 2 in the calculation.  
4. **No filing sections or 8-K events needed** – The question is purely metric-based on the 2015 10-K annual data.  
5. **Potential data gaps** – If Netflix reported under IFRS or had missing D&A line items, the calculation could be unsupported; however, Netflix is a US GAAP filer with standard cash flow presentation.

## Summary (cited)

- Netflix's 2015 EBITDA margin cannot be calculated because the depreciation and amortization (D&A) line item from the cash flow statement is not available in the structured SEC data accessible via the tools. [1] [2] [3]
- The available 2015 figures are revenue of $6.8 billion and operating income of $305.8 million, but D&A must be added to operating income to compute EBITDA as defined. [1] [2]
- Without D&A, the EBITDA margin (EBITDA/revenue) cannot be determined. [1] [2]

## Key numbers (cited)

- Revenue for fiscal year ended 2015-12-31: $6.8 billion [1]
- Operating income for fiscal year ended 2015-12-31: $305.8 million [2]
- Operating cash flow for fiscal year ended 2015-12-31: -$749.4 million (this is net cash from operations, not D&A) [3]

## Bull case (cited)

- Netflix generated positive operating income of $305.8 million in 2015, showing the core streaming business was profitable at the operating level. [2]

## Bear case (cited)

- Operating cash flow was negative -$749.4 million in 2015, reflecting heavy cash outflows for content licensing and production that are not captured in operating income. [3]

## Risks (cited)

- The D&A figure needed for the requested EBITDA calculation is not exposed in the SEC structured data feed used by the tools, so the metric cannot be computed. [1] [2] [3]

## What would change the view (cited)

- If the depreciation and amortization line item from the 2015 cash flow statement becomes available in the structured data, the EBITDA margin could be calculated. [1] [2] [3]

## Limitations

- The get_financials tool does not provide depreciation and amortization as a separate metric; it only provides operating_cash_flow (net cash from operations), which includes D&A but also working capital changes, stock-based compensation, and other adjustments.
- The read_filing_section tool only accesses Item 1A, Item 7, and Item 7A of the 10-K, not the financial statements (Item 8) where the cash flow statement appears, so the D&A line cannot be extracted from the filing text via the available tools.
- Therefore, the requested EBITDA margin (operating income + cash flow D&A) / revenue cannot be computed with the current data access.

## Sources

1. `fact-3b550fab7345` revenue = $6.8 billion, 2015-01-01 to 2015-12-31 (us-gaap:Revenues; 10-K 0001065280-16-000047, filed 2016-01-28) https://www.sec.gov/Archives/edgar/data/1065280/000106528016000047/
2. `fact-0fc5cb07b498` operating_income = $305.8 million, 2015-01-01 to 2015-12-31 (us-gaap:OperatingIncomeLoss; 10-K 0001065280-16-000047, filed 2016-01-28) https://www.sec.gov/Archives/edgar/data/1065280/000106528016000047/
3. `fact-060f30bf9cd7` operating_cash_flow = -$749.4 million, 2015-01-01 to 2015-12-31 (us-gaap:NetCashProvidedByUsedInOperatingActivities; 10-K 0001065280-16-000047, filed 2016-01-28) https://www.sec.gov/Archives/edgar/data/1065280/000106528016000047/
