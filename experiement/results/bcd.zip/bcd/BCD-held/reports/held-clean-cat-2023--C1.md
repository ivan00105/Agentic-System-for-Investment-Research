# What were Caterpillar's total sales and revenues, operating profit and profit in 2023?

- Run status: failed
- Cutoff: 2024-03-31T23:59:59.999999+00:00
- Condition: C (analyst team)
- Model: anthropic/claude-haiku-5.5 (served by Claude Platform on AWS)
- Run: 20261124-160836-c63ac6
- Error: The model provider requires payment or additional credits. Check the selected provider account.

## Plan

**Plan: Caterpillar (CAT) total sales and revenues, operating profit and profit, fiscal 2023**

1. **Identify the company.** Use find_company on CAT to get the CIK and confirm the SIC industry (machinery). Caterpillar is a US domestic filer reporting in USD, so no currency conversion or IFRS adjustments should be needed.

2. **Fundamentals figures (ask_fundamentals).** Request these for fiscal year 2023, with 2022 as the comparison year:
   - Total sales and revenues, as reported on the consolidated statement of results of operations.
   - Operating profit. Caterpillar reports operating profit at the segment level (Construction Industries, Resource Industries, Energy & Transportation, Financial Products). Ask whether a consolidated operating profit figure exists or needs to be derived from the segments, and label which one is used.
   - Profit. Ask for the consolidated profit figure and also profit attributable to common shareholders, since the two differ because of noncontrolling interests. Confirm which one answers "profit."
   - Ask the analyst to check each figure against the FY2023 10-K using verify_against_filing, and to confirm that both fiscal periods are comparable (no restatements or segment reorganisations that would break the comparison).

3. **Calculations (calculate, run by the fundamentals analyst or myself).**
   - Operating margin: operating profit divided by total sales and revenues.
   - Net margin: profit divided by total sales and revenues.
   - Year-over-year growth in sales and revenues, and change in margin in percentage points, using 2022 as the base.

4. **Filing context (ask_filings).** Read Item 7 (MD&A) in the FY2023 10-K to explain the main drivers of 2023 sales and profit, such as pricing, volume and Financial Products results. Check whether any recent 8-K events affect how these figures should be read. Insider trades are not needed for this question.

5. **Market and valuation.** Not needed for this question. Skip ask_market unless the user later asks about valuation.

6. **Likely gaps to flag in the answer.**
   - "Operating profit" may need to be the sum of segment operating profits, with corporate items shown separately. Say which definition is used.
   - "Profit" could mean consolidated profit or profit attributable to common shareholders. Report both and label them.
   - Financial Products is a captive finance segment, so its revenue and profit are reported within the consolidated totals. Note this if it affects the comparison.
   - No outlook model is needed here, and no bank or IFRS adjustments apply.

## Who did what

- fundamentals analyst (finished, 4 model calls, 5 findings): Caterpillar Inc (CAT, CIK 0000018230), fiscal year 2023 (year ended 2023-12-31) with fiscal 2022 as comparison. Find: (1) total sales and revenues from the consolidated statement of results of operations; (2) consolidated operating profit if reported, otherwise the sum of segment operating profit (Construction Industries, Resource Industries, Energy & Transportation, Financial Products) with corporate items shown separately, and label which definition is used; (3) consolidated profit and profit attributable to common shareholders. Check each figure against the FY2023 10-K with verify_against_filing, and confirm both periods are comparable (no restatement or segment reorganisation). Give fact IDs for each value.
- filings and events analyst (finished, 4 model calls, 14 findings): Caterpillar Inc (CAT, CIK 0000018230). Read Item 7 (MD&A) of the FY2023 10-K (year ended 2023-12-31) and summarise the main drivers of 2023 total sales and revenues and profit versus 2022 (price realization, sales volume, currency, Financial Products results), attributing management's statements. Also check list_filings/get_events for any material 8-K events in early 2024 up to 2024-03-31 that affect how these figures should be read.
- fundamentals analyst (failed, 1 model calls, 0 findings): Follow-up: profit is still missing for Caterpillar (CIK 0000018230). Retry for fiscal 2023 and 2022 (years ended 2023-12-31 and 2022-12-31): consolidated profit (ProfitLoss, including noncontrolling interests) and profit attributable to common shareholders (NetIncomeLoss). Try alternative tags and the statement of results of operations / income statement. Verify each with verify_against_filing and give fact IDs. Then calculate operating margin (operating profit / total sales and revenues) for 2023 and 2022, the change in that margin in percentage points, and the net margin using profit attributable to common shareholders.
- market and valuation analyst (failed, 1 model calls, 0 findings): Caterpillar Inc (CAT, CIK 0000018230). Using get_financials, find the fiscal 2023 (year ended 2023-12-31) and fiscal 2022 values for consolidated profit (ProfitLoss, including noncontrolling interests) and profit attributable to common shareholders (NetIncomeLoss). Return fact IDs for each, and note any that are missing. Do not estimate.

## Summary (abstained)

- Nothing to report.

## Key numbers (abstained)

- Nothing to report.

## Bull case (abstained)

- Nothing to report.

## Bear case (abstained)

- Nothing to report.

## Risks (abstained)

- Nothing to report.

## What would change the view (abstained)

- Nothing to report.

## Limitations

- The model did not hand in a report (The model provider requires payment or additional credits. Check the selected provider account.). Every section is abstained; the 99 records gathered before it stopped are listed as sources.

## Sources

1. `company-0000018230` CATERPILLAR INC (CIK 0000018230, CAT)
2. `fact-fc5b1ab7ac2d` revenue = $67.1 billion, 2023-01-01 to 2023-12-31 (us-gaap:Revenues; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
3. `fact-ff2db89dc8b4` revenue = $59.4 billion, 2022-01-01 to 2022-12-31 (us-gaap:Revenues; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
4. `fact-cb51e360b9a5` revenue = $51.0 billion, 2021-01-01 to 2021-12-31 (us-gaap:Revenues; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
5. `fact-c44667ed171a` operating_income = $13.0 billion, 2023-01-01 to 2023-12-31 (us-gaap:OperatingIncomeLoss; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
6. `fact-2e7c5b75b635` operating_income = $7.9 billion, 2022-01-01 to 2022-12-31 (us-gaap:OperatingIncomeLoss; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
7. `fact-c4644fccbfce` operating_income = $6.9 billion, 2021-01-01 to 2021-12-31 (us-gaap:OperatingIncomeLoss; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
8. `fact-1b7611484c06` eps_diluted = $20.12 per share, 2023-01-01 to 2023-12-31 (us-gaap:EarningsPerShareDiluted; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
9. `fact-d0c573749ba0` eps_diluted = $12.64 per share, 2022-01-01 to 2022-12-31 (us-gaap:EarningsPerShareDiluted; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
10. `fact-7f320a96e67c` eps_diluted = $11.83 per share, 2021-01-01 to 2021-12-31 (us-gaap:EarningsPerShareDiluted; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
11. `fact-769e00e57f45` diluted_shares = 513.6 million shares, 2023-01-01 to 2023-12-31 (us-gaap:WeightedAverageNumberOfDilutedSharesOutstanding; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
12. `fact-c61bdae65732` diluted_shares = 530.4 million shares, 2022-01-01 to 2022-12-31 (us-gaap:WeightedAverageNumberOfDilutedSharesOutstanding; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
13. `fact-cb331570ecff` diluted_shares = 548.5 million shares, 2021-01-01 to 2021-12-31 (us-gaap:WeightedAverageNumberOfDilutedSharesOutstanding; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
14. `check-da52d02f08a5` fact-fc5b1ab7ac2d checked against the filing: match https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
15. `check-87159c89200b` fact-ff2db89dc8b4 checked against the filing: match https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
16. `check-a07d5a6e3cae` fact-c44667ed171a checked against the filing: match https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
17. `check-8989576fdb64` fact-2e7c5b75b635 checked against the filing: match https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
18. `check-55dbcad2c424` fact-1b7611484c06 checked against the filing: match https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
19. `calc-69cf3bb22b31` growth(current=`fact-fc5b1ab7ac2d`, previous=`fact-ff2db89dc8b4`) = 12.8%, 2022-01-01 to 2023-12-31
20. `claim-cd12deac129a` fundamentals analyst finding (v1): Caterpillar's total sales and revenues were $67.1 billion in the fiscal year ended 2023-12-31, up from $59.4 billion in the fiscal year ended 2022-12-31. Cites `fact-fc5b1ab7ac2d`, `fact-ff2db89dc8b4`, `check-da52d02f08a5`, `check-87159c89200b`.
21. `claim-9d65ab22f4ca` fundamentals analyst finding (v1): Total sales and revenues rose about 12.8% in 2023 versus 2022. Cites `calc-69cf3bb22b31`, `fact-fc5b1ab7ac2d`, `fact-ff2db89dc8b4`.
22. `claim-133071663dbd` fundamentals analyst finding (v1): Caterpillar reports consolidated operating profit (operating income, the profit left after running costs, before interest and tax) of $13.0 billion for the fiscal year ended 2023-12-31, against $7.9 billion for the fiscal year ended 2022-12-31. This is the company's reported consolidated figure, not a sum of segments. Cites `fact-c44667ed171a`, `fact-2e7c5b75b635`, `check-a07d5a6e3cae`, `check-8989576fdb64`.
23. `claim-37f9485a4437` fundamentals analyst finding (v1): Diluted profit per common share was $20.12 per share for 2023 and $12.64 per share for 2022, on about 513.6 million shares diluted shares in 2023. Profit per share is profit attributable to common shareholders divided by shares, so it reflects the profit figure that could not be retrieved (see gaps). Cites `fact-1b7611484c06`, `fact-d0c573749ba0`, `fact-769e00e57f45`, `check-55dbcad2c424`.
24. `claim-ccdaf1982b23` fundamentals analyst finding (v1): Both 2023 and 2022 figures come from the same 10-K (filed 2024-02-16), and the revenue and operating profit values match the filing's tables. No restatement or segment reorganisation was flagged in the records retrieved, so the two years are comparable on these measures. Cites `fact-fc5b1ab7ac2d`, `fact-ff2db89dc8b4`, `fact-c44667ed171a`, `fact-2e7c5b75b635`, `check-da52d02f08a5`, `check-87159c89200b`, `check-a07d5a6e3cae`, `check-8989576fdb64`.
25. `filing-0001104659-24-035172` 4 filed 2024-03-18: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924035172/xslF345X05/tm249012-3_4seq1.xml
26. `filing-0001104659-24-035169` 4 filed 2024-03-18: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924035169/xslF345X05/tm249012-2_4seq1.xml
27. `filing-0001104659-24-035167` 4 filed 2024-03-18: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924035167/xslF345X05/tm249012-1_4seq1.xml
28. `filing-0001104659-24-033203` 4 filed 2024-03-12: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924033203/xslF345X05/tm248510-1_4seq1.xml
29. `filing-0001104659-24-033191` 4 filed 2024-03-12: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924033191/xslF345X05/tm248510-2_4seq1.xml
30. `filing-0001104659-24-033188` 4 filed 2024-03-12: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924033188/xslF345X05/tm248510-3_4seq1.xml
31. `filing-0001104659-24-032271` 4 filed 2024-03-08: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924032271/xslF345X05/tm248344-1_4seq1.xml
32. `filing-0001104659-24-031375` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031375/xslF345X05/tm248078-1_4seq1.xml
33. `filing-0001104659-24-031373` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031373/xslF345X05/tm248078-9_4seq1.xml
34. `filing-0001104659-24-031372` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031372/xslF345X05/tm248078-8_4seq1.xml
35. `filing-0001104659-24-031370` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031370/xslF345X05/tm248078-7_4seq1.xml
36. `filing-0001104659-24-031369` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031369/xslF345X05/tm248078-6_4seq1.xml
37. `filing-0001104659-24-031368` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031368/xslF345X05/tm248078-5_4seq1.xml
38. `filing-0001104659-24-031367` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031367/xslF345X05/tm248078-4_4seq1.xml
39. `filing-0001104659-24-031366` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031366/xslF345X05/tm248078-3_4seq1.xml
40. `filing-0001104659-24-031365` 4 filed 2024-03-06: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031365/xslF345X05/tm248078-2_4seq1.xml
41. `filing-0001104659-24-031072` 4 filed 2024-03-05: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924031072/xslF345X05/tm248010-1_4seq1.xml
42. `filing-0001104659-24-029307` 4 filed 2024-02-29: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924029307/xslF345X05/tm247306-4_4seq1.xml
43. `filing-0001972362-24-000241` 144 filed 2024-02-28:  https://www.sec.gov/Archives/edgar/data/18230/000197236224000241/xsl144X01/primary_doc.xml
44. `filing-0001104659-24-028184` 4 filed 2024-02-27: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924028184/xslF345X05/tm247306-3_4seq1.xml
45. `filing-0001104659-24-027620` 4 filed 2024-02-26: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924027620/xslF345X05/tm247306-1_4seq1.xml
46. `filing-0001104659-24-026998` 4 filed 2024-02-23: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924026998/xslF345X05/tm247117-1_4seq1.xml
47. `filing-0001972362-24-000181` 144 filed 2024-02-22:  https://www.sec.gov/Archives/edgar/data/18230/000197236224000181/xsl144X01/primary_doc.xml
48. `filing-0001104659-24-024881` 4 filed 2024-02-16: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924024881/xslF345X05/tm246539-1_4seq1.xml
49. `filing-0000018230-24-000009` 10-K filed 2024-02-16: 10-K https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
50. `filing-0001972362-24-000138` 144 filed 2024-02-15:  https://www.sec.gov/Archives/edgar/data/18230/000197236224000138/xsl144X01/primary_doc.xml
51. `filing-0001104659-24-024310` 4 filed 2024-02-15: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924024310/xslF345X05/tm245322-10_4seq1.xml
52. `filing-0001104659-24-024305` 4 filed 2024-02-15: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924024305/xslF345X05/tm245322-9_4seq1.xml
53. `filing-0001104659-24-024303` 4 filed 2024-02-15: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924024303/xslF345X05/tm245322-8_4seq1.xml
54. `filing-0001104659-24-024301` 4 filed 2024-02-15: OWNERSHIP DOCUMENT https://www.sec.gov/Archives/edgar/data/18230/000110465924024301/xslF345X05/tm245322-7_4seq1.xml
55. `chunk-0000018230-24-000009-part_ii_item_7-37` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 37 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
56. `chunk-0000018230-24-000009-part_ii_item_7-57` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 57 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
57. `chunk-0000018230-24-000009-part_ii_item_7-20` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 20 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
58. `chunk-0000018230-24-000009-part_ii_item_7-35` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 35 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
59. `chunk-0000018230-24-000009-part_ii_item_7-38` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 38 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
60. `chunk-0000018230-24-000009-part_ii_item_7-18` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 18 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
61. `chunk-0000018230-24-000009-part_ii_item_7-24` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 24 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
62. `chunk-0000018230-24-000009-part_ii_item_7-36` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 36 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
63. `chunk-0000018230-24-000009-part_ii_item_7-70` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 70 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
64. `chunk-0000018230-24-000009-part_ii_item_7-6` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 6 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
65. `chunk-0000018230-24-000009-part_ii_item_7-22` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 22 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
66. `chunk-0000018230-24-000009-part_ii_item_7-40` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 40 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
67. `chunk-0000018230-24-000009-part_ii_item_7-12` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 12 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
68. `chunk-0000018230-24-000009-part_ii_item_7-43` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 43 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
69. `chunk-0000018230-24-000009-part_ii_item_7-34` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 34 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
70. `filing-0000018230-24-000005` 8-K filed 2024-02-05: 8-K https://www.sec.gov/Archives/edgar/data/18230/000001823024000005/cat-20240205.htm
71. `filing-0000018230-23-000058` 8-K filed 2023-12-14: 8-K https://www.sec.gov/Archives/edgar/data/18230/000001823023000058/cat-20231212.htm
72. `chunk-0000018230-24-000009-part_ii_item_7-30` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 30 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
73. `chunk-0000018230-24-000009-part_ii_item_7-46` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 46 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
74. `chunk-0000018230-24-000009-part_ii_item_7-26` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 26 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
75. `chunk-0000018230-24-000009-part_ii_item_7-47` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 47 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
76. `chunk-0000018230-24-000009-part_ii_item_7-2` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 2 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
77. `chunk-0000018230-24-000009-part_ii_item_7-50` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 50 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
78. `chunk-0000018230-24-000009-part_ii_item_7-56` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 56 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
79. `chunk-0000018230-24-000009-part_ii_item_7-61` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 61 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
80. `chunk-0000018230-24-000009-part_ii_item_7-157` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 157 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
81. `chunk-0000018230-24-000009-part_ii_item_7-73` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 73 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
82. `chunk-0000018230-24-000009-part_ii_item_7-165` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 165 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
83. `chunk-0000018230-24-000009-part_ii_item_7-52` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 52 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
84. `claim-99a5955de199` filings analyst finding (v1): Caterpillar's total sales and revenues rose in 2023 from 2022, and management says the increase was primarily due to favorable price realization and higher sales volume. Cites `chunk-0000018230-24-000009-part_ii_item_7-6`, `chunk-0000018230-24-000009-part_ii_item_7-18`.
85. `claim-c771a6be9cd5` filings analyst finding (v1): Of the sales increase, price realization (higher prices charged to customers) was the largest driver, well ahead of sales volume; currency was a small net drag and Financial Products revenue added a smaller amount. Cites `chunk-0000018230-24-000009-part_ii_item_7-24`.
86. `claim-6dcf842099b9` filings analyst finding (v1): Management says sales volume rose mainly because of higher sales of equipment to end users, partly offset by changes in dealer inventories: dealers built stock by a smaller amount in 2023 than in 2022. Cites `chunk-0000018230-24-000009-part_ii_item_7-18`, `chunk-0000018230-24-000009-part_ii_item_7-35`.
87. `claim-e06b18da553b` filings analyst finding (v1): Currency moved against the company in the Machinery, Energy & Transportation business overall: management names the Japanese yen, Australian dollar and Chinese yuan as unfavorable in Asia/Pacific, while the euro and Brazilian real helped in EAME and Latin America. Cites `chunk-0000018230-24-000009-part_ii_item_7-38`, `chunk-0000018230-24-000009-part_ii_item_7-37`, `chunk-0000018230-24-000009-part_ii_item_7-20`, `chunk-0000018230-24-000009-part_ii_item_7-24`.
88. `claim-0e59e545fb99` filings analyst finding (v1): Sales rose in all three equipment segments: Energy & Transportation rose the most (management cites higher volume and favorable price realization), followed by Resource Industries and Construction Industries (both driven mainly by price, with lower volume). Cites `chunk-0000018230-24-000009-part_ii_item_7-43`, `chunk-0000018230-24-000009-part_ii_item_7-40`, `chunk-0000018230-24-000009-part_ii_item_7-34`.
89. `claim-92c68637b2a8` filings analyst finding (v1): Consolidated operating profit (profit before interest and tax, the core earnings from running the business) rose sharply in 2023. Operating profit margin (operating profit as a share of sales) was 19.3% in 2023 versus 13.3% in 2022. Cites `chunk-0000018230-24-000009-part_ii_item_7-2`, `chunk-0000018230-24-000009-part_ii_item_7-30`, `chunk-0000018230-24-000009-part_ii_item_7-157`.
90. `claim-1da12eb8cf42` filings analyst finding (v1): Management says the operating profit gain came from the same sources as sales: favorable price realization and higher sales volume. The 2022 goodwill impairment charge on the Rail division was absent in 2023, which also helped. Cites `chunk-0000018230-24-000009-part_ii_item_7-6`, `chunk-0000018230-24-000009-part_ii_item_7-52`.
91. `claim-21b9b670ec0f` filings analyst finding (v1): Management says offsets included higher selling, general and administrative and research and development spending, unfavorable manufacturing costs, the divestiture of the Longwall business, and lower mark-to-market gains on pension and retiree-health plans. Cites `chunk-0000018230-24-000009-part_ii_item_7-6`.
92. `claim-8bf6df13f442` filings analyst finding (v1): Profit (net income attributable to Caterpillar) rose sharply in 2023. Management attributes the rise to the same drivers as operating profit, and profit per share also rose sharply. Cites `chunk-0000018230-24-000009-part_ii_item_7-6`, `chunk-0000018230-24-000009-part_ii_item_7-157`.
93. `claim-e9a3a555f1dc` filings analyst finding (v1): Most of the operating profit gain came from the Machinery, Energy & Transportation business: its segment profit rose by well over half, with all three equipment segments up strongly. Construction Industries' profit margin rose to 25.4% from 18.8%. Cites `chunk-0000018230-24-000009-part_ii_item_7-30`, `chunk-0000018230-24-000009-part_ii_item_7-40`.
94. `claim-a9977c474ffe` filings analyst finding (v1): Financial Products (the financing arm, Cat Financial, and insurance) grew modestly. Management says revenue rose mainly from higher average financing rates. Segment profit rose slightly, mainly from higher net yield on earning assets and lower credit-loss provisions, partly offset by higher SG&A. Cites `chunk-0000018230-24-000009-part_ii_item_7-46`, `chunk-0000018230-24-000009-part_ii_item_7-47`, `chunk-0000018230-24-000009-part_ii_item_7-30`.
95. `claim-9a8a7dd2697b` filings analyst finding (v1): Management's outlook for the first quarter of 2024 is for sales broadly similar to the first quarter of 2023, with favorable price realization expected to continue and a smaller dealer inventory build than a year earlier. Resource Industries sales are expected to fall. Cites `chunk-0000018230-24-000009-part_ii_item_7-12`.
96. `claim-a93491ef63c5` filings analyst finding (v1): No 8-K describing a material event between the 2023 year end and 2024-03-31 changes how the 2023 figures should be read. The only early-2024 8-K in the filing list is the 2024-02-05 earnings release (Item 2.02, results of operations); it is a results release, not a restatement or deal. The 2023-12-14 8-K (Item 8.01, other events) falls before the year end, and its content was not readable with the tools available. Cites `filing-0000018230-24-000005`, `filing-0000018230-23-000058`.
97. `claim-1eb66e295e11` filings analyst finding (v1): Insider filings in February and March 2024 were Form 4 ownership documents and Form 144 notices; I did not analyse them for buying or selling, since insider trades were outside this task. Cites `filing-0001104659-24-024881`, `filing-0001972362-24-000241`.
98. `calc-c9cb2fbbd4d6` ratio(numerator=`fact-c44667ed171a`, denominator=`fact-fc5b1ab7ac2d`) = 19.3%, 2023-01-01 to 2023-12-31
99. `calc-7bfd3c6bc88f` ratio(numerator=`fact-2e7c5b75b635`, denominator=`fact-ff2db89dc8b4`) = 13.3%, 2022-01-01 to 2022-12-31
