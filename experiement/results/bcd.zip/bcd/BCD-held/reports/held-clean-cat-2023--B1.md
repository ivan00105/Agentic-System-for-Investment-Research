# What were Caterpillar's total sales and revenues, operating profit and profit in 2023?

- Run status: finished
- Cutoff: 2024-03-31T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: anthropic/claude-haiku-5.5 (served by Claude Platform on AWS)
- Run: 20261124-160754-996e6c

## Plan

**Plan: Caterpillar (CAT) FY2023 sales, operating profit and profit**

1. **Identify the company.** Call `find_company` with "CAT" to get the SEC CIK and confirm the ticker and industry code.

2. **Pull FY2023 financials.** Call `get_financials` for the FY2023 fiscal year (year ended December 31, 2023). Also pull FY2022 so the report can show the year-over-year change. Collect these fact IDs:
   - Total sales and revenues (the consolidated top line).
   - Operating profit (consolidated, if reported; otherwise the segment-level total).
   - Profit: check whether the filing reports "profit attributable to common shareholders" or total consolidated profit, and note which one the figure is.

3. **Verify against the filing.** Call `verify_against_filing` on each of the three FY2023 facts to confirm they match the inline XBRL values in the 10-K. Operating profit is the most likely to show `not_in_filing` or a label mismatch, because it may be a non-standard line item.

4. **Read the MD&A for context.** Call `read_filing_section` on Item 7 of the FY2023 10-K, using queries such as "operating profit," "sales and revenues," and "profit per share." This gives the management explanation of the results and the drivers behind the numbers.

5. **Check recent events (optional).** Call `list_filings` with `forms=["8-K"]` to see whether an earnings release or restatement near the cutoff changes how these figures should be described.

6. **Calculations.** Use `calculate` only with fact IDs:
   - Growth in sales and revenues (FY2023 vs FY2022) via `growth`.
   - Operating margin (operating profit ÷ sales and revenues) via `ratio`.
   - Profit margin (profit ÷ sales and revenues) via `ratio`.

**Possible gaps to flag in the report:**
- Caterpillar reports operating profit by segment and may not tag a single consolidated operating profit figure. If so, state that the consolidated figure is derived from segment totals.
- "Profit" can mean total profit or profit attributable to common shareholders. Report the definition the filing uses and state which one is given.
- All figures are in USD from a US GAAP 10-K, so no currency conversion is needed.
- No statistical outlook is needed for this historical question, so `get_outlook` and the risk tools are out of scope.

## Summary (qualified)

- Caterpillar's total sales and revenues were $67.1 billion in 2023, and its operating profit was $13.0 billion (fiscal year ended 2023-12-31). [1] [2]
- Sales and revenues rose 12.8% from 2022, when they were $59.4 billion. [3] [4]
- Operating profit was 19.3% of sales and revenues in 2023, meaning about 19 cents of each sales dollar was left after operating costs. [5] (qualified: see checker flags)
- Profit, which the 10-K defines as profit attributable to common shareholders, rose from 2022 according to the MD&A; the MD&A gives the dollar amounts, but the structured data this research uses does not, so no dollar profit figure is shown here. [6] [7]
- Diluted profit per share was $20.12 per share in 2023, up from $12.64 per share in 2022. [8] [9]

## Key numbers (cited)

- Total sales and revenues, 2023: $67.1 billion (matches the 10-K inline XBRL). [1]
- Operating profit, 2023: $13.0 billion (matches the 10-K inline XBRL; the filing reports it as a consolidated line). [2]
- Profit attributable to common shareholders, 2023: stated in the MD&A text and the supplemental consolidating data, but not in the structured financial data, so no dollar figure is given here. [6] [10]
- Profit per share (diluted), 2023: $20.12 per share. [8]
- Sales and revenues growth, 2023 vs 2022: 12.8%. [3]
- Operating profit margin, 2023: 19.3%. [5]

## Bull case (cited)

- Operating profit rose to $13.0 billion in 2023 from $7.9 billion in 2022, and the 10-K attributes the sales increase mainly to favorable price realization and higher sales volume. [2] [11] [6]
- Management's adjusted operating profit margin, a non-GAAP measure that excludes restructuring costs and the 2022 goodwill impairment, was higher in 2023 than in 2022. [12] [13] [14]

## Bear case (cited)

- Part of the 2023 operating profit gain came from the absence of the 2022 goodwill impairment, not only from underlying growth. [10] [6]
- Restructuring costs reduced 2023 operating profit, including a non-cash charge tied to the Longwall divestiture, according to management. [15] [13]

## Risks (cited)

- Per the 10-K MD&A, management points to higher SG&A and R&D expenses and unfavorable manufacturing costs as offsets to 2023 profit growth. [6]

## What would change the view (cited)

- A restatement of the FY2023 10-K figures, or a later filing that changes the reported sales, operating profit or profit, would change these numbers. [1] [2]

## Limitations

- The 2023 profit total is given in the MD&A text and supplemental table, not in the structured financial data the research tool returns. No profit fact ID was available, so no dollar profit figure or profit margin is shown.
- Revenue and operating profit were checked against the 10-K inline XBRL and match.
- Operating profit is a consolidated figure the filing reports directly, not derived from segment totals.
- Risks are drawn only from the MD&A. Item 1A (risk factors) was not read, so material risks listed there may be missing.
- Recent 8-K filings were not checked, so events near the cutoff were not reviewed.
- Adjusted operating profit margin is a management non-GAAP measure; its figures are quoted from the filing text and no calculation was run on it.

## Flags

- summary[2]: '19' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.

## Sources

1. `fact-fc5b1ab7ac2d` revenue = $67.1 billion, 2023-01-01 to 2023-12-31 (us-gaap:Revenues; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
2. `fact-c44667ed171a` operating_income = $13.0 billion, 2023-01-01 to 2023-12-31 (us-gaap:OperatingIncomeLoss; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
3. `calc-69cf3bb22b31` growth(current=`fact-fc5b1ab7ac2d`, previous=`fact-ff2db89dc8b4`) = 12.8%, 2022-01-01 to 2023-12-31
4. `fact-ff2db89dc8b4` revenue = $59.4 billion, 2022-01-01 to 2022-12-31 (us-gaap:Revenues; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
5. `calc-c9cb2fbbd4d6` ratio(numerator=`fact-c44667ed171a`, denominator=`fact-fc5b1ab7ac2d`) = 19.3%, 2023-01-01 to 2023-12-31
6. `chunk-0000018230-24-000009-part_ii_item_7-6` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 6 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
7. `chunk-0000018230-24-000009-part_ii_item_7-160` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 160 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
8. `fact-1b7611484c06` eps_diluted = $20.12 per share, 2023-01-01 to 2023-12-31 (us-gaap:EarningsPerShareDiluted; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
9. `fact-d0c573749ba0` eps_diluted = $12.64 per share, 2022-01-01 to 2022-12-31 (us-gaap:EarningsPerShareDiluted; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
10. `chunk-0000018230-24-000009-part_ii_item_7-157` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 157 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
11. `fact-2e7c5b75b635` operating_income = $7.9 billion, 2022-01-01 to 2022-12-31 (us-gaap:OperatingIncomeLoss; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
12. `chunk-0000018230-24-000009-part_ii_item_7-2` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 2 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
13. `chunk-0000018230-24-000009-part_ii_item_7-150` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 150 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
14. `chunk-0000018230-24-000009-part_ii_item_7-52` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 52 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
15. `chunk-0000018230-24-000009-part_ii_item_7-29` 10-K 0000018230-24-000009, part_ii_item_7 paragraph 29 https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/cat-20231231.htm
