# What was Lockheed Martin's two-year compound annual growth rate of total net sales from 2020 to 2022?

- Run status: failed
- Cutoff: 2023-02-28T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: anthropic/claude-haiku-5.5 (served by Claude Platform on AWS)
- Run: 20261124-160933-a664b3
- Error: The model provider requires payment or additional credits. Check the selected provider account.

## Plan

1. **Identify the company.** Call `find_company` with "Lockheed Martin" or LMT to get the CIK and confirm it is a US domestic 10-K filer, not a foreign or IFRS filer.

2. **Pull the revenue facts.** Call `get_financials` for LMT and take the total net sales figure for fiscal 2020, 2021 and 2022. Keep the fact IDs for the 2020 and 2022 values. Fiscal 2021 is not needed for a two-year CAGR, but it is a useful sanity check on the trend.

3. **Verify the inputs.** Call `verify_against_filing` on the 2020 and 2022 net sales facts to confirm they match the inline XBRL tags in the original 10-K filings. If the 2020 value appears only as a comparative in the FY2022 10-K, verify it there.

4. **Compute the CAGR.** Call `calculate` with `cagr`, using the 2020 fact ID as the start value and the 2022 fact ID as the end value, with a period of 2 years. As a cross-check, `growth` on the 2021 to 2022 pair and on the 2020 to 2021 pair shows the year-by-year path that the CAGR smooths over.

5. **Filing text (optional).** If the answer needs context on the drivers of the change in sales, read the MD&A (Item 7) of the FY2022 10-K for the stated reasons for the movement in net sales. Item 1A is not needed for this question. Check `list_filings` for 8-Ks only if you want to rule out a restatement or a divestiture that would make the reported series non-comparable.

6. **Limitations to report.**
   - LMT is a US GAAP filer, so no currency conversion or IFRS gap applies.
   - The question is backward-looking, so the outlook and base-rate tools are not needed.
   - If the FY2020 figure was later recast in the FY2022 filing, state which filing's figure you used and note the basis for the comparison.

## Summary (abstained)

- Nothing to report.

## Key numbers (abstained)

- Nothing to report.

## Bull case (abstained)

- Nothing to report.

## Bear case (abstained)

- Nothing to report.

## Risks (abstained)

- Nothing to report.

## What would change the view (abstained)

- Nothing to report.

## Limitations

- The model did not hand in a report (The model provider requires payment or additional credits. Check the selected provider account.). Every section is abstained; the 0 records gathered before it stopped are listed as sources.
