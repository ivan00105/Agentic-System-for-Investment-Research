# In fiscal 2024, what percentage of Cloudflare's revenue came from channel partners?

- Run status: failed
- Cutoff: 2025-03-31T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: anthropic/claude-haiku-5.5
- Run: 20261124-160942-74f6a2
- Error: The model provider requires payment or additional credits. Check the selected provider account.

## Summary (abstained)

- Nothing to report.

## Key numbers (abstained)

- Nothing to report.

## Bull case (abstained)

- Nothing to report.

## Bear case (abstained)

- Nothing to report.

## Risks (abstained)

- Nothing to report.

## What would change the view (abstained)

- Nothing to report.

## Limitations

- The model did not hand in a report (The model provider requires payment or additional credits. Check the selected provider account.). Every section is abstained; the 0 records gathered before it stopped are listed as sources.
