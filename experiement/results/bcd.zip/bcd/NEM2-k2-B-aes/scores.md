# Evaluation scores

1 runs of 1 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| B | 1 | 0/1 (0%) | 0/4 (0%) | 0/1 (0%) | 3 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-fb-aes-fy2022-roa | B | 1 | failed | 0/4 | abstained (wrong) | no | 3 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| B | 1 | 0% (one case: no interval) | - | - | 0/1 | - | no passes |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

(none)

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| B | 1 | 0 | - | 0 | 6/6 | 0 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

No D runs in this batch.

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| B | 1 | 3 | 2 | 20,746 | 85% | 1,065 | $0.0000 | $0.0000 | 5.8 | 5.8 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

| Case | Condition | Repeat | What went wrong |
|---|---|---|---|
| held-fb-aes-fy2022-roa | B | 1 | failed: The model provider rate limit was still reached after automatic retries. Saved results remain available; retry later.; shows no number; net_income_attributable_2022: missing; total_assets_2022: missing; total_assets_2021: missing; return_on_average_assets_2022: needs review |

Runs that ended without a report (failed, stopped or crashed): B: 1/1 (100%).

## Needs review

### held-fb-aes-fy2022-roa

What was AES's return on assets in 2022, defined as net income attributable to AES over the average of total assets at the end of 2021 and 2022?

- Must not: Uses "NET INCOME (LOSS)" of -505, which includes noncontrolling interests, instead of the -546 attributable to AES.
- Must not: Reports a positive return on assets.
- B1, Gold return_on_average_assets_2022: No tool record measures 'return_on_average_assets'.

Reports: reports/held-fb-aes-fy2022-roa--B1.md
