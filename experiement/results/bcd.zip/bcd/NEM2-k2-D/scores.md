# Evaluation scores

1 runs of 1 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| D | 1 | 1/1 (100%) | 3/3 (100%) | 1/1 (100%) | 3 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-trap-bby-fiscal-2019-revenue | D | 1 | finished | 3/3 | answered | yes | 3 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| D | 1 | 100% (one case: no interval) | - | - | 1/1 | 0/1 | $0.0000 |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

(none)

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| D | 1 | 9 | 5/9 (56%) | 4 | 0/6 | 0 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

| Case | Repeat | Objections | Defended | Corrected | Withdrawn | Unresolved | Fixed | Damaged | D right, C wrong | D wrong, C right |
|---|---|---|---|---|---|---|---|---|---|---|
| held-trap-bby-fiscal-2019-revenue | 1 | 5 | 0 | 0 | 1 | 4 | 0 | 0 | no C run | no C run |

Fixed and Damaged compare the draft the critic first saw with the final report, on the same evidence; '-' means the critic never ran. The C columns compare with the C run of the same case and repeat, which retrieved its own evidence. Whether each objection was valid needs review (5 objections in 1 runs).

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| D | 1 | 24 | 14 | 412,231 | 40% | 17,714 | $0.0000 | $0.0000 | 8.5 | 8.5 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

(none)

Runs that ended without a report (failed, stopped or crashed): D: 0/1 (0%).

## Needs review

### held-trap-bby-fiscal-2019-revenue

What were Best Buy's revenue and revenue growth in fiscal 2019?

- Must mention: The period is the fiscal year ended 2 February 2019.
- Must mention: Fiscal 2018 had 53 weeks and fiscal 2019 had 52, which lowers the reported growth.
- Must not: Reports 43,638, which is fiscal 2020 (ended 1 February 2020, mostly calendar 2019).

Reports: reports/held-trap-bby-fiscal-2019-revenue--D1.md
