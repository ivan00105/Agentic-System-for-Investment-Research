# Evaluation scores

2 runs of 1 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| B | 1 | 1/1 (100%) | 3/3 (100%) | 1/1 (100%) | 3 |
| C | 1 | 0/1 (0%) | 0/3 (0%) | 0/1 (0%) | 3 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-trap-cost-fy2023-53-week-growth | B | 1 | finished | 3/3 | answered | yes | 3 |
| held-trap-cost-fy2023-53-week-growth | C | 1 | failed | 0/3 | abstained (wrong) | no | 3 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| B | 1 | 100% (one case: no interval) | - | - | 1/1 | 0/1 | $0.0117 |
| C | 1 | 0% (one case: no interval) | - | - | 0/1 | - | - |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

| Comparison | Shared cases | Before | After | Difference (95% interval) |
|---|---|---|---|---|
| C vs B | 1 | 100% | 0% | -100% (one case: no interval) |

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| B | 1 | 13 | 13/13 (100%) | 0 | 0/6 | 6 |
| C | 1 | 0 | - | 0 | 6/6 | 0 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

No D runs in this batch.

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| B | 1 | 6 | 6 | 84,789 | 0% | 6,522 | $0.0117 | $0.0117 | 0.5 | 0.5 |
| C | 1 | 0 | 0 | 0 | - | 0 | - | - | 0.0 | 0.0 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

| Case | Condition | Repeat | What went wrong |
|---|---|---|---|
| held-trap-cost-fy2023-53-week-growth | C | 1 | failed: The model provider requires payment or additional credits. Check the selected provider account.; shows no number; total_revenue_fy2023: missing; total_revenue_fy2022: missing; revenue_growth_fy2023: missing |

Runs that ended without a report (failed, stopped or crashed): B: 0/1 (0%), C: 1/1 (100%).

## Needs review

### held-trap-cost-fy2023-53-week-growth

How much did Costco's total revenue grow in fiscal 2023?

- Must mention: Fiscal 2023 had 53 weeks (ended 3 September 2023) and fiscal 2022 had 52 (ended 28 August 2022), so part of the growth is the extra week.
- Must not: Presents the growth as like-for-like without mentioning the extra week.
- Must not: Uses net sales (237,710 and 222,730) as total revenue without saying so.

Reports: reports/held-trap-cost-fy2023-53-week-growth--B1.md, reports/held-trap-cost-fy2023-53-week-growth--C1.md
