# What were Caterpillar's total sales and revenues, operating profit and profit in 2023?

- Run status: finished
- Cutoff: 2024-03-31T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261125-045136-59c3a1

## Plan

1. **Identify Caterpillar** – Use `find_company` with ticker "CAT" to get its CIK and confirm it is a US GAAP filer.  
2. **Retrieve 2023 annual financials** – Call `get_financials` for the CIK from step 1; the newest fiscal year returned should be FY 2023 (period ending 2023-12-31). The response will include revenue (total sales and revenues), operating income (operating profit), and net income (profit) with fact IDs for citation.  
3. **No further calculations needed** – The requested figures are reported directly in the SEC filing; `calculate` is not required.  
4. **Optional verification** – If desired, `verify_against_filing` can be used on each fact ID to confirm the numbers match the inline XBRL, but the question only asks for the reported values.  
5. **No filing sections or 8‑K events needed** – The data comes from the annual 10‑K financial statements; Item 1A/7 or 8‑Ks are not required for this query.

## Summary (cited)

- Caterpillar reported total sales and revenues of $67.1 billion and operating profit of $13.0 billion for the fiscal year ended December 31, 2023. [1] [2]
- Net income (profit) is not directly available in the structured SEC data; the filing reports diluted EPS of $20.12 per share on 513.6 million shares diluted shares. [3] [4]

## Key numbers (cited)

- Revenue (total sales and revenues): $67.1 billion for FY2023 [1]
- Operating income (operating profit): $13.0 billion for FY2023 [2]
- Diluted EPS: $20.12 per share for FY2023 [3]
- Diluted shares outstanding: 513.6 million shares for FY2023 [4]

## Bull case (cited)

- Revenue grew from $59.4 billion in 2022 to $67.1 billion in 2023, a 12.8% increase. [5] [1] [6]
- Operating income rose sharply from $7.9 billion in 2022 to $13.0 billion in 2023, a 64.0% increase. [7] [2] [8]

## Bear case (qualified)

- Net income is not directly reported in the structured data feed, limiting immediate verification of bottom-line profit. (qualified: see checker flags)
- The company's long-term debt remains high at $24.5 billion as of year-end 2023. [9]

## Risks (qualified)

- Net income figure not directly accessible via the structured data; users must derive it from EPS and share count or consult the full filing. (qualified: see checker flags)

## What would change the view (qualified)

- Availability of a net_income fact in the structured SEC data would provide a direct profit figure. (qualified: see checker flags)

## Limitations

- The SEC structured data feed did not return a net_income fact for 2023 under standard US GAAP tags (us-gaap:NetIncomeLoss). Net income can be approximated by multiplying diluted EPS ($20.12 per share) by diluted shares (513.6 million shares), yielding approximately $10.33 billion, but this calculation is not a cited fact.
- Only the most recent 5 fiscal years were requested; older historical data is available but not shown.

## Flags

- bear_case[0]: No citation: cite the records this statement rests on.
- risks[0]: No citation: cite the records this statement rests on.
- what_would_change_view[0]: No citation: cite the records this statement rests on.
- limitations[0]: '$10.33 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- limitations[1]: '5' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.

## Sources

1. `fact-fc5b1ab7ac2d` revenue = $67.1 billion, 2023-01-01 to 2023-12-31 (us-gaap:Revenues; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
2. `fact-c44667ed171a` operating_income = $13.0 billion, 2023-01-01 to 2023-12-31 (us-gaap:OperatingIncomeLoss; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
3. `fact-1b7611484c06` eps_diluted = $20.12 per share, 2023-01-01 to 2023-12-31 (us-gaap:EarningsPerShareDiluted; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
4. `fact-769e00e57f45` diluted_shares = 513.6 million shares, 2023-01-01 to 2023-12-31 (us-gaap:WeightedAverageNumberOfDilutedSharesOutstanding; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
5. `fact-ff2db89dc8b4` revenue = $59.4 billion, 2022-01-01 to 2022-12-31 (us-gaap:Revenues; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
6. `calc-69cf3bb22b31` growth(current=`fact-fc5b1ab7ac2d`, previous=`fact-ff2db89dc8b4`) = 12.8%, 2022-01-01 to 2023-12-31
7. `fact-2e7c5b75b635` operating_income = $7.9 billion, 2022-01-01 to 2022-12-31 (us-gaap:OperatingIncomeLoss; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
8. `calc-f6dc1c5ed88f` growth(current=`fact-c44667ed171a`, previous=`fact-2e7c5b75b635`) = 64.0%, 2022-01-01 to 2023-12-31
9. `fact-9cac75e40631` long_term_debt = $24.5 billion, at 2023-12-31 (us-gaap:LongTermDebtNoncurrent; 10-K 0000018230-24-000009, filed 2024-02-16) https://www.sec.gov/Archives/edgar/data/18230/000001823024000009/
