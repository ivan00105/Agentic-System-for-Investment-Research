# What was Lockheed Martin's two-year compound annual growth rate of total net sales from 2020 to 2022?

- Run status: failed
- Cutoff: 2023-02-28T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free
- Run: 20261125-050749-671b09
- Error: The selected model or provider endpoint is unavailable. Saved results remain available; retry explicitly later.

## Summary (abstained)

- Nothing to report.

## Key numbers (abstained)

- Nothing to report.

## Bull case (abstained)

- Nothing to report.

## Bear case (abstained)

- Nothing to report.

## Risks (abstained)

- Nothing to report.

## What would change the view (abstained)

- Nothing to report.

## Limitations

- The model did not hand in a report (The selected model or provider endpoint is unavailable. Saved results remain available; retry explicitly later.). Every section is abstained; the 0 records gathered before it stopped are listed as sources.
