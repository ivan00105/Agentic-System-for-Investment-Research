# Evaluation scores

4 runs of 4 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| B | 4 | 0/4 (0%) | 2/13 (15%) | 1/4 (25%) | 6 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-clean-cat-2023 | B | 1 | finished | 2/3 | answered | no | 0 |
| held-fb-aes-fy2022-roa | B | 1 | failed | 0/4 | abstained (wrong) | no | 3 |
| held-fb-gis-fy2020-fcf | B | 1 | failed | 0/3 | abstained (wrong) | no | 2 |
| held-fb-lmt-fy2022-revenue-cagr | B | 1 | failed | 0/3 | abstained (wrong) | no | 1 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| B | 4 | 0% (0% to 0%) | - | - | 1/4 | 1/1 | no passes |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

(none)

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| B | 4 | 12 | 9/12 (75%) | 3 | 18/24 | 0 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

No D runs in this batch.

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| B | 4 | 3 | 2 | 43,927 | 52% | 2,017 | $0.0000 | $0.0000 | 1.3 | 13.7 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

| Case | Condition | Repeat | What went wrong |
|---|---|---|---|
| held-clean-cat-2023 | B | 1 | profit_2023: missing |
| held-fb-aes-fy2022-roa | B | 1 | failed: The selected model or provider endpoint is unavailable. Saved results remain available; retry explicitly later.; shows no number; net_income_attributable_2022: missing; total_assets_2022: missing; total_assets_2021: missing; return_on_average_assets_2022: needs review |
| held-fb-gis-fy2020-fcf | B | 1 | failed: The selected model or provider endpoint is unavailable. Saved results remain available; retry explicitly later.; shows no number; operating_cash_flow_fy2020: missing; capex_fy2020: missing; fcf_fy2020: missing |
| held-fb-lmt-fy2022-revenue-cagr | B | 1 | failed: The selected model or provider endpoint is unavailable. Saved results remain available; retry explicitly later.; shows no number; total_net_sales_2022: missing; total_net_sales_2020: missing; revenue_cagr_2020_2022: missing |

Runs that ended without a report (failed, stopped or crashed): B: 3/4 (75%).

## Needs review

### held-fb-aes-fy2022-roa

What was AES's return on assets in 2022, defined as net income attributable to AES over the average of total assets at the end of 2021 and 2022?

- Must not: Uses "NET INCOME (LOSS)" of -505, which includes noncontrolling interests, instead of the -546 attributable to AES.
- Must not: Reports a positive return on assets.
- B1, Gold return_on_average_assets_2022: No tool record measures 'return_on_average_assets'.

Reports: reports/held-fb-aes-fy2022-roa--B1.md

### held-fb-gis-fy2020-fcf

What was General Mills' free cash flow (operating cash flow minus capital expenditure) in fiscal 2020?

- Must mention: The period is the fiscal year ended 31 May 2020.
- Must not: Subtracts total investing cash flow (486.2) instead of capital expenditure.

Reports: reports/held-fb-gis-fy2020-fcf--B1.md

### held-fb-lmt-fy2022-revenue-cagr

What was Lockheed Martin's two-year compound annual growth rate of total net sales from 2020 to 2022?

- Must not: Gives the 2021-to-2022 change (about -1.6%) as the two-year growth rate.

Reports: reports/held-fb-lmt-fy2022-revenue-cagr--B1.md
