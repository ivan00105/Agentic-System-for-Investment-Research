# Evaluation scores

3 runs of 1 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| B | 1 | 1/1 (100%) | 3/3 (100%) | 1/1 (100%) | 3 |
| C | 1 | 1/1 (100%) | 3/3 (100%) | 1/1 (100%) | 3 |
| D | 1 | 1/1 (100%) | 3/3 (100%) | 1/1 (100%) | 3 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-trap-cost-fy2023-53-week-growth | B | 1 | finished | 3/3 | answered | yes | 3 |
| held-trap-cost-fy2023-53-week-growth | C | 1 | finished | 3/3 | answered | yes | 3 |
| held-trap-cost-fy2023-53-week-growth | D | 1 | finished | 3/3 | answered | yes | 3 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| B | 1 | 100% (one case: no interval) | - | - | 1/1 | 0/1 | $0.0000 |
| C | 1 | 100% (one case: no interval) | - | - | 1/1 | 0/1 | $0.0000 |
| D | 1 | 100% (one case: no interval) | - | - | 1/1 | 0/1 | $0.0000 |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

| Comparison | Shared cases | Before | After | Difference (95% interval) |
|---|---|---|---|---|
| C vs B | 1 | 100% | 100% | +0% (one case: no interval) |
| D vs C | 1 | 100% | 100% | +0% (one case: no interval) |

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| B | 1 | 10 | 10/10 (100%) | 0 | 0/6 | 5 |
| C | 1 | 28 | 6/28 (21%) | 22 | 0/6 | 0 |
| D | 1 | 9 | 9/9 (100%) | 0 | 0/6 | 0 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

| Case | Repeat | Objections | Defended | Corrected | Withdrawn | Unresolved | Fixed | Damaged | D right, C wrong | D wrong, C right |
|---|---|---|---|---|---|---|---|---|---|---|
| held-trap-cost-fy2023-53-week-growth | 1 | 2 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |

Fixed and Damaged compare the draft the critic first saw with the final report, on the same evidence; '-' means the critic never ran. The C columns compare with the C run of the same case and repeat, which retrieved its own evidence. Whether each objection was valid needs review (2 objections in 1 runs).

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| B | 1 | 7 | 4 | 71,273 | 68% | 3,102 | $0.0000 | $0.0000 | 1.3 | 1.3 |
| C | 1 | 19 | 14 | 158,470 | 44% | 7,977 | $0.0000 | $0.0000 | 4.1 | 4.1 |
| D | 1 | 17 | 9 | 119,067 | 37% | 14,323 | $0.0000 | $0.0000 | 7.2 | 7.2 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

(none)

Runs that ended without a report (failed, stopped or crashed): B: 0/1 (0%), C: 0/1 (0%), D: 0/1 (0%).

## Needs review

### held-trap-cost-fy2023-53-week-growth

How much did Costco's total revenue grow in fiscal 2023?

- Must mention: Fiscal 2023 had 53 weeks (ended 3 September 2023) and fiscal 2022 had 52 (ended 28 August 2022), so part of the growth is the extra week.
- Must not: Presents the growth as like-for-like without mentioning the extra week.
- Must not: Uses net sales (237,710 and 222,730) as total revenue without saying so.

Reports: reports/held-trap-cost-fy2023-53-week-growth--B1.md, reports/held-trap-cost-fy2023-53-week-growth--C1.md, reports/held-trap-cost-fy2023-53-week-growth--D1.md
