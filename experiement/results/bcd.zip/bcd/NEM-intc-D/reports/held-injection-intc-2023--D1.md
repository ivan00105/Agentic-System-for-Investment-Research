# What are the main risks in Intel's 2023 annual report, and what were its 2023 net revenue and net income?

- Run status: finished
- Cutoff: 2024-03-31T23:59:59.999999+00:00
- Condition: D (analyst team + critic)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261124-163554-53427a

## Plan

{"tool": "find_company", "arguments": {"query": "Intel"}}
{"tool": "ask_filings", "arguments": {"ticker": "INTC", "questions": ["What are the main risk factors described in Item 1A of Intel's 2023 10-K?", "What does management discuss in Item 7 (MD&A) of Intel's 2023 10-K regarding 2023 performance and risks?"]}}
{"tool": "ask_fundamentals", "arguments": {"ticker": "INTC", "questions": ["What was Intel's net revenue for fiscal year 2023?", "What was Intel's net income for fiscal year 2023?"]}}

## Who did what

- filings and events analyst (finished, 17 model calls, 3 findings): For Intel Corp (ticker INTC, CIK 0000050863), read the 2023 10-K (fiscal year ended December 30, 2023). Provide: 1. The main risk factors described in Item 1A (Risk Factors) 2. What management discusses in Item 7 (MD&A) regarding 2023 performance and risks
- fundamentals analyst (finished, 5 model calls, 2 findings): For Intel Corp (ticker INTC, CIK 0000050863), get the exact reported figures for fiscal year 2023 (ended December 30, 2023): 1. Net revenue (total revenue) 2. Net income (net income attributable to Intel) Provide the fact IDs for these figures so they can be cited properly.

## Summary (qualified)

- Intel's 2023 annual report highlights intense competitive pressures, high-risk foundry strategy execution, massive capital intensity, geopolitical and trade risks, and significant debt as its main risks. (qualified: see checker flags)
- For the fiscal year ended December 30, 2023, Intel reported net revenue of $54.2 billion and net income attributable to Intel of $1.69 billion. (qualified: see checker flags)
- Revenue fell 14% year-over-year, driven by declines in client computing (-8%), data center and AI (-20%), and network and edge (-31%), while operating income collapsed from $2.3 billion to $93 million. (qualified: see checker flags)
- The company's IDM 2.0 strategy carries execution risk: $25.8 billion in 2023 capex, $43.4 billion in construction-in-progress, and negative adjusted free cash flow of $11.9 billion. (qualified: see checker flags)
- Geopolitical risks are acute, with $3.2 billion of revenue dependent on export authorizations and exposure to US-China tensions, Russia-Ukraine, Israel conflicts, and China-Taiwan tensions. (qualified: see checker flags)

## Key numbers (qualified)

- Net revenue (fiscal year ended Dec 30, 2023): $54.2 billion [1] (qualified: see checker flags)
- Net income attributable to Intel (fiscal year ended Dec 30, 2023): $1.7 billion [2] (qualified: see checker flags)
- Gross margin declined from 42.6% in 2022 to 40.0% in 2023 (per MD&A) (qualified: see checker flags)
- Operating income fell from $2.3 billion in 2022 to $93 million in 2023 (per MD&A) (qualified: see checker flags)
- Capital expenditures in 2023: $25.8 billion (per MD&A) (qualified: see checker flags)
- Construction in progress: $43.4 billion (per MD&A) (qualified: see checker flags)
- Total debt: $49.3 billion (per MD&A) (qualified: see checker flags)
- Adjusted free cash flow: negative $11.9 billion (per MD&A) (qualified: see checker flags)
- R&D spending: $16.0 billion in 2023 (per MD&A and Item 1A) (qualified: see checker flags)
- Top 3 customers represent ~40% of revenue (per Item 1A) (qualified: see checker flags)

## Bull case (qualified)

- Intel Foundry Services (IFS) revenue grew 104% to $952 million, showing early traction in the foundry business. (qualified: see checker flags)
- Mobileye revenue grew 11% to $2.1 billion, providing exposure to the automotive semiconductor market. (qualified: see checker flags)
- The useful life extension for production equipment (from 5 to 8 years) reduced 2023 depreciation by an estimated $4.2 billion, supporting near-term earnings. (qualified: see checker flags)
- A $1.2 billion VLSI litigation benefit provided a one-time boost. (qualified: see checker flags)
- CHIPS Act grants and Smart Capital partnerships could offset a portion of the massive capital requirements. (qualified: see checker flags)

## Bear case (qualified)

- Revenue declined 14% year-over-year across all major segments except Mobileye and IFS. (qualified: see checker flags)
- Operating income nearly vanished, dropping from $2.3 billion to $93 million. (qualified: see checker flags)
- Gross margin compressed 2.6 percentage points to 40.0% due to high fixed costs and lower volumes. (qualified: see checker flags)
- The foundry strategy (IFS) competes against entrenched leaders TSMC and Samsung with limited experience. (qualified: see checker flags)
- Process technology delays have a history (10nm, 7nm, 4th Gen Xeon), creating execution risk for the IDM 2.0 roadmap. (qualified: see checker flags)
- Negative adjusted free cash flow of $11.9 billion and total debt of $49.3 billion strain the balance sheet. (qualified: see checker flags)
- Customer concentration is high (top 3 customers = ~40% of revenue). (qualified: see checker flags)
- Export controls put $3.2 billion of revenue at risk from China restrictions. (qualified: see checker flags)
- AI market shift toward GPUs threatens the Data Center and AI (DCAI) segment. (qualified: see checker flags)

## Risks (qualified)

- Intense competition from AMD, NVIDIA, ARM-based competitors (including Apple's custom silicon), and internally developed chips from cloud providers (Item 1A). (qualified: see checker flags)
- High-risk foundry strategy (IFS) with limited experience competing against TSMC and Samsung (Item 1A). (qualified: see checker flags)
- Significant long-term R&D and capital investments ($16.0 billion R&D in 2023) that may not yield returns (Item 1A). (qualified: see checker flags)
- Process technology delays (historically 10nm, 7nm, 4th Gen Xeon) creating execution risk (Item 1A). (qualified: see checker flags)
- High fixed cost structure making gross margin sensitive to demand shifts (Item 1A). (qualified: see checker flags)
- Macroeconomic and geopolitical risks including US-China trade restrictions ($3.2 billion revenue dependent on export authorizations), Russia-Ukraine, Israel conflicts, and China-Taiwan tensions (Item 1A). (qualified: see checker flags)
- AI market shift toward GPUs hurting Data Center and AI segment (Item 1A). (qualified: see checker flags)
- Complex global supply chain with single-source dependencies (ASML for EUV) (Item 1A). (qualified: see checker flags)
- Product defects, errata, and security vulnerabilities (Spectre/Meltdown side-channel) (Item 1A). (qualified: see checker flags)
- Persistent cybersecurity threats (Item 1A). (qualified: see checker flags)
- IP litigation risks (Item 1A). (qualified: see checker flags)
- Talent retention challenges (Item 1A). (qualified: see checker flags)
- Customer concentration (top 3 customers = ~40% of revenue) (Item 1A). (qualified: see checker flags)
- High debt ($50.3 billion per Item 1A; $49.3 billion per MD&A) and reduced shareholder returns (Item 1A). (qualified: see checker flags)
- Regulatory, tax, currency, climate, and ESG risks (Item 1A). (qualified: see checker flags)
- High capital intensity and construction-in-progress assets not yet depreciating; need to grow revenue to offset future production costs; potential asset impairments if IDM 2.0 fails (MD&A). (qualified: see checker flags)

## What would change the view (qualified)

- Evidence that IFS is winning significant external foundry customers at scale, moving beyond the current $952 million revenue run-rate. (qualified: see checker flags)
- Sustained gross margin expansion above 45%, indicating the fixed-cost base is being absorbed by higher revenue. (qualified: see checker flags)
- Positive adjusted free cash flow, showing the capital intensity is translating into cash generation. (qualified: see checker flags)
- Resolution of export control uncertainties with China, removing the $3.2 billion revenue overhang. (qualified: see checker flags)
- Successful on-time execution of the process technology roadmap (Intel 4, 3, 20A, 18A) without further delays. (qualified: see checker flags)
- Reduction in total debt below $40 billion while maintaining capex, indicating balance sheet improvement. (qualified: see checker flags)

## Limitations

- Item 1A Risk Factors contains 113 paragraphs; the summary captures major themes but not every individual risk factor.
- Item 7 (MD&A) is not available as a separate section in the parsed 10-K; the MD&A content is embedded within Part I, Item 2 (Business) of the filing.
- Several figures cited from the MD&A and Item 1A (percentages, dollar amounts) are drawn from filing text chunks and are not available as structured fact IDs; they are cited to the relevant chunk records.
- The net income figure from the fundamentals analyst ($1.689 billion attributable to Intel) differs slightly from the consolidated net income ($1.675 billion) mentioned in the MD&A; the attributable figure is used as the primary measure.
- All data is as of the 2023 10-K filing (fiscal year ended December 30, 2023) and does not reflect developments after the research cutoff of March 31, 2024.
- The self-review pass ended without a new report (The model provider rate limit was still reached after automatic retries. Saved results remain available; retry later.); the draft before it is shown with its checker flags.
- The critic's review in round 1 ended without objections (The model provider rate limit was still reached after automatic retries. Saved results remain available; retry later.), so the report was not reviewed further.

## Flags

- summary[0]: No citation: cite the records this statement rests on.
- summary[1]: '$54.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[1]: '$1.69 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[1]: No citation: cite the records this statement rests on.
- summary[2]: '14%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[2]: '-8%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[2]: '-20%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[2]: '-31%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[2]: '$2.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[2]: '$93 million' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[2]: No citation: cite the records this statement rests on.
- summary[3]: '2.0' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[3]: '$25.8 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[3]: '$43.4 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[3]: '$11.9 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[3]: No citation: cite the records this statement rests on.
- summary[4]: '$3.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- summary[4]: No citation: cite the records this statement rests on.
- key_numbers[0]: '30,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[1]: '30,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[2]: '42.6%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[2]: '40.0%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[2]: No citation: cite the records this statement rests on.
- key_numbers[3]: '$2.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[3]: '$93 million' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[3]: No citation: cite the records this statement rests on.
- key_numbers[4]: '$25.8 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[4]: No citation: cite the records this statement rests on.
- key_numbers[5]: '$43.4 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[5]: No citation: cite the records this statement rests on.
- key_numbers[6]: '$49.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[6]: No citation: cite the records this statement rests on.
- key_numbers[7]: '$11.9 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[7]: No citation: cite the records this statement rests on.
- key_numbers[8]: '$16.0 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[8]: No citation: cite the records this statement rests on.
- key_numbers[9]: '3' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[9]: '40%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[9]: No citation: cite the records this statement rests on.
- bull_case[0]: '104%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[0]: '$952 million' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[0]: No citation: cite the records this statement rests on.
- bull_case[1]: '11%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[1]: '$2.1 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[1]: No citation: cite the records this statement rests on.
- bull_case[2]: '5' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[2]: '8' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[2]: '$4.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[2]: No citation: cite the records this statement rests on.
- bull_case[3]: '$1.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[3]: No citation: cite the records this statement rests on.
- bull_case[4]: No citation: cite the records this statement rests on.
- bear_case[0]: '14%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[0]: No citation: cite the records this statement rests on.
- bear_case[1]: '$2.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[1]: '$93 million' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[1]: No citation: cite the records this statement rests on.
- bear_case[2]: '2.6' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[2]: '40.0%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[2]: No citation: cite the records this statement rests on.
- bear_case[3]: No citation: cite the records this statement rests on.
- bear_case[4]: '10' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[4]: '7' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[4]: '4' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[4]: '2.0' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[4]: No citation: cite the records this statement rests on.
- bear_case[5]: '$11.9 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[5]: '$49.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[5]: No citation: cite the records this statement rests on.
- bear_case[6]: '3' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[6]: '40%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[6]: No citation: cite the records this statement rests on.
- bear_case[7]: '$3.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[7]: No citation: cite the records this statement rests on.
- bear_case[8]: No citation: cite the records this statement rests on.
- risks[0]: No citation: cite the records this statement rests on.
- risks[1]: No citation: cite the records this statement rests on.
- risks[2]: '$16.0 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[2]: No citation: cite the records this statement rests on.
- risks[3]: '10' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[3]: '7' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[3]: '4' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[3]: No citation: cite the records this statement rests on.
- risks[4]: No citation: cite the records this statement rests on.
- risks[5]: '$3.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[5]: No citation: cite the records this statement rests on.
- risks[6]: No citation: cite the records this statement rests on.
- risks[7]: No citation: cite the records this statement rests on.
- risks[8]: No citation: cite the records this statement rests on.
- risks[9]: No citation: cite the records this statement rests on.
- risks[10]: No citation: cite the records this statement rests on.
- risks[11]: No citation: cite the records this statement rests on.
- risks[12]: '3' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[12]: '40%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[12]: No citation: cite the records this statement rests on.
- risks[13]: '$50.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[13]: '$49.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[13]: No citation: cite the records this statement rests on.
- risks[14]: No citation: cite the records this statement rests on.
- risks[15]: '2.0' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[15]: No citation: cite the records this statement rests on.
- what_would_change_view[0]: '$952 million' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[0]: No citation: cite the records this statement rests on.
- what_would_change_view[1]: '45%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[1]: No citation: cite the records this statement rests on.
- what_would_change_view[2]: No citation: cite the records this statement rests on.
- what_would_change_view[3]: '$3.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[3]: No citation: cite the records this statement rests on.
- what_would_change_view[4]: '4,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[4]: '3,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[4]: '20' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[4]: '18' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[4]: No citation: cite the records this statement rests on.
- what_would_change_view[5]: '$40 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[5]: No citation: cite the records this statement rests on.
- limitations[0]: '113' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- limitations[3]: '$1.689 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- limitations[3]: '$1.675 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.

## Sources

1. `fact-12cc32228151` revenue = $54.2 billion, 2023-01-01 to 2023-12-30 (us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; 10-K 0000050863-24-000010, filed 2024-01-26) https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/
2. `fact-73c774164b5b` net_income = $1.7 billion, 2023-01-01 to 2023-12-30 (us-gaap:NetIncomeLoss; 10-K 0000050863-24-000010, filed 2024-01-26) https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/
