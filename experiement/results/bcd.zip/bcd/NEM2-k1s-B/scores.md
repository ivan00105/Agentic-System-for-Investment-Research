# Evaluation scores

1 runs of 1 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| B | 1 | 1/1 (100%) | 3/3 (100%) | 1/1 (100%) | 1 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-fb-lmt-fy2022-revenue-cagr | B | 1 | finished | 3/3 | answered | yes | 1 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| B | 1 | 100% (one case: no interval) | - | - | 1/1 | 0/1 | $0.0000 |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

(none)

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| B | 1 | 9 | 7/9 (78%) | 2 | 0/6 | 3 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

No D runs in this batch.

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| B | 1 | 6 | 3 | 55,457 | 63% | 2,030 | $0.0000 | $0.0000 | 0.6 | 0.6 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

(none)

Runs that ended without a report (failed, stopped or crashed): B: 0/1 (0%).

## Needs review

### held-fb-lmt-fy2022-revenue-cagr

What was Lockheed Martin's two-year compound annual growth rate of total net sales from 2020 to 2022?

- Must not: Gives the 2021-to-2022 change (about -1.6%) as the two-year growth rate.

Reports: reports/held-fb-lmt-fy2022-revenue-cagr--B1.md
