# What was Lockheed Martin's two-year compound annual growth rate of total net sales from 2020 to 2022?

- Run status: finished
- Cutoff: 2023-02-28T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261125-052648-9627ad

## Plan

{
  "tool": "find_company",
  "args": {"query": "Lockheed Martin"}
}

## Summary (cited)

- Lockheed Martin's total net sales grew at a compound annual growth rate of 0.4% from 2020 to 2022. [1]
- Revenue was $65.4 billion in 2020 and $66.0 billion in 2022, showing minimal growth over the two-year period. [2] [3]

## Key numbers (cited)

- Total net sales (revenue) for fiscal year ended 2020-12-31: $65.4 billion [2]
- Total net sales (revenue) for fiscal year ended 2022-12-31: $66.0 billion [3]
- Two-year CAGR of total net sales from 2020 to 2022: 0.4% [1]

## Bull case (cited)

- Revenue remained stable above $65.4 billion across both years, indicating resilient demand for defense products. [2] [3]

## Bear case (cited)

- Revenue growth was essentially flat (0.4% CAGR) over the two-year period, suggesting limited organic expansion. [1]

## Risks (qualified)

- Defense spending cycles and budget pressures could constrain future revenue growth. (qualified: see checker flags)

## What would change the view (qualified)

- A significant new contract award or major program cancellation would change the revenue trajectory. (qualified: see checker flags)

## Limitations

- The calculation uses only the two endpoints (2020 and 2022); intermediate year 2021 revenue was $67.0 billion, showing a dip in 2022 from the 2021 peak.

## Flags

- risks[0]: No citation: cite the records this statement rests on.
- what_would_change_view[0]: No citation: cite the records this statement rests on.

## Sources

1. `calc-680fd0d74a51` cagr(first=`fact-774709bd0a89`, last=`fact-37356adba3db`) = 0.4%, 2020-01-01 to 2022-12-31
2. `fact-774709bd0a89` revenue = $65.4 billion, 2020-01-01 to 2020-12-31 (us-gaap:Revenues; 10-K 0000936468-23-000009, filed 2023-01-26) https://www.sec.gov/Archives/edgar/data/936468/000093646823000009/
3. `fact-37356adba3db` revenue = $66.0 billion, 2022-01-01 to 2022-12-31 (us-gaap:Revenues; 10-K 0000936468-23-000009, filed 2023-01-26) https://www.sec.gov/Archives/edgar/data/936468/000093646823000009/
4. `fact-cf4af97d6258` revenue = $67.0 billion, 2021-01-01 to 2021-12-31 (us-gaap:Revenues; 10-K 0000936468-23-000009, filed 2023-01-26) https://www.sec.gov/Archives/edgar/data/936468/000093646823000009/
