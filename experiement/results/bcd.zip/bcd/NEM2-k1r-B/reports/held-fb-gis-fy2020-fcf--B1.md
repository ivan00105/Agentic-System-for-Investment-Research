# What was General Mills' free cash flow (operating cash flow minus capital expenditure) in fiscal 2020?

- Run status: finished
- Cutoff: 2020-08-31T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261125-052539-7ebdf3

## Plan

1. **Identify the company**: Use `find_company` to get General Mills' CIK and ticker (likely GIS).
2. **Retrieve financials**: Call `get_financials` for General Mills to obtain annual cash-flow data (operating cash flow and capital expenditure) for fiscal 2020 (the fiscal year ending around May 2020).
3. **Calculate free cash flow**: Use `calculate` with the `fcf` formula (operating cash flow minus capital expenditure) on the fact IDs returned for fiscal 2020.
4. **Verify if needed**: Optionally use `verify_against_filing` to confirm the cash-flow figures against the 10-K filing.

## Summary (cited)

- General Mills generated $3.2 billion of free cash flow in fiscal 2020 (year ended May 31, 2020). [1]
- Operating cash flow was $3.7 billion and capital expenditure was $460.8 million, yielding the free cash flow figure. [2] [3]

## Key numbers (cited)

- Free cash flow (operating cash flow minus capital expenditure) for fiscal 2020: $3.2 billion [1]
- Operating cash flow for fiscal 2020: $3.7 billion [2]
- Capital expenditure for fiscal 2020: $460.8 million [3]

## Bull case (cited)

- Strong operating cash flow generation of $3.7 billion supports dividend payments and share repurchases. [2]

## Bear case (cited)

- Capital expenditure of $460.8 million, while moderate, reduces free cash flow available to shareholders. [3]

## Risks (cited)

- Free cash flow is a non-GAAP measure and may vary based on working capital changes and investment needs. [1]

## What would change the view (cited)

- A significant decline in operating cash flow or a sharp increase in capital expenditure would reduce free cash flow. [2] [3]

## Limitations

- The calculation uses SEC-reported operating cash flow and capital expenditure from the 10-K filing; free cash flow is not a GAAP measure and definitions can vary.

## Sources

1. `calc-48a01defc5f1` fcf(operating_cash_flow=`fact-1ebcb5878697`, capex=`fact-15ca9dc89a2a`) = $3.2 billion, 2019-05-27 to 2020-05-31. Free cash flow is non-GAAP: operating cash flow minus capital expenditure.
2. `fact-1ebcb5878697` operating_cash_flow = $3.7 billion, 2019-05-27 to 2020-05-31 (us-gaap:NetCashProvidedByUsedInOperatingActivities; 10-K 0001193125-20-186469, filed 2020-07-02) https://www.sec.gov/Archives/edgar/data/40704/000119312520186469/
3. `fact-15ca9dc89a2a` capex = $460.8 million, 2019-05-27 to 2020-05-31 (us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; 10-K 0001193125-20-186469, filed 2020-07-02) https://www.sec.gov/Archives/edgar/data/40704/000119312520186469/
