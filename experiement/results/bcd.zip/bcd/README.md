# B-D pilot results (free model nvidia/nemotron-3-ultra-550b-a55b:free, held-out split, one repeat)

Batch 1 (24 Nov 2026): NEM-cost, NEM-intc, NEM-intc-D (rerun after a provider outage), NEM-abnb: B, C, D on Costco, Intel, Airbnb.
BCD-pilot, BCD-held: earlier attempts that failed on credit/provider errors (kept for honesty; not scored).

Batch 2 (25 Nov 2026), experiments/run_bcd_batch2.sh KEYTAG B-cases C-cases D-cases, one free-tier key per line:
- NEM2-k1-B: B on held-clean-cat-2023 (finished); aes, gis, lmt failed on "provider endpoint unavailable" (0-3 calls)
- NEM2-k1-C: C on held-clean-cat-2023, failed (provider unavailable, 0 calls)
- NEM2-k2-B: B on held-fb-nflx-fy2015-ebitda-margin, held-fb-wmt-fy2019-operating-margin-change, held-trap-bby-fiscal-2019-revenue
- NEM2-k2-D: D on held-trap-bby-fiscal-2019-revenue
- NEM2-k3-B: B on held-vals-net-2024-channel-partners, held-vals-orcl-fy2024-tax-rate, held-vals-pltr-2024-revenue-cagr
- NEM2-k3-C: C on held-trap-bby-fiscal-2019-revenue
- NEM2-k2-B-aes, NEM2-k1r-B (aes): AES retried twice, failed each time at step 3 (APIConnectionError, provider unavailable)
- NEM2-k1r-B (gis): B on held-fb-gis-fy2020-fcf (finished)
- NEM2-k2r-B, NEM2-k3r-C: lmt B and cat C, failed: free-models-per-day limit (50) reached on keys 2 and 3
- NEM2-k1s-B: B on held-fb-lmt-fy2022-revenue-cagr (finished)

Coverage: B has a report for 12 of 13 held-out cases (AES failed on provider errors three times);
C and D cover Costco, Intel, Airbnb, Best Buy. Must-mention/must-not rules were judged by one reader.
