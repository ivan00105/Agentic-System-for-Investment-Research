# What was Airbnb's revenue in 2019, and how fast did it grow?

- Run status: finished
- Cutoff: 2020-06-30T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261124-162050-bf16ec

## Plan

{
  "steps": [
    {
      "action": "find_company",
      "params": {
        "query": "ABNB"
      },
      "purpose": "Identify Airbnb's CIK and confirm it is a US-listed company"
    },
    {
      "action": "get_financials",
      "params": {
        "cik": "<CIK from find_company>",
        "periods": ["2019", "2018"]
      },
      "purpose": "Retrieve Airbnb's revenue for fiscal years 2019 and 2018 (newest first) to compute growth"
    },
    {
      "action": "calculate",
      "params": {
        "formula": "growth",
        "ids": {
          "current": "<revenue fact ID for 2019>",
          "prior": "<revenue fact ID for 2018>"
        }
      },
      "purpose": "Calculate year-over-year revenue growth rate from 2018 to 2019"
    }
  ],
  "notes": [
    "Airbnb went public in December 2020; as of the 2020-06-30 cutoff, its 2019 and 2018 annual financials may only be available in its S-1 registration statement, not yet in a 10-K. The get_financials tool pulls from 10-K/20-F/40-F filings, so 2019 data might not be present. If get_financials returns no data for 2019, we will need to read the S-1 filing via list_filings and read_filing_section, but S-1 is not a supported form for get_financials. We'll first attempt get_financials and adapt if needed."
  ]
}

## Summary (qualified)

- As of the research cutoff (2020-06-30), Airbnb's 2019 revenue and growth rate are not available in the SEC annual filing data accessible to the tools. (qualified: see checker flags)
- Airbnb had not yet filed a 10-K, 10-Q, or S-1 registration statement before the cutoff; its initial public offering occurred in December 2020. (qualified: see checker flags)

## Key numbers (abstained)

- Nothing to report.

## Bull case (abstained)

- Nothing to report.

## Bear case (abstained)

- Nothing to report.

## Risks (abstained)

- Nothing to report.

## What would change the view (qualified)

- If Airbnb's S-1 or 10-K filings become available in the SEC structured data after the cutoff, the 2019 revenue and year-over-year growth could be calculated. (qualified: see checker flags)

## Limitations

- The get_financials tool only retrieves data from 10-K, 20-F, and 40-F annual reports. Airbnb's pre-IPO financials were disclosed in its S-1 registration statement (filed November 2020), which is after the 2020-06-30 research cutoff and is not a supported form for get_financials.
- The list_filings tool shows no SEC filings for Airbnb before the cutoff, confirming that no annual report data is available in the system.
- Therefore, the 2019 revenue figure and growth rate cannot be provided from the available evidence.

## Flags

- summary[0]: No citation: cite the records this statement rests on.
- summary[1]: No citation: cite the records this statement rests on.
- what_would_change_view[0]: No citation: cite the records this statement rests on.
