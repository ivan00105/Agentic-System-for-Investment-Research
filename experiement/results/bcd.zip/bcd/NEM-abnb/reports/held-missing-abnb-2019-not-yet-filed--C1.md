# What was Airbnb's revenue in 2019, and how fast did it grow?

- Run status: finished
- Cutoff: 2020-06-30T23:59:59.999999+00:00
- Condition: C (analyst team)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261124-162304-56411f

## Plan

1. **Company identification**: Airbnb (ticker: ABNB). Use `find_company` to confirm CIK and filing status.  
2. **Fiscal periods needed**: FY 2019 revenue (from 10-K) and FY 2018 revenue to compute year-over-year growth.  
3. **Analyst assignment**:  
   - **Fundamentals analyst** (`ask_fundamentals`): Retrieve reported revenue for FY 2019 and FY 2018 from SEC filings; compute growth via `calculate` (growth formula).  
   - No filings or market analyst needed for this purely historical figure.  
4. **Filing sections**: Item 6 (Selected Financial Data) or Item 7 (MD&A) in the 10-K for FY 2019; no 8-K events relevant.  
5. **Potential gaps**: Airbnb went public in Dec 2020; pre-IPO financials are in its S-1/10-K. If the tool only covers post-IPO filings, 2019 data may be unavailable. Also, foreign-currency conversion not applicable (USD filer).

## Who did what

- fundamentals analyst (finished, 3 model calls, 1 findings): For Airbnb, Inc. (CIK 0001559720, ticker ABNB), retrieve reported revenue for fiscal year 2019 and fiscal year 2018 from SEC filings. Compute year-over-year revenue growth from 2018 to 2019. Provide the revenue figures and growth rate with citations to the filing records.

## Summary (qualified)

- As of the research cutoff (2020-06-30), Airbnb's revenue for fiscal year 2019 and its growth rate from 2018 are not available in SEC annual report filings. (qualified: see checker flags)
- Airbnb had not yet filed any annual report (Form 10-K) as of the cutoff; its first annual report would be filed after its IPO. (qualified: see checker flags)
- Therefore, neither the 2019 revenue figure nor the year-over-year growth rate can be provided from the available data. (qualified: see checker flags)

## Key numbers (abstained)

- Nothing to report.

## Bull case (abstained)

- Nothing to report.

## Bear case (abstained)

- Nothing to report.

## Risks (abstained)

- Nothing to report.

## What would change the view (qualified)

- The publication of Airbnb's first annual report (Form 10-K) after its IPO would provide historical revenue for 2019 and 2018, enabling a growth calculation. (qualified: see checker flags)

## Limitations

- The fundamentals analyst's tool (get_financials) only covers annual reports (Form 10-K, 20-F, 40-F) filed with the SEC. As of 2020-06-30, Airbnb had not yet filed any annual report. Its S-1 registration statement, which contains pre-IPO historical financials, was filed after the cutoff and is not included in the structured dataset.

## Flags

- summary[0]: No citation: cite the records this statement rests on.
- summary[1]: No citation: cite the records this statement rests on.
- summary[2]: No citation: cite the records this statement rests on.
- what_would_change_view[0]: No citation: cite the records this statement rests on.
