# What was Airbnb's revenue in 2019, and how fast did it grow?

- Run status: finished
- Cutoff: 2020-06-30T23:59:59.999999+00:00
- Condition: D (analyst team + critic)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261124-162514-d7ec34

## Plan

1. **Identify the company** – Use `find_company` with ticker "ABNB" to confirm Airbnb's CIK, SIC industry, and that it is a US‑listed filer (not a bank/insurer or IFRS foreign filer).

2. **Retrieve reported revenue for the relevant fiscal periods** – Ask the **fundamentals analyst** (`ask_fundamentals`) for Airbnb’s revenue from the 10‑K filings for fiscal years ending 2018‑12‑31 and 2019‑12‑31. The analyst will pull the figures from the SEC filings and cite the record IDs.

3. **Calculate year‑over‑year revenue growth** – Use the `calculate` tool with the `growth` formula on the two revenue values (2018 and 2019) to compute the percentage growth rate. Cite the resulting calculation ID.

4. **Optional context from filings** – If the growth figure needs qualitative explanation, ask the **filings analyst** (`ask_filings`) to read Item 7 (Management’s Discussion) of the 2019 10‑K for management’s commentary on revenue drivers. Recent 8‑K events are unlikely to affect the 2019 full‑year number, so they can be skipped.

5. **Potential gaps** – Airbnb’s 2019 financials are from its pre‑IPO period (IPO was Dec 2020), so the 10‑K for FY2019 was filed as part of the S‑1 registration statement. The fundamentals analyst can still retrieve the audited figures. No bank/insurer or IFRS complications apply.

## Who did what

- fundamentals analyst (finished, 3 model calls, 1 findings): For Airbnb, Inc. (CIK 0001559720, ticker ABNB), get the reported revenue from the 10-K filings for fiscal years ending 2018-12-31 and 2019-12-31. Provide the revenue figures with their record IDs.
- filings and events analyst (finished, 4 model calls, 0 findings): For Airbnb, Inc. (CIK 0001559720), find the S-1 registration statement filed in 2020 (likely November 2020) that contains audited financial statements for fiscal years 2018 and 2019. Read the financial statements section to extract revenue for those years. Provide the revenue figures with citations.
- fundamentals analyst (finished, 2 model calls, 1 findings): For Airbnb, Inc. (CIK 0001559720), run get_financials for revenue for fiscal years ending 2018-12-31 and 2019-12-31. Provide the tool's result record IDs (fact IDs) even if the values are not reported.
- fundamentals analyst (finished, 1 model calls, 1 findings): For Airbnb, Inc. (CIK 0001559720), provide the record ID of the get_financials tool result that shows revenue status 'not_reported' for fiscal years 2018 and 2019. I need the underlying tool record ID to cite in the report.
- filings and events analyst (finished, 2 model calls, 1 findings): For Airbnb, Inc. (CIK 0001559720), provide the record ID of the list_filings tool result that shows zero filings before the research cutoff (2020-06-30). I need the underlying tool record ID to cite in the report.

## Summary (qualified)

- Airbnb's 2019 revenue and year-over-year growth cannot be determined from SEC filings as of the research cutoff (2020-06-30). (qualified: see checker flags)
- Airbnb was a private company until its IPO in December 2020; its S-1 registration statement containing audited financials for 2018 and 2019 was filed in November 2020, after the cutoff. (qualified: see checker flags)

## Key numbers (abstained)

- Nothing to report.

## Bull case (abstained)

- Nothing to report.

## Bear case (abstained)

- Nothing to report.

## Risks (abstained)

- Nothing to report.

## What would change the view (qualified)

- Availability of Airbnb's S-1 filing (November 2020) or subsequent 10-K filings would provide audited revenue for fiscal years 2018 and 2019. (qualified: see checker flags)

## Limitations

- The SEC Company Facts dataset (used by get_financials) does not contain revenue for Airbnb for fiscal years ending 2018-12-31 or 2019-12-31 as of the research cutoff.
- No SEC filings for Airbnb exist before 2020-06-30; the S-1 was filed after the cutoff and is not in the tool data.
- Therefore, neither the fundamentals analyst nor the filings analyst could retrieve the 2019 revenue or calculate growth.
- The self-review pass ended without a new report (Model authentication or access was rejected. Check the selected provider credentials and permissions.); the draft before it is shown with its checker flags.
- The critic's review in round 1 ended without objections (The selected model or provider endpoint is unavailable. Saved results remain available; retry explicitly later.), so the report was not reviewed further.

## Flags

- summary[0]: No citation: cite the records this statement rests on.
- summary[1]: No citation: cite the records this statement rests on.
- what_would_change_view[0]: No citation: cite the records this statement rests on.
