# Evaluation scores

3 runs of 1 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| B | 1 | 1/1 (100%) | - | 1/1 (100%) | 3 |
| C | 1 | 1/1 (100%) | - | 1/1 (100%) | 3 |
| D | 1 | 1/1 (100%) | - | 1/1 (100%) | 3 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-missing-abnb-2019-not-yet-filed | B | 1 | finished | - | abstained | yes | 3 |
| held-missing-abnb-2019-not-yet-filed | C | 1 | finished | - | abstained | yes | 3 |
| held-missing-abnb-2019-not-yet-filed | D | 1 | finished | - | abstained | yes | 3 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| B | 1 | 100% (one case: no interval) | - | - | - | - | $0.0000 |
| C | 1 | 100% (one case: no interval) | - | - | - | - | $0.0000 |
| D | 1 | 100% (one case: no interval) | - | - | - | - | $0.0000 |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

| Comparison | Shared cases | Before | After | Difference (95% interval) |
|---|---|---|---|---|
| C vs B | 1 | 100% | 100% | +0% (one case: no interval) |
| D vs C | 1 | 100% | 100% | +0% (one case: no interval) |

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| B | 1 | 3 | 0/3 (0%) | 3 | 4/6 | 0 |
| C | 1 | 4 | 0/4 (0%) | 4 | 4/6 | 0 |
| D | 1 | 3 | 0/3 (0%) | 3 | 4/6 | 0 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

| Case | Repeat | Objections | Defended | Corrected | Withdrawn | Unresolved | Fixed | Damaged | D right, C wrong | D wrong, C right |
|---|---|---|---|---|---|---|---|---|---|---|
| held-missing-abnb-2019-not-yet-filed | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

Fixed and Damaged compare the draft the critic first saw with the final report, on the same evidence; '-' means the critic never ran. The C columns compare with the C run of the same case and repeat, which retrieved its own evidence. Whether each objection was valid needs review (0 objections in 1 runs).

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| B | 1 | 6 | 3 | 52,682 | 67% | 4,483 | $0.0000 | $0.0000 | 2.2 | 2.2 |
| C | 1 | 8 | 4 | 39,476 | 33% | 3,554 | $0.0000 | $0.0000 | 2.2 | 2.2 |
| D | 1 | 20 | 12 | 116,445 | 60% | 9,870 | $0.0000 | $0.0000 | 11.0 | 11.0 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

(none)

Runs that ended without a report (failed, stopped or crashed): B: 0/1 (0%), C: 0/1 (0%), D: 0/1 (0%).

## Needs review

### held-missing-abnb-2019-not-yet-filed

What was Airbnb's revenue in 2019, and how fast did it grow?

- Must mention: No SEC filing with Airbnb's financial statements was public by 30 June 2020 (its only filings were Form D notices of private offerings), so its 2019 revenue isn't available as of the cutoff.
- Must not: Gives a 2019 revenue figure or growth rate, such as 4,805 million (first public in the S-1 filed on 16 November 2020).
- Must not: Mentions Airbnb's listing in December 2020, or any other event, result or price after 30 June 2020.

Reports: reports/held-missing-abnb-2019-not-yet-filed--B1.md, reports/held-missing-abnb-2019-not-yet-filed--C1.md, reports/held-missing-abnb-2019-not-yet-filed--D1.md
