# Evaluation scores

3 runs of 3 cases. Small samples are exploratory (REFERENCE §7): read these as counts, not as significant differences.

## Accuracy

| Condition | Runs | Passed | Gold items correct | Right behaviour | Needs review |
|---|---|---|---|---|---|
| B | 3 | 1/3 (33%) | 4/9 (44%) | 3/3 (100%) | 10 |

Per run:

| Case | Condition | Repeat | Status | Gold correct | Behaviour | Passed | Needs review |
|---|---|---|---|---|---|---|---|
| held-vals-net-2024-channel-partners | B | 1 | finished | 1/3 | answered | no | 4 |
| held-vals-orcl-fy2024-tax-rate | B | 1 | finished | 0/3 | answered | no | 5 |
| held-vals-pltr-2024-revenue-cagr | B | 1 | finished | 3/3 | answered | yes | 1 |

## Uncertainty and reliability

| Condition | Cases | Pass rate (95% interval) | pass@k | pass^k | Coverage | Error among answered | Cost per pass |
|---|---|---|---|---|---|---|---|
| B | 3 | 33% (0% to 100%) | - | - | 3/3 | 2/3 | $0.0000 |

A case is the unit: intervals resample cases (95% bootstrap), so a case run three times counts once. pass@k: cases passed at least once in their k runs; pass^k: passed every time (cases with two or more runs). Coverage: runs that answered, of those whose case has an answer; error among answered: of those, the ones that didn't pass. Cost per pass counts failed runs' cost too. With few cases, or when every case has the same result, the interval is too narrow to trust.

(none)

Each comparison adds one thing: B the tools and loop, C the team, D the critic. An interval that includes 0 means no difference could be shown.

## Support

| Condition | Reports | Claims | Cited, no checker flag | No citation | Sections abstained | Central claims |
|---|---|---|---|---|---|---|
| B | 3 | 30 | 21/30 (70%) | 9 | 0/18 | 8 |

Citation validity is automatic (the checker's flags). Whether the cited evidence really supports a claim needs review: a person judges a sample of the central claims.

## Critic: fixes vs damage (D vs C)

No D runs in this batch.

## Prompt injection: task and attack graded apart

(none)

## Cost, tokens and latency

| Condition | Runs | Model calls / run | Tool calls / run | Prompt tokens / run | Cached | Completion tokens / run | Cost / run | Total cost | Median minutes | p95 minutes |
|---|---|---|---|---|---|---|---|---|---|---|
| B | 3 | 14 | 10 | 354,805 | 76% | 6,407 | $0.0000 | $0.0000 | 3.0 | 4.4 |

Model calls are the steps. Cost is what the provider billed (OpenRouter's usage.cost, cache discount included); '-' where it reported none (A makes no model call). p95 of fewer than 20 runs is about the slowest run.

## Failures

| Case | Condition | Repeat | What went wrong |
|---|---|---|---|
| held-vals-net-2024-channel-partners | B | 1 | channel_partner_revenue_2024: needs review; channel_partner_share_2024: needs review |
| held-vals-orcl-fy2024-tax-rate | B | 1 | effective_tax_rate_fy2024: needs review; effective_tax_rate_fy2023: needs review; effective_tax_rate_change: needs review |

Runs that ended without a report (failed, stopped or crashed): B: 0/3 (0%).

## Needs review

### held-vals-net-2024-channel-partners

In fiscal 2024, what percentage of Cloudflare's revenue came from channel partners?

- Must not: Gives 2023's share (16%) as 2024's.
- Must not: Gives the share of revenue from international customers (49%) instead.
- B1, Gold channel_partner_revenue_2024: No tool record measures 'channel_partner_revenue'.
- B1, Gold channel_partner_share_2024: No tool record measures 'channel_partner_share_of_revenue'.

Reports: reports/held-vals-net-2024-channel-partners--B1.md

### held-vals-orcl-fy2024-tax-rate

What was Oracle's effective tax rate for the fiscal year ended 31 May 2024, and how did it change from the year before, in basis points?

- Must mention: The effective tax rate was 10.9% in fiscal 2024 and 6.8% in fiscal 2023, up about 410 basis points.
- Must not: Gives the non-GAAP rates (19.2% for fiscal 2024, 16.3% for fiscal 2023) as Oracle's effective tax rate.
- B1, Gold effective_tax_rate_fy2024: No tool record measures 'effective_tax_rate'.
- B1, Gold effective_tax_rate_fy2023: No tool record measures 'effective_tax_rate'.
- B1, Gold effective_tax_rate_change: No automatic rule for the unit 'basis points'.

Reports: reports/held-vals-orcl-fy2024-tax-rate--B1.md

### held-vals-pltr-2024-revenue-cagr

What was Palantir Technologies' two-year revenue CAGR from 2022 to 2024?

- Must not: Gives the 2023-to-2024 growth (about 28.8%) as the two-year rate.

Reports: reports/held-vals-pltr-2024-revenue-cagr--B1.md
