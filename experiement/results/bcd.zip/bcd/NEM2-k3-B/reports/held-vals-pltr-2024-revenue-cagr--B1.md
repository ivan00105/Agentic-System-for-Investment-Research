# What was Palantir Technologies' two-year revenue CAGR from 2022 to 2024?

- Run status: finished
- Cutoff: 2025-03-31T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261125-045859-29456c

## Plan

1. **Company identification** – Use `find_company` with ticker "PLTR" to get Palantir Technologies' CIK and confirm it is a US GAAP filer with calendar-year fiscal periods.

2. **Annual revenue data** – Call `get_financials` for the CIK to retrieve revenue (or net sales) for the three most recent fiscal years available at the 2025-03-31 cutoff: FY 2022, FY 2023, and FY 2024. Each value will carry a fact ID for citation.

3. **CAGR calculation** – Use `calculate` with the `cagr` formula, passing the revenue fact IDs for FY 2022 (beginning) and FY 2024 (ending) and setting `years: 2`. This returns the two-year compound annual growth rate with a calc ID to cite.

4. **Verification (optional)** – If needed, cross-check the FY 2022 and FY 2024 revenue figures against the original 10-K filings with `verify_against_filing`.

No filing-section reads or 8-K events are required for this pure historical growth metric.

## Summary (cited)

- Palantir Technologies' two-year revenue CAGR from fiscal year 2022 to fiscal year 2024 was 22.6%. [1]
- Revenue grew from $1.9 billion in FY 2022 to $2.9 billion in FY 2024. [2] [3]
- The compound annual growth rate reflects consistent double-digit expansion over the two-year period, supported by year-over-year growth of 16.7% (2022→2023) and 28.8% (2023→2024). [4] [5]

## Key numbers (cited)

- FY 2022 revenue: $1.9 billion (fiscal year ended 2022-12-31) [2]
- FY 2024 revenue: $2.9 billion (fiscal year ended 2024-12-31) [3]
- Two-year revenue CAGR (2022–2024): 22.6% [1]

## Bull case (cited)

- Revenue increased 50.4% in absolute terms over two years, from $1.9 billion to $2.9 billion. [6] [2] [3]

## Bear case (cited)

- The CAGR calculation is based on only three annual data points; year-over-year growth rates were 16.7% (2022→2023) and 28.8% (2023→2024), showing acceleration but also variability. [4] [5] [2] [7] [3]

## Risks (cited)

- Revenue growth may not continue at the same pace; the 10-K risk factors (Item 1A) highlight dependence on government contracts and competition, and note that government spending caps or changes in budgetary priorities could adversely affect results. [8] [9] [10] [11]

## What would change the view (cited)

- A significant revenue miss in FY 2025 or a change in government spending priorities would alter the growth trajectory, as noted in the 10-K risk factors regarding government budget uncertainty. [8] [9]

## Limitations

- The CAGR is calculated from SEC-reported revenue figures (us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax) for calendar-year fiscal periods ending December 31.
- Only three fiscal years (2022, 2023, 2024) were used; the calculation assumes a two-year compounding period between the 2022 and 2024 fiscal year ends.
- No verification against the original 10-K XBRL tags was performed; the figures come from the SEC's companyfacts API.

## Sources

1. `calc-a4633e9c1dee` cagr(first=`fact-536465e6c141`, last=`fact-53e1820dad1c`) = 22.6%, 2022-01-01 to 2024-12-31
2. `fact-536465e6c141` revenue = $1.9 billion, 2022-01-01 to 2022-12-31 (us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; 10-K 0001321655-25-000022, filed 2025-02-18) https://www.sec.gov/Archives/edgar/data/1321655/000132165525000022/
3. `fact-53e1820dad1c` revenue = $2.9 billion, 2024-01-01 to 2024-12-31 (us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; 10-K 0001321655-25-000022, filed 2025-02-18) https://www.sec.gov/Archives/edgar/data/1321655/000132165525000022/
4. `calc-9c7072757cfb` growth(current=`fact-b405af04014b`, previous=`fact-536465e6c141`) = 16.7%, 2022-01-01 to 2023-12-31
5. `calc-8d9c450e559e` growth(current=`fact-53e1820dad1c`, previous=`fact-b405af04014b`) = 28.8%, 2023-01-01 to 2024-12-31
6. `calc-45a563d31c35` growth(current=`fact-53e1820dad1c`, previous=`fact-536465e6c141`) = 50.4%, 2022-01-01 to 2024-12-31. The two periods end 2.00 years apart, not one.
7. `fact-b405af04014b` revenue = $2.2 billion, 2023-01-01 to 2023-12-31 (us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; 10-K 0001321655-25-000022, filed 2025-02-18) https://www.sec.gov/Archives/edgar/data/1321655/000132165525000022/
8. `chunk-0001321655-25-000022-part_i_item_1a-292` 10-K 0001321655-25-000022, part_i_item_1a paragraph 292 https://www.sec.gov/Archives/edgar/data/1321655/000132165525000022/pltr-20241231.htm
9. `chunk-0001321655-25-000022-part_i_item_1a-259` 10-K 0001321655-25-000022, part_i_item_1a paragraph 259 https://www.sec.gov/Archives/edgar/data/1321655/000132165525000022/pltr-20241231.htm
10. `chunk-0001321655-25-000022-part_i_item_1a-105` 10-K 0001321655-25-000022, part_i_item_1a paragraph 105 https://www.sec.gov/Archives/edgar/data/1321655/000132165525000022/pltr-20241231.htm
11. `chunk-0001321655-25-000022-part_i_item_1a-20` 10-K 0001321655-25-000022, part_i_item_1a paragraph 20 https://www.sec.gov/Archives/edgar/data/1321655/000132165525000022/pltr-20241231.htm
