# In fiscal 2024, what percentage of Cloudflare's revenue came from channel partners?

- Run status: finished
- Cutoff: 2025-03-31T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261125-045136-dc771a

## Plan

1. **Find Cloudflare** – Use `find_company` with name "Cloudflare" to get its CIK and ticker (NET).
2. **Get fiscal 2024 financials** – Call `get_financials` for the CIK to confirm the latest fiscal year is 2024 and collect revenue, but the revenue-by-channel split is not in the structured financials.
3. **Read the 10-K for revenue breakdown** – Use `read_filing_section` on the most recent 10-K (filed early 2025 for FY2024) targeting Item 7 (MD&A) and/or Item 1 (Business) with queries like "channel partner", "partner revenue", "indirect revenue", "channel revenue" to locate the disclosure of what portion of revenue comes from channel partners.
4. **Calculate the percentage** – Once the channel-partner revenue dollar amount and total revenue are identified from the filing text, use `calculate` with formula `ratio` (channel_partner_revenue / total_revenue) to produce the percentage.
5. **Cross-check with 8-Ks if needed** – If the 10-K does not break it out, search recent 8-K earnings releases (`list_filings` with forms=["8-K"] then `read_filing_section`) for any supplemental channel metrics.

## Summary (cited)

- Cloudflare does not disclose what percentage of its fiscal 2024 revenue came from channel partners. [1] [2]
- The 10-K for FY2024 (filed February 20, 2025) breaks out revenue only by geography and by customer type (contracted vs. pay-as-you-go), but not by sales channel (direct vs. indirect/channel). [1] [3]
- The filing confirms Cloudflare sells both directly and through channel partners (managed service providers, resellers, distributors, global system integrators), but provides no dollar amount or percentage for the indirect channel. [2] [4]
- Total FY2024 revenue was $1.7 billion, but the channel-partner share is not reported in SEC filings available through the research cutoff. [5]

## Key numbers (cited)

- FY2024 total revenue: $1.7 billion [5]
- Revenue by geography for FY2024 is disclosed in the filing with percentage breakdowns for US, EMEA, APAC, and Other regions. [1]

## Bull case (cited)

- Cloudflare's disclosure of a dual go-to-market model (direct sales force + channel partner ecosystem) suggests diversified customer acquisition, but the lack of a reported channel-revenue metric prevents assessing its scale or growth. [2] [6]

## Bear case (cited)

- The absence of a channel-revenue breakdown means investors cannot evaluate the contribution, margin profile, or trajectory of the indirect sales channel, which is a common disclosure among SaaS and infrastructure peers. [1]

## Risks (cited)

- Investors have no visibility into the concentration or growth rate of channel-partner revenue, making it harder to assess channel dependency, partner churn risk, or the economics of indirect vs. direct sales. [2] [4]

## What would change the view (cited)

- A future 10-K or 10-Q that adds a revenue-by-channel table (direct vs. indirect/channel) or a management commentary quantifying the channel share would provide the missing visibility. [1] [2]
- An 8-K earnings release or investor presentation that explicitly states the percentage or dollar amount of revenue sourced through channel partners would address the current gap. [1] [2]

## Limitations

- The 10-K Item 7 and Item 1 were searched for keywords including 'channel partner', 'partner revenue', 'indirect revenue', 'channel revenue', 'direct revenue', and 'percentage' — no channel-revenue split was found.
- 8-K earnings releases (Items 2.02) only reference press releases (Exhibit 99.1) which are not included in the SEC filing text and were not accessible via the tools.
- Structured financial data (XBRL) does not contain a line item for channel or indirect revenue.

## Flags

- limitations[1]: '99.1' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.

## Sources

1. `chunk-0001477333-25-000043-part_ii_item_7-20` 10-K 0001477333-25-000043, part_ii_item_7 paragraph 20 https://www.sec.gov/Archives/edgar/data/1477333/000147733325000043/cloud-20241231.htm
2. `chunk-0001477333-25-000043-part_i_item_1-67` 10-K 0001477333-25-000043, part_i_item_1 paragraph 67 https://www.sec.gov/Archives/edgar/data/1477333/000147733325000043/cloud-20241231.htm
3. `chunk-0001477333-25-000043-part_ii_item_7-4` 10-K 0001477333-25-000043, part_ii_item_7 paragraph 4 https://www.sec.gov/Archives/edgar/data/1477333/000147733325000043/cloud-20241231.htm
4. `chunk-0001477333-25-000043-part_ii_item_7-37` 10-K 0001477333-25-000043, part_ii_item_7 paragraph 37 https://www.sec.gov/Archives/edgar/data/1477333/000147733325000043/cloud-20241231.htm
5. `fact-1d31cdc17d6c` revenue = $1.7 billion, 2024-01-01 to 2024-12-31 (us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; 10-K 0001477333-25-000043, filed 2025-02-20) https://www.sec.gov/Archives/edgar/data/1477333/000147733325000043/
6. `chunk-0001477333-25-000043-part_ii_item_7-10` 10-K 0001477333-25-000043, part_ii_item_7 paragraph 10 https://www.sec.gov/Archives/edgar/data/1477333/000147733325000043/cloud-20241231.htm
