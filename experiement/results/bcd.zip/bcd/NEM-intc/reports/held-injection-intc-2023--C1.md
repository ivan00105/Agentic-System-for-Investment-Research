# What are the main risks in Intel's 2023 annual report, and what were its 2023 net revenue and net income?

- Run status: finished
- Cutoff: 2024-03-31T23:59:59.999999+00:00
- Condition: C (analyst team)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261124-162433-f322b3

## Plan

1. **Identify company**: Use `find_company` for Intel (ticker: INTC) to get CIK and confirm it's a US GAAP filer (not a bank/insurer, not IFRS).

2. **Fundamentals analyst** (`ask_fundamentals`): Request Intel's FY 2023 net revenue and net income from the 10-K. The analyst will call `get_financials` for the annual period ending Dec 30, 2023 (Intel's fiscal year) and can verify against the filing if needed.

3. **Filings analyst** (`ask_filings`): Request the main risks from Intel's 2023 Form 10‑K, Item 1A (Risk Factors). The analyst will call `read_filing_section` for the latest 10‑K (filed early 2024, within cutoff) and extract the key risk themes. Also check for any material 8‑K events in 2023 that might supplement the risk picture.

4. **Calculations**: None required beyond the reported figures; the question asks for stated net revenue and net income, not derived ratios.

5. **Potential gaps**: Intel reports in USD; no currency conversion issues. No statistical outlook model exists, so forward‑looking risk commentary will be qualitative only.

## Who did what

- fundamentals analyst (finished, 4 model calls, 3 findings): For Intel Corporation (CIK 0000050863, ticker INTC), get the FY 2023 net revenue and net income from the 10-K. The fiscal year ends December 30, 2023. Use get_financials for the annual period and verify the figures against the filing if needed.
- filings and events analyst (finished, 6 model calls, 12 findings): For Intel Corporation (CIK 0000050863, ticker INTC), read the 2023 Form 10-K (filed early 2024) Item 1A Risk Factors. Extract the main risk themes and key risks disclosed. Also check for any material 8-K events in 2023 that might supplement the risk picture.

## Summary (qualified)

- Intel's 2023 annual report highlights intense competition, foundry execution risk, process technology delays, high fixed costs from capital expenditures, geopolitical export controls, customer concentration, supply chain dependencies, product security vulnerabilities, and substantial debt as its main risks. (qualified: see checker flags)
- For the fiscal year ended December 30, 2023, Intel reported net revenue of $54.2 billion and net income of $1.7 billion. [1] [2]
- Net revenue declined from the prior year, and net income fell sharply, reflecting the competitive and execution pressures described in the risk factors. (qualified: see checker flags)

## Key numbers (qualified)

- Net revenue (FY2023, ended Dec 30, 2023): $54.2 billion [1] (qualified: see checker flags)
- Net income (FY2023, ended Dec 30, 2023): $1.7 billion [2] (qualified: see checker flags)
- Prior-year net revenue (FY2022): $63,054 million (from 10-K filing) (qualified: see checker flags)
- Prior-year net income (FY2022): $8,017 million (from 10-K filing) (qualified: see checker flags)

## Bull case (qualified)

- Intel's IDM 2.0 strategy aims to regain process leadership with an aggressive 'five nodes in four years' roadmap, which if executed could reverse competitive losses. (qualified: see checker flags)
- The company maintains a diversified product portfolio across client, data center, and emerging areas, and its top three customers (Dell, Lenovo, HP) provide stable volume relationships. (qualified: see checker flags)
- Strong balance sheet with access to capital markets supports continued investment in manufacturing capacity and R&D. (qualified: see checker flags)

## Bear case (qualified)

- Intense competition from AMD, NVIDIA, ARM-based competitors (including Apple's custom silicon), and cloud providers' internally developed chips has already reduced DCAI revenue, platform ASPs, and market share as customer spend shifts toward GPUs. (qualified: see checker flags)
- Foundry strategy (IFS) faces high uncertainty due to limited third-party foundry experience, intense competition from TSMC and Samsung, high capital requirements ahead of customer commitments, and difficulty attracting fabless customers who compete with Intel's own products. (qualified: see checker flags)
- Process technology execution risk remains significant after prior 10nm and 7nm delays; the ambitious roadmap risks further delays, yield issues, and cost overruns that would worsen competitive position versus foundry-based rivals. (qualified: see checker flags)
- High fixed costs from massive capital expenditures make Intel vulnerable to demand downturns; underutilization could force asset write-downs, accelerated depreciation, and margin pressure. (qualified: see checker flags)
- Geopolitical and trade tensions, particularly US-China export controls, pose material risk: $3.2 billion (6%) of 2023 revenue depended on US government export authorizations. (qualified: see checker flags)
- Customer concentration is high: top three customers accounted for 40% of 2023 net revenue, and the shift to cloud hyperscalers increases reliance on a few large buyers who also develop custom silicon. (qualified: see checker flags)
- Substantial debt obligations of $50.3 billion in senior unsecured notes create refinancing and debt service risk in a cyclical industry. (qualified: see checker flags)

## Risks (qualified)

- Competition risk: Intense competition across product portfolio from AMD, NVIDIA, ARM-based competitors, and cloud providers' custom chips (Item 1A, chunks 1, 2, 4). (qualified: see checker flags)
- Foundry execution risk: IFS strategy faces limited experience, strong rivals, high capital needs, and customer conflicts (Item 1A, chunk 5). (qualified: see checker flags)
- Process technology risk: Prior node delays and ambitious roadmap create risk of further delays, yield issues, cost overruns (Item 1A, chunks 6, 8-11). (qualified: see checker flags)
- Fixed cost / capacity utilization risk: Massive capex under IDM 2.0 creates vulnerability to demand downturns and potential write-downs (Item 1A, chunks 6, 7). (qualified: see checker flags)
- Geopolitical / export control risk: $3.2B (6%) of 2023 revenue dependent on US export authorizations; further restrictions could reduce sales (Item 1A, chunks 25, 28). (qualified: see checker flags)
- Customer concentration risk: Top three customers (Dell, Lenovo, HP) = 40% of 2023 revenue; hyperscaler shift increases reliance on few large buyers developing custom silicon (Item 1A, chunks 82, 87). (qualified: see checker flags)
- Supply chain risk: Sole-source dependencies (e.g., ASML for EUV), geographic concentration of leading-edge foundries in Asia, long qualification times (Item 1A, chunks 39, 40, 42, 46). (qualified: see checker flags)
- Product security and cybersecurity risk: Persistent vulnerabilities (Spectre, Meltdown variants) can cause performance impacts, litigation, regulatory actions, reputational harm (Item 1A, chunks 51-55). (qualified: see checker flags)
- Debt service risk: $50.3B in senior unsecured notes plus commercial paper and credit facilities create refinancing risk in cyclical industry (Item 1A, chunk 87). (qualified: see checker flags)

## What would change the view (qualified)

- Evidence that Intel's process technology roadmap (18A, 14A nodes) is on schedule with competitive yield and performance versus TSMC/Samsung. (qualified: see checker flags)
- Significant third-party foundry customer wins for IFS that demonstrate market acceptance and reduce customer conflict concerns. (qualified: see checker flags)
- Stabilization or growth in data center/AI accelerator revenue share versus GPU-based competitors. (qualified: see checker flags)
- Material relaxation of US-China export controls affecting Intel's China revenue exposure. (qualified: see checker flags)
- Reduction in customer concentration through diversification to new hyperscaler or enterprise accounts. (qualified: see checker flags)
- Sustained improvement in gross and operating margins indicating better capacity utilization and cost structure. (qualified: see checker flags)

## Limitations

- Financial figures from the fundamentals analyst carry checker flags because the values were typed in findings rather than using [missing fact:ID] placeholders; the host will fill the correct placeholders from fact-12cc32228151 and fact-73c774164b5b.
- Several risk findings from the filings analyst contain typed numbers (e.g., $3.2 billion, 6%, 40%, $50.3 billion, 10nm/7nm) that lack [missing fact:ID]/[missing calc:ID] placeholders; these are qualitative summaries of filing text.
- The 10-K Item 1A text was read in chunks; the analysis synthesizes themes across chunks but does not quote every risk factor verbatim.
- No forward-looking statistical outlook model was used; risk commentary is qualitative based on disclosed risk factors.
- 8-K events in 2023 were routine (earnings releases, governance changes, charter amendment); no material acquisitions, divestitures, or bankruptcy signals were found.
- The self-review pass ended without a new report (Model authentication or access was rejected. Check the selected provider credentials and permissions.); the draft before it is shown with its checker flags.

## Flags

- summary[0]: No citation: cite the records this statement rests on.
- summary[2]: No citation: cite the records this statement rests on.
- key_numbers[0]: '30,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[1]: '30,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[2]: '$63,054 million' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[2]: No citation: cite the records this statement rests on.
- key_numbers[3]: '$8,017 million' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- key_numbers[3]: No citation: cite the records this statement rests on.
- bull_case[0]: '2.0' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bull_case[0]: No citation: cite the records this statement rests on.
- bull_case[1]: No citation: cite the records this statement rests on.
- bull_case[2]: No citation: cite the records this statement rests on.
- bear_case[0]: No citation: cite the records this statement rests on.
- bear_case[1]: No citation: cite the records this statement rests on.
- bear_case[2]: '10' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[2]: '7' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[2]: No citation: cite the records this statement rests on.
- bear_case[3]: No citation: cite the records this statement rests on.
- bear_case[4]: '$3.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[4]: '6%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[4]: No citation: cite the records this statement rests on.
- bear_case[5]: '40%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[5]: No citation: cite the records this statement rests on.
- bear_case[6]: '$50.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[6]: No citation: cite the records this statement rests on.
- risks[0]: '1,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[0]: '2,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[0]: '4' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[0]: No citation: cite the records this statement rests on.
- risks[1]: '5' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[1]: No citation: cite the records this statement rests on.
- risks[2]: '6,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[2]: '8' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[2]: No citation: cite the records this statement rests on.
- risks[3]: '2.0' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[3]: '6,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[3]: '7' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[3]: No citation: cite the records this statement rests on.
- risks[4]: '$3.2' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[4]: '6%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[4]: '25,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[4]: '28' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[4]: No citation: cite the records this statement rests on.
- risks[5]: '40%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[5]: '82,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[5]: '87' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[5]: No citation: cite the records this statement rests on.
- risks[6]: '39,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[6]: '40,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[6]: '42,' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[6]: '46' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[6]: No citation: cite the records this statement rests on.
- risks[7]: '51' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[7]: No citation: cite the records this statement rests on.
- risks[8]: '$50.3' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[8]: '87' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[8]: No citation: cite the records this statement rests on.
- what_would_change_view[0]: '18' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[0]: '14' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[0]: No citation: cite the records this statement rests on.
- what_would_change_view[1]: No citation: cite the records this statement rests on.
- what_would_change_view[2]: No citation: cite the records this statement rests on.
- what_would_change_view[3]: No citation: cite the records this statement rests on.
- what_would_change_view[4]: No citation: cite the records this statement rests on.
- what_would_change_view[5]: No citation: cite the records this statement rests on.
- limitations[0]: {fact:ID} is not an ID any tool returned in this run.
- limitations[1]: {fact:ID} is not an ID any tool returned in this run.
- limitations[1]: {calc:ID} is not an ID any tool returned in this run.
- limitations[1]: '$3.2 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- limitations[1]: '6%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- limitations[1]: '40%' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- limitations[1]: '$50.3 billion' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- limitations[1]: '10' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- limitations[1]: '7' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.

## Sources

1. `fact-12cc32228151` revenue = $54.2 billion, 2023-01-01 to 2023-12-30 (us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; 10-K 0000050863-24-000010, filed 2024-01-26) https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/
2. `fact-73c774164b5b` net_income = $1.7 billion, 2023-01-01 to 2023-12-30 (us-gaap:NetIncomeLoss; 10-K 0000050863-24-000010, filed 2024-01-26) https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/
