# What are the main risks in Intel's 2023 annual report, and what were its 2023 net revenue and net income?

- Run status: finished
- Cutoff: 2024-03-31T23:59:59.999999+00:00
- Condition: B (single agent)
- Model: nvidia/nemotron-3-ultra-550b-a55b:free (served by Nvidia)
- Run: 20261124-161603-9b1d5a

## Plan

1. **Find Intel (ticker: INTC)** using `find_company` to get its CIK and confirm it's a US GAAP filer.
2. **Get 2023 annual financials** via `get_financials` for the fiscal year ended Dec 30, 2023 (Intel's FY2023) – extract net revenue and net income (with fact IDs).
3. **Read Item 1A (Risk Factors)** of Intel's latest 10-K (filed early 2024 for FY2023) using `read_filing_section` to capture the main risks disclosed.
4. **Optional:** Quick scan of recent 8-Ks via `list_filings` (forms=["8-K"]) around the reporting period for any material risk-related events, but the primary risk disclosure is in Item 1A.
5. **Cite** all figures and risk excerpts with their respective fact/chunk IDs.

## Summary (qualified)

- Intel's 2023 annual report (fiscal year ended [missing fact:12cc32228151.end]) shows net revenue of $54.2 billion and net income of $1.7 billion. [1] [2] (qualified: see checker flags)
- The main risks disclosed in Item 1A center on intense competition (especially in AI and data center), execution risk in its IDM 2.0 and foundry (IFS) strategies, process technology delays, high fixed costs from massive capital spending, geopolitical and trade tensions (particularly US-China), supply chain dependencies, product security vulnerabilities, and cybersecurity threats. [3] [4] [5] [6] [7] [8] [9] [10] (qualified: see checker flags)

## Key numbers (cited)

- Net revenue for FY2023: $54.2 billion [1]
- Net income for FY2023: $1.7 billion [2]
- R&D expense for FY2023: $16.0 billion [11]
- Capital expenditures for FY2023: $25.8 billion [12]
- Revenue from China was a significant portion of total FY2023 revenue, and a meaningful amount was dependent on US export authorizations. [7] [13]

## Bull case (cited)

- Intel maintains a large installed base and brand recognition across PC, data center, and network infrastructure markets. [14]
- The company is investing heavily in R&D ($16.0 billion) and capex ($25.8 billion) to regain process technology leadership by 2025, which could restore competitive positioning if executed successfully. [11] [12] [5]
- Government incentives (CHIPS Act in US, EU Chips Act in Germany) could offset a portion of the high capital costs for new fabrication facilities. [15]

## Bear case (qualified)

- Intense competition from AMD, NVIDIA, ARM-based designs, and Apple's internal silicon has already eroded market share in client and data center CPUs, and the shift of customer spend to GPUs for AI workloads is accelerating. [16] [14] [17]
- The foundry strategy (IFS) is highly risky: Intel has limited third-party foundry experience, must compete with well-established TSMC and Samsung, and many potential IFS customers are direct competitors who may hesitate to share designs. [4]
- Process technology delays (historically in 10nm and 7nm nodes, and 4th Gen Xeon) have allowed competitors to gain manufacturing advantages, and the ambitious multi-node roadmap carries significant execution risk. [18] [5] (qualified: see checker flags)
- High fixed cost structure from massive capex makes margins highly sensitive to demand downturns; underutilization could trigger asset write-downs and accelerated depreciation. [6]
- Geopolitical risks are acute: a significant portion of revenue comes from China, a meaningful amount is dependent on US export licenses, and escalating US-China trade restrictions could further limit market access. [7] [13]

## Risks (qualified)

- Competitive risk: Intense competition across all product lines from AMD, NVIDIA, Qualcomm, ARM ecosystem, Apple, and Chinese semiconductor companies. [3] [16] [19] [14]
- Foundry execution risk: IFS strategy requires overcoming customer IP concerns, hiring foundry talent, and competing with TSMC/Samsung/GF/UMC/SMIC on technology, capacity, price, and ecosystem. [4]
- Process technology risk: Delays in new nodes (historically in 10nm and 7nm, and 4th Gen Xeon) can cause cost, performance, and time-to-market disadvantages vs. foundry-based competitors. [20] [18] [21] [22] (qualified: see checker flags)
- High fixed cost / demand cyclicality risk: Capex of $25.8 billion creates high fixed costs; demand downturns disproportionately hurt gross margin and can trigger asset write-downs. [12] [6] [23] [24]
- Geopolitical and trade risk: US-China tensions, export controls (a meaningful amount of revenue at risk), Russia-Ukraine war, Israel tensions, and China-Taiwan tensions threaten operations and market access. [7] [25] [13] [26] [27] [28] [29]
- Supply chain risk: Dependence on single/limited suppliers (e.g., ASML for EUV tools), geographic concentration of leading-edge foundries in Asia, and long qualification times for alternates. [8] [30]
- Product security vulnerabilities: Ongoing side-channel vulnerabilities (Spectre, Meltdown variants) and mitigation challenges can cause performance impacts, reputational harm, and litigation costs. [9] [31] [32]
- Cybersecurity risk: Increasingly sophisticated attacks, including state-sponsored and AI-enabled threats, targeting design/manufacturing processes and sensitive customer data in foundry/cloud businesses. [10] [33]

## What would change the view (qualified)

- Clear evidence that Intel's next-generation process nodes (such as 18A) are ramping on schedule with competitive yield and performance vs. leading foundry nodes. [5] [18] (qualified: see checker flags)
- Significant external foundry customer wins for IFS (especially large fabless companies) demonstrating the model's viability. [4]
- Stabilization or growth in data center CPU revenue share, reversing the shift to GPU/AI accelerator spend. [14] [17]
- Resolution of US-China export control uncertainties or diversification of revenue away from China-dependent products. [13]

## Limitations

- Only a portion of Item 1A paragraphs were retrieved; additional risk factors may appear in later sections.
- Financial data is from SEC structured data (companyfacts); the net income figure matches the 10-K but was not independently verified against the inline XBRL filing.
- Risk factor text is management's disclosure of potential risks, not a probability-weighted assessment; actual outcomes may differ.
- No analysis of Item 7 (MD&A) was performed, which may contain additional context on risk mitigation and outlook.
- Peer comparisons and valuation metrics were not requested and are not included.

## Flags

- summary[0]: {fact:12cc32228151.end} is not an ID any tool returned in this run.
- summary[1]: '2.0' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[2]: '10' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[2]: '7' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- bear_case[2]: '4' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[2]: '10' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[2]: '7' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- risks[2]: '4' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.
- what_would_change_view[0]: '18' is typed, not a {fact:ID}/{calc:ID} placeholder, so no tool result backs it.

## Sources

1. `fact-12cc32228151` revenue = $54.2 billion, 2023-01-01 to 2023-12-30 (us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; 10-K 0000050863-24-000010, filed 2024-01-26) https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/
2. `fact-73c774164b5b` net_income = $1.7 billion, 2023-01-01 to 2023-12-30 (us-gaap:NetIncomeLoss; 10-K 0000050863-24-000010, filed 2024-01-26) https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/
3. `chunk-0000050863-24-000010-part_i_item_1a-1` 10-K 0000050863-24-000010, part_i_item_1a paragraph 1 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
4. `chunk-0000050863-24-000010-part_i_item_1a-5` 10-K 0000050863-24-000010, part_i_item_1a paragraph 5 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
5. `chunk-0000050863-24-000010-part_i_item_1a-6` 10-K 0000050863-24-000010, part_i_item_1a paragraph 6 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
6. `chunk-0000050863-24-000010-part_i_item_1a-7` 10-K 0000050863-24-000010, part_i_item_1a paragraph 7 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
7. `chunk-0000050863-24-000010-part_i_item_1a-25` 10-K 0000050863-24-000010, part_i_item_1a paragraph 25 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
8. `chunk-0000050863-24-000010-part_i_item_1a-39` 10-K 0000050863-24-000010, part_i_item_1a paragraph 39 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
9. `chunk-0000050863-24-000010-part_i_item_1a-51` 10-K 0000050863-24-000010, part_i_item_1a paragraph 51 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
10. `chunk-0000050863-24-000010-part_i_item_1a-54` 10-K 0000050863-24-000010, part_i_item_1a paragraph 54 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
11. `fact-a6dd5eca838f` research_and_development = $16.0 billion, 2023-01-01 to 2023-12-30 (us-gaap:ResearchAndDevelopmentExpense; 10-K 0000050863-24-000010, filed 2024-01-26) https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/
12. `fact-ad54396f9cae` capex = $25.8 billion, 2023-01-01 to 2023-12-30 (us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; 10-K 0000050863-24-000010, filed 2024-01-26) https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/
13. `chunk-0000050863-24-000010-part_i_item_1a-28` 10-K 0000050863-24-000010, part_i_item_1a paragraph 28 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
14. `chunk-0000050863-24-000010-part_i_item_1a-4` 10-K 0000050863-24-000010, part_i_item_1a paragraph 4 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
15. `chunk-0000050863-24-000010-part_i_item_1a-17` 10-K 0000050863-24-000010, part_i_item_1a paragraph 17 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
16. `chunk-0000050863-24-000010-part_i_item_1a-2` 10-K 0000050863-24-000010, part_i_item_1a paragraph 2 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
17. `chunk-0000050863-24-000010-part_i_item_1a-37` 10-K 0000050863-24-000010, part_i_item_1a paragraph 37 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
18. `chunk-0000050863-24-000010-part_i_item_1a-9` 10-K 0000050863-24-000010, part_i_item_1a paragraph 9 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
19. `chunk-0000050863-24-000010-part_i_item_1a-3` 10-K 0000050863-24-000010, part_i_item_1a paragraph 3 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
20. `chunk-0000050863-24-000010-part_i_item_1a-8` 10-K 0000050863-24-000010, part_i_item_1a paragraph 8 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
21. `chunk-0000050863-24-000010-part_i_item_1a-10` 10-K 0000050863-24-000010, part_i_item_1a paragraph 10 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
22. `chunk-0000050863-24-000010-part_i_item_1a-11` 10-K 0000050863-24-000010, part_i_item_1a paragraph 11 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
23. `chunk-0000050863-24-000010-part_i_item_1a-18` 10-K 0000050863-24-000010, part_i_item_1a paragraph 18 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
24. `chunk-0000050863-24-000010-part_i_item_1a-24` 10-K 0000050863-24-000010, part_i_item_1a paragraph 24 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
25. `chunk-0000050863-24-000010-part_i_item_1a-27` 10-K 0000050863-24-000010, part_i_item_1a paragraph 27 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
26. `chunk-0000050863-24-000010-part_i_item_1a-29` 10-K 0000050863-24-000010, part_i_item_1a paragraph 29 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
27. `chunk-0000050863-24-000010-part_i_item_1a-30` 10-K 0000050863-24-000010, part_i_item_1a paragraph 30 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
28. `chunk-0000050863-24-000010-part_i_item_1a-31` 10-K 0000050863-24-000010, part_i_item_1a paragraph 31 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
29. `chunk-0000050863-24-000010-part_i_item_1a-32` 10-K 0000050863-24-000010, part_i_item_1a paragraph 32 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
30. `chunk-0000050863-24-000010-part_i_item_1a-46` 10-K 0000050863-24-000010, part_i_item_1a paragraph 46 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
31. `chunk-0000050863-24-000010-part_i_item_1a-52` 10-K 0000050863-24-000010, part_i_item_1a paragraph 52 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
32. `chunk-0000050863-24-000010-part_i_item_1a-53` 10-K 0000050863-24-000010, part_i_item_1a paragraph 53 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
33. `chunk-0000050863-24-000010-part_i_item_1a-55` 10-K 0000050863-24-000010, part_i_item_1a paragraph 55 https://www.sec.gov/Archives/edgar/data/50863/000005086324000010/intc-20231230.htm
